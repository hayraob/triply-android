# Changelog

## [1.0.0] — Initial V1 Implementation
- **Phase A (Foundation)**: Reproducible Gradle 8.9 / AGP 8.7.3 / Kotlin 2.0.21 / Compose BOM / Room 2.6.1 / MapLibre 11.8.0 project, GitHub Actions CI workflow (`.github/workflows/android-build.yml`), dark-mode-only `TriplyTheme`, 17 Room entities, 5 DAOs, and 5-tab navigation.
- **Phase B (Core Trip Data)**: Multi-destination Trip Builder, editable starting templates, itinerary block CRUD/duplicate/reorder, transfer-day duration calculator, and dynamic activity-specific forms.
- **Phase C (Maps & Routing)**: MapLibre Native Android map canvas with numbered pins and ordered polyline, `OpenRouteServiceRoutingProvider` with honest motorcycle limitation notice, saved offline routes, external `geo:` navigation, and compliant `OfflineRegionsScreen` with `TileSourcePolicyGuard`.
- **Phase D (Money & Logistics)**: Planned vs. actual budget tracker with integer minor units, Compose Canvas category chart, receipt attachments, participant split & settlement engine, accommodation/transport managers, and non-destructive dynamic packing checklist.
- **Phase E (Time & Safety)**: Alarm & Timeline with `AlarmManager` + `WorkManager` + `BootCompletedReceiver`, permission rationales, and offline Emergency Center.
- **Phase F (Weather, Journal & What-If)**: Open-Meteo weather caching with freshness badges, Trip Journal with app-private media persistence and Markdown export, and isolated What-If Planner with explicit confirmation.
- **Phase G (Backup, Import & Credits)**: Versioned ZIP full backup/restore and single-trip export/import with SHA-256 verification, Profile API configuration, and About Triply / Developer Credits for Haydar and silent.dt with vector social icons.
