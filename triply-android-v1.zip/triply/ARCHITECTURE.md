# Triply Architecture

## Module & Package Boundaries

Triply is structured as a single `:app` Gradle module with strict package boundaries separating domain rules, Room persistence, network/platform integrations, design system, navigation, and feature UI:

- `com.triply.app.core.common` — Pure Kotlin domain math and policy guards:
  - `MoneyMath`: Integer minor-unit currency formatting (IDR default), deterministic equal-split remainder distribution, and minimal settlement transfer solver.
  - `TripDurationCalculator`: Recalculates trip duration including explicit transfer days and computes nullable fuel cost estimates.
  - `TileSourcePolicyGuard`: Blocks prohibited public OpenStreetMap tile servers (`tile.openstreetmap.org`, etc.) from offline downloads and enforces provider attribution/cache limits.
  - `WeatherFreshness`: Evaluates `FRESH`, `STALE`, and `OFFLINE_CACHED` states (3-hour threshold).
  - `ConnectivityMonitor`: Reactive `ConnectivityManager.NetworkCallback` flow.
- `com.triply.app.core.database` — Room SQLite database (`TriplyDatabase`, schema exported to `app/schemas/`), 17 normalized entities with `CASCADE` foreign keys, explicit `orderIndex` columns (never relying on row insertion order), and 5 focused DAOs.
- `com.triply.app.core.data` — `TriplyRepository`, `ProviderConfigStore` (DataStore Preferences), `OpenRouteServiceRoutingProvider` (behind `RoutingProvider` interface), `OpenMeteoClient` (weather + debounced geocoding), `ReminderScheduler` (`AlarmManager` + `WorkManager` + `BootCompletedReceiver`), `TriplyArchiveManager` (versioned ZIP backup/restore & single-trip export/import with SHA-256 checksums), `ChecklistSuggestionEngine`, and `WhatIfSimulationEngine`.
- `com.triply.app.core.designsystem` — Dark-mode-only `TriplyTheme`, reusable cards/headers/pills/banners/dialogs, and vector platform icons (`SocialVectorIcons`).
- `com.triply.app.core.navigation` — 5-item bottom navigation (`Home`, `My Trips`, `Explore`, `Budget`, `Profile`), 6-tab `TripDetailScreen` (`Overview`, `Itinerary`, `Map`, `Budget`, `Preparation`, `Journal`), and secondary routes (`TripBuilder`, `WhatIfPlanner`, `EmergencyCenter`, `OfflineRegions`).
- `com.triply.app.feature.*` — Feature-scoped Compose screens bound directly to reactive Room `Flow` streams.

## Key Technical Decisions

1. **Exact Integer Financial Math**: All monetary values are stored as `Long` minor units (for IDR, integer Rupiah). Equal splits explicitly track `+1` remainder units on affected `ExpenseShareEntity` rows so no currency is silently lost.
2. **Offline-First Source of Truth**: Every user record is persisted immediately to Room. Network responses (routes, weather) are cached with retrieval timestamps (`fetchedAtEpochMillis`) and never presented as live data when offline or stale.
3. **Atomic Restore & Collision-Safe Import**: `TriplyArchiveManager` validates `manifest.json` schema version and SHA-256 checksum before touching Room, executes full restores inside `db.withTransaction`, and imports single-trip packages with regenerated UUIDs as new trips by default.
4. **Isolated What-If Workspace**: `WhatIfPlannerScreen` operates on an in-memory/sandboxed `WhatIfSnapshot` and only writes to the main trip tables after explicit user confirmation.
