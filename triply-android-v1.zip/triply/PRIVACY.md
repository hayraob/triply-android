# Triply Privacy Policy (V1)

Triply is designed to be **private by default and offline-first**.

## What Stays on Your Device
- All trips, destinations, itinerary blocks, planned budgets, actual expenses, receipts, participants, settlements, packing checklists, accommodation records, transport plans, reminders, emergency contacts, journal entries, photos/videos, and What-If scenarios are stored locally in the app's private SQLite database (`triply_local.db`) and private media directory.
- `android:allowBackup="false"` is enabled so Android cloud auto-backup does not silently upload your local database to third-party servers.
- Triply includes **zero analytics SDKs, zero advertising SDKs, and zero telemetry or crash trackers**.

## What Data Is Sent Externally (Only When You Explicitly Trigger It)
1. **Place Search (Explore)**: Sends your search query text to `geocoding-api.open-meteo.com` (debounced at 600 ms).
2. **Weather Refresh**: Sends only the latitude/longitude of your trip destinations to `api.open-meteo.com` (or `customer-api.open-meteo.com` if you configured a commercial key).
3. **Route Calculation**: Sends only the ordered waypoint coordinates of your trip to `api.openrouteservice.org` using your configured API key.
4. **Map Viewing / Offline Region Download**: Requests map style JSON and vector tiles from your selected tile provider (`OpenFreeMap`, `Stadia Maps`, `MapTiler`, or your self-hosted server).
5. **External Intents**: Tapping navigation, phone call, or developer social links hands off the requested URI to Android's external app or browser.

No personal notes, expense descriptions, participant names, phone numbers, or journal media are ever transmitted to any server.
