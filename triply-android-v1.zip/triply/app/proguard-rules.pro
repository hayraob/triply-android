# Keep Kotlinx Serialization models
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
-keepclassmembers class kotlinx.serialization.json.** {
    *** Companion;
}
-keepclasseswithmembers class kotlinx.serialization.json.** {
    kotlinx.serialization.KSerializer serializer(...);
}
-keep,includedescriptorclasses class com.triply.app.**$$serializer { *; }
-keepclassmembers class com.triply.app.** {
    *** Companion;
}
-keepclasseswithmembers class com.triply.app.** {
    kotlinx.serialization.KSerializer serializer(...);
}

# Keep Room entities & generated classes
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *
