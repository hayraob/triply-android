package com.triply.app.feature.whatif

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.triply.app.core.common.MoneyMath
import com.triply.app.core.data.TriplyRepository
import com.triply.app.core.data.WhatIfSimulationEngine
import com.triply.app.core.data.WhatIfSnapshot
import com.triply.app.core.database.TripBlockEntity
import com.triply.app.core.designsystem.ConfirmDestructiveDialog
import com.triply.app.core.designsystem.SectionHeader
import com.triply.app.core.designsystem.StatusPill
import com.triply.app.core.designsystem.TriplyCard
import com.triply.app.core.designsystem.TriplyColors
import com.triply.app.core.designsystem.TriplySpacing
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WhatIfPlannerScreen(
    repository: TriplyRepository,
    tripId: String,
    onBack: () -> Unit
) {
    val trip by repository.observeTrip(tripId).collectAsState(initial = null)
    val baselineBlocks by repository.observeBlocks(tripId).collectAsState(initial = emptyList())
    val participants by repository.observeParticipants(tripId).collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()

    val simBlocks = remember { mutableStateListOf<TripBlockEntity>() }
    var initialized by remember { mutableStateOf(false) }
    var stayDeltaText by remember { mutableStateOf("0") }
    var transportDeltaText by remember { mutableStateOf("0") }
    var gearDeltaText by remember { mutableStateOf("0") }
    var showApplyConfirm by remember { mutableStateOf(false) }

    LaunchedEffect(baselineBlocks) {
        if (!initialized && baselineBlocks.isNotEmpty()) {
            simBlocks.clear()
            simBlocks.addAll(baselineBlocks)
            initialized = true
        }
    }

    val snapshot = WhatIfSnapshot(
        blocks = simBlocks.toList(),
        accommodationCostDeltaMinor = stayDeltaText.toLongOrNull() ?: 0L,
        transportCostDeltaMinor = transportDeltaText.toLongOrNull() ?: 0L,
        gearAndTicketDeltaMinor = gearDeltaText.toLongOrNull() ?: 0L
    )
    val start = trip?.let { runCatching { LocalDate.parse(it.startDateIso) }.getOrNull() }
    val impact = WhatIfSimulationEngine.evaluateImpact(
        startDate = start,
        baselineBlocks = baselineBlocks,
        baselinePlannedBudgetMinor = trip?.plannedBudgetMinor ?: 0L,
        participantCount = participants.size.coerceAtLeast(1),
        snapshot = snapshot
    )
    val currency = trip?.currencyCode ?: "IDR"

    Scaffold(
        containerColor = TriplyColors.Background,
        topBar = {
            TopAppBar(
                title = { Text("What-If Planner") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = TriplyColors.Surface)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(TriplySpacing.Lg),
            verticalArrangement = Arrangement.spacedBy(TriplySpacing.Md)
        ) {
            TriplyCard(containerColor = TriplyColors.SurfaceSecondary) {
                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Text("Isolated Sandbox", style = MaterialTheme.typography.titleMedium)
                    StatusPill("Main trip untouched", TriplyColors.Success)
                }
                Spacer(Modifier.height(TriplySpacing.Xs))
                Text("Duration: ${impact.baselineDays}d -> ${impact.simulatedDays}d (${if (impact.dayDelta >= 0) "+${impact.dayDelta}" else impact.dayDelta}d)", style = MaterialTheme.typography.bodyLarge)
                Text("Planned Cost: ${MoneyMath.format(impact.baselineCostMinor, currency)} -> ${MoneyMath.format(impact.simulatedCostMinor, currency)}", style = MaterialTheme.typography.bodyLarge)
                Text("Per-Person (${participants.size.coerceAtLeast(1)}): ${MoneyMath.format(impact.simulatedPerPersonMinor, currency)}", style = MaterialTheme.typography.bodyMedium)
            }

            TriplyCard {
                SectionHeader(title = "Test Cost Adjustments (signed IDR)")
                OutlinedTextField(value = stayDeltaText, onValueChange = { stayDeltaText = it }, label = { Text("Accommodation Cost Change (+/- IDR)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(TriplySpacing.Xs))
                OutlinedTextField(value = transportDeltaText, onValueChange = { transportDeltaText = it }, label = { Text("Transport Mode Cost Change (+/- IDR)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(TriplySpacing.Xs))
                OutlinedTextField(value = gearDeltaText, onValueChange = { gearDeltaText = it }, label = { Text("Gear Rental / Ticket Change (+/- IDR)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }

            SectionHeader(
                title = "Simulated Itinerary Blocks (${simBlocks.size})",
                actionLabel = "Add Block",
                onActionClick = {
                    simBlocks.add(
                        TripBlockEntity(
                            id = UUID.randomUUID().toString(),
                            tripId = tripId,
                            title = "Simulated Stop",
                            destinationName = "Optional Destination",
                            orderIndex = simBlocks.size,
                            durationDays = 1
                        )
                    )
                }
            )

            simBlocks.forEachIndexed { idx, block ->
                TriplyCard {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(block.title, style = MaterialTheme.typography.titleMedium)
                            Text("${block.durationDays}d activity + ${block.transferDaysBefore}d transfer", style = MaterialTheme.typography.bodyMedium)
                        }
                        Row {
                            OutlinedButton(onClick = { simBlocks[idx] = block.copy(durationDays = block.durationDays + 1) }) {
                                Text("+1d")
                            }
                            IconButton(onClick = { simBlocks.removeAt(idx) }) {
                                Icon(Icons.Outlined.Delete, contentDescription = "Remove simulated block", tint = TriplyColors.Danger)
                            }
                        }
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(TriplySpacing.Sm), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(onClick = onBack, modifier = Modifier.weight(1f)) {
                    Text("Discard")
                }
                Button(onClick = { showApplyConfirm = true }, modifier = Modifier.weight(1f)) {
                    Text("Apply to Trip")
                }
            }
        }
    }

    if (showApplyConfirm) {
        ConfirmDestructiveDialog(
            title = "Apply What-If Scenario?",
            message = "This will update your main trip's itinerary blocks, end date, and planned budget to match this simulation.",
            confirmLabel = "Apply Changes",
            onConfirm = {
                scope.launch {
                    repository.applyWhatIfToMainTrip(tripId, snapshot)
                    showApplyConfirm = false
                    onBack()
                }
            },
            onDismiss = { showApplyConfirm = false }
        )
    }
}
