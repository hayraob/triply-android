package com.triply.app.feature.profile

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Backup
import androidx.compose.material.icons.outlined.DownloadForOffline
import androidx.compose.material.icons.outlined.FileOpen
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Restore
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.triply.app.core.data.TriplyRepository
import com.triply.app.core.data.backup.ArchivePreview
import com.triply.app.core.data.config.ProviderConfig
import com.triply.app.core.designsystem.ConfirmDestructiveDialog
import com.triply.app.core.designsystem.SectionHeader
import com.triply.app.core.designsystem.SocialVectorIcons
import com.triply.app.core.designsystem.TriplyCard
import com.triply.app.core.designsystem.TriplyColors
import com.triply.app.core.designsystem.TriplySpacing
import kotlinx.coroutines.launch

// Exact supplied developer credit links (Section 5 — never altered)
private object DeveloperSocialUrls {
    const val INSTAGRAM = "https://www.instagram.com/sailent.dt?dmpr=djVpOWFoZW42bWpj"
    const val DISCORD_INVITE = "https://discord.gg/sfTRrgQq"
    const val TIKTOK = "https://www.tiktok.com/@sailent.dt?_r=1&_t=ZS-9BfFb7apCx4"
    const val WHATSAPP = "https://wa.me/6287790421211"
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProfileScreen(
    repository: TriplyRepository,
    onOpenOfflineMaps: () -> Unit
) {
    val context = LocalContext.current
    val config by repository.configStore.configFlow.collectAsState(initial = ProviderConfig())
    val scope = rememberCoroutineScope()

    var mapProvider by remember { mutableStateOf(config.mapProviderId) }
    var mapStyleUrl by remember { mutableStateOf(config.mapStyleUrl) }
    var mapApiKey by remember { mutableStateOf(config.mapApiKey) }
    var orsApiKey by remember { mutableStateOf(config.orsApiKey) }
    var openMeteoKey by remember { mutableStateOf(config.openMeteoApiKey) }
    var statusMessage by remember { mutableStateOf<String?>(null) }

    var pendingRestoreUri by remember { mutableStateOf<Uri?>(null) }
    var pendingRestorePreview by remember { mutableStateOf<ArchivePreview?>(null) }
    var pendingImportTripUri by remember { mutableStateOf<Uri?>(null) }
    var pendingImportTripPreview by remember { mutableStateOf<ArchivePreview?>(null) }

    LaunchedEffect(config) {
        mapProvider = config.mapProviderId
        mapStyleUrl = config.mapStyleUrl
        mapApiKey = config.mapApiKey
        orsApiKey = config.orsApiKey
        openMeteoKey = config.openMeteoApiKey
    }

    val createBackupLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val res = repository.archiveManager.exportFullBackup(uri)
                statusMessage = res.fold(
                    onSuccess = { "Full local backup saved (${it.tripCount} trip(s), ${it.attachmentCount} attachment(s))." },
                    onFailure = { "Backup failed: ${it.localizedMessage}" }
                )
            }
        }
    }

    val pickRestoreLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val preview = repository.archiveManager.inspectArchive(uri)
                preview.fold(
                    onSuccess = {
                        pendingRestoreUri = uri
                        pendingRestorePreview = it
                    },
                    onFailure = { statusMessage = "Invalid backup file: ${it.localizedMessage}" }
                )
            }
        }
    }

    val pickImportTripLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val preview = repository.archiveManager.inspectArchive(uri)
                preview.fold(
                    onSuccess = {
                        pendingImportTripUri = uri
                        pendingImportTripPreview = it
                    },
                    onFailure = { statusMessage = "Invalid trip package: ${it.localizedMessage}" }
                )
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(TriplySpacing.Lg),
        verticalArrangement = Arrangement.spacedBy(TriplySpacing.Md)
    ) {
        Text("Profile & Settings", style = MaterialTheme.typography.headlineMedium)

        statusMessage?.let {
            TriplyCard(containerColor = TriplyColors.SurfaceSecondary) {
                Text(it, color = TriplyColors.Accent, style = MaterialTheme.typography.bodyMedium)
            }
        }

        // Offline Maps & Storage
        TriplyCard {
            SectionHeader(title = "Offline Maps & Storage", subtitle = "Available storage: ${repository.availableStorageMb()} MB")
            Button(onClick = onOpenOfflineMaps, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Outlined.DownloadForOffline, contentDescription = null)
                Text(" Manage Offline Map Regions")
            }
        }

        // Backup, Restore & Trip Import (Section 8)
        TriplyCard {
            SectionHeader(title = "Local Backup, Restore & Trip Import", subtitle = "All files stay on your device — no cloud sync in V1.")
            Row(horizontalArrangement = Arrangement.spacedBy(TriplySpacing.Sm), modifier = Modifier.fillMaxWidth()) {
                Button(onClick = { createBackupLauncher.launch("triply_full_backup.zip") }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Outlined.Backup, contentDescription = null)
                    Text(" Backup")
                }
                OutlinedButton(onClick = { pickRestoreLauncher.launch(arrayOf("application/zip")) }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Outlined.Restore, contentDescription = null)
                    Text(" Restore")
                }
            }
            Spacer(Modifier.height(TriplySpacing.Sm))
            OutlinedButton(
                onClick = { pickImportTripLauncher.launch(arrayOf("application/zip")) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Outlined.FileOpen, contentDescription = null)
                Text(" Import Shared Trip Package (.zip)")
            }
        }

        // Map & API Provider Configuration (Section 7D — no hardcoded secrets)
        TriplyCard {
            SectionHeader(title = "Map & API Settings", subtitle = "Configure your own keys locally. Keys are never bundled in the APK.")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(TriplySpacing.Xs)) {
                listOf(
                    "openfreemap" to "OpenFreeMap",
                    "stadia_maps" to "Stadia Maps",
                    "maptiler" to "MapTiler",
                    "self_hosted" to "Self-Hosted"
                ).forEach { (id, label) ->
                    FilterChip(selected = mapProvider == id, onClick = { mapProvider = id }, label = { Text(label) })
                }
            }
            Spacer(Modifier.height(TriplySpacing.Xs))
            if (mapProvider == "stadia_maps" || mapProvider == "maptiler") {
                OutlinedTextField(
                    value = mapApiKey,
                    onValueChange = { mapApiKey = it },
                    label = { Text("Map Tile Provider API Key") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            if (mapProvider == "self_hosted") {
                OutlinedTextField(
                    value = mapStyleUrl,
                    onValueChange = { mapStyleUrl = it },
                    label = { Text("Self-Hosted MapLibre Style JSON URL") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Spacer(Modifier.height(TriplySpacing.Xs))
            OutlinedTextField(
                value = orsApiKey,
                onValueChange = { orsApiKey = it },
                label = { Text("OpenRouteService API Key (for live routes)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(TriplySpacing.Xs))
            OutlinedTextField(
                value = openMeteoKey,
                onValueChange = { openMeteoKey = it },
                label = { Text("Open-Meteo Commercial Key (optional)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(TriplySpacing.Sm))
            Button(
                onClick = {
                    scope.launch {
                        repository.configStore.save(
                            ProviderConfig(
                                mapProviderId = mapProvider,
                                mapStyleUrl = mapStyleUrl,
                                mapApiKey = mapApiKey,
                                orsApiKey = orsApiKey,
                                openMeteoApiKey = openMeteoKey
                            )
                        )
                        statusMessage = "Provider settings saved locally."
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Save API Settings")
            }
        }

        // Permissions Shortcut
        TriplyCard {
            SectionHeader(title = "Notifications & Permissions")
            OutlinedButton(
                onClick = {
                    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                        data = Uri.fromParts("package", context.packageName, null)
                    }
                    runCatching { context.startActivity(intent) }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Outlined.Notifications, contentDescription = null)
                Text(" Open Android App Permissions")
            }
        }

        // About Triply & Developer Credits (Section 5 — exact names, vector icons, intent + browser fallback)
        TriplyCard {
            Text("About Triply", style = MaterialTheme.typography.titleLarge)
            Text("Your Journey, Fully Planned. • v1.0.0 (Offline-First)", style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(TriplySpacing.Md))

            Text("Developer Credits", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(TriplySpacing.Xs))
            Text("Haydar", style = MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.height(TriplySpacing.Xs))
            Text("silent.dt", style = MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.height(TriplySpacing.Sm))

            Row(
                horizontalArrangement = Arrangement.spacedBy(TriplySpacing.Md),
                verticalAlignment = Alignment.CenterVertically
            ) {
                FilledTonalIconButton(
                    onClick = { openExternalUrl(context, DeveloperSocialUrls.INSTAGRAM) },
                    colors = IconButtonDefaults.filledTonalIconButtonColors(containerColor = TriplyColors.SurfaceSecondary)
                ) {
                    Icon(SocialVectorIcons.Instagram, contentDescription = "Instagram for silent.dt", modifier = Modifier.size(22.dp), tint = TriplyColors.TextPrimary)
                }
                FilledTonalIconButton(
                    onClick = { openExternalUrl(context, DeveloperSocialUrls.DISCORD_INVITE) },
                    colors = IconButtonDefaults.filledTonalIconButtonColors(containerColor = TriplyColors.SurfaceSecondary)
                ) {
                    Icon(SocialVectorIcons.Discord, contentDescription = "Discord invite for silent.dt", modifier = Modifier.size(22.dp), tint = TriplyColors.TextPrimary)
                }
                FilledTonalIconButton(
                    onClick = { openExternalUrl(context, DeveloperSocialUrls.TIKTOK) },
                    colors = IconButtonDefaults.filledTonalIconButtonColors(containerColor = TriplyColors.SurfaceSecondary)
                ) {
                    Icon(SocialVectorIcons.TikTok, contentDescription = "TikTok for silent.dt", modifier = Modifier.size(22.dp), tint = TriplyColors.TextPrimary)
                }
                FilledTonalIconButton(
                    onClick = { openExternalUrl(context, DeveloperSocialUrls.WHATSAPP) },
                    colors = IconButtonDefaults.filledTonalIconButtonColors(containerColor = TriplyColors.SurfaceSecondary)
                ) {
                    Icon(SocialVectorIcons.WhatsApp, contentDescription = "WhatsApp for silent.dt", modifier = Modifier.size(22.dp), tint = TriplyColors.Success)
                }
            }
        }
    }

    // Restore preview + explicit confirmation dialog
    if (pendingRestoreUri != null && pendingRestorePreview != null) {
        val prev = pendingRestorePreview!!
        ConfirmDestructiveDialog(
            title = "Restore Full Backup?",
            message = "Archive: ${prev.summaryTitle} (schema v${prev.manifest.schemaVersion}, ${prev.manifest.attachmentCount} attachment(s)). Restoring will replace all current local trips and data.",
            confirmLabel = "Replace & Restore",
            onConfirm = {
                val uri = pendingRestoreUri!!
                scope.launch {
                    val res = repository.archiveManager.restoreFullBackup(uri)
                    statusMessage = res.fold(
                        onSuccess = { "Restored $it trip(s) successfully." },
                        onFailure = { "Restore failed (database unchanged): ${it.localizedMessage}" }
                    )
                }
                pendingRestoreUri = null
                pendingRestorePreview = null
            },
            onDismiss = {
                pendingRestoreUri = null
                pendingRestorePreview = null
            }
        )
    }

    // Import single trip preview + confirmation dialog
    if (pendingImportTripUri != null && pendingImportTripPreview != null) {
        val prev = pendingImportTripPreview!!
        ConfirmDestructiveDialog(
            title = "Import Shared Trip?",
            message = "Import '${prev.summaryTitle}' (schema v${prev.manifest.schemaVersion}, ${prev.manifest.attachmentCount} attachment(s)) as a new trip? Existing trips will not be overwritten.",
            confirmLabel = "Import as New Trip",
            onConfirm = {
                val uri = pendingImportTripUri!!
                scope.launch {
                    val res = repository.archiveManager.importSingleTripAsNew(uri)
                    statusMessage = res.fold(
                        onSuccess = { "Imported '${prev.summaryTitle}' as a new trip." },
                        onFailure = { "Trip import failed: ${it.localizedMessage}" }
                    )
                }
                pendingImportTripUri = null
                pendingImportTripPreview = null
            },
            onDismiss = {
                pendingImportTripUri = null
                pendingImportTripPreview = null
            }
        )
    }
}

private fun openExternalUrl(context: Context, url: String) {
    val uri = Uri.parse(url)
    val intent = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    runCatching { context.startActivity(intent) }
}
