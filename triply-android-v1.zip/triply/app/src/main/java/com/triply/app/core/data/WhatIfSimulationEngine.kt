package com.triply.app.core.data

import com.triply.app.core.common.TripDurationCalculator
import com.triply.app.core.database.TripBlockEntity
import kotlinx.serialization.Serializable
import java.time.LocalDate

@Serializable
data class WhatIfSnapshot(
    val blocks: List<TripBlockEntity>,
    val accommodationCostDeltaMinor: Long = 0L,
    val transportCostDeltaMinor: Long = 0L,
    val gearAndTicketDeltaMinor: Long = 0L,
    val transportModeNote: String = ""
)

data class WhatIfImpactReport(
    val baselineDays: Int,
    val simulatedDays: Int,
    val dayDelta: Int,
    val baselineCostMinor: Long,
    val simulatedCostMinor: Long,
    val costDeltaMinor: Long,
    val baselinePerPersonMinor: Long,
    val simulatedPerPersonMinor: Long,
    val perPersonDeltaMinor: Long
)

/**
 * Pure isolated simulation calculator for Module 12 (What-If Planner).
 * Never mutates the main trip until the user explicitly confirms Apply.
 */
object WhatIfSimulationEngine {

    fun evaluateImpact(
        startDate: LocalDate?,
        baselineBlocks: List<TripBlockEntity>,
        baselinePlannedBudgetMinor: Long,
        participantCount: Int,
        snapshot: WhatIfSnapshot
    ): WhatIfImpactReport {
        val baseDuration = TripDurationCalculator.calculate(
            startDate,
            baselineBlocks.map { TripDurationCalculator.BlockSpan(it.durationDays, it.transferDaysBefore) }
        )
        val simDuration = TripDurationCalculator.calculate(
            startDate,
            snapshot.blocks.map { TripDurationCalculator.BlockSpan(it.durationDays, it.transferDaysBefore) }
        )

        val baseBlocksCost = baselineBlocks.sumOf { it.estimatedCostMinor }
        val simBlocksCost = snapshot.blocks.sumOf { it.estimatedCostMinor }
        val blockCostDelta = simBlocksCost - baseBlocksCost

        val baseTotal = if (baselinePlannedBudgetMinor > 0L) baselinePlannedBudgetMinor else baseBlocksCost
        val simTotal = (baseTotal + blockCostDelta + snapshot.accommodationCostDeltaMinor +
            snapshot.transportCostDeltaMinor + snapshot.gearAndTicketDeltaMinor).coerceAtLeast(0L)

        val people = participantCount.coerceAtLeast(1).toLong()
        val basePerPerson = baseTotal / people
        val simPerPerson = simTotal / people

        return WhatIfImpactReport(
            baselineDays = baseDuration.totalTripDays,
            simulatedDays = simDuration.totalTripDays,
            dayDelta = simDuration.totalTripDays - baseDuration.totalTripDays,
            baselineCostMinor = baseTotal,
            simulatedCostMinor = simTotal,
            costDeltaMinor = simTotal - baseTotal,
            baselinePerPersonMinor = basePerPerson,
            simulatedPerPersonMinor = simPerPerson,
            perPersonDeltaMinor = simPerPerson - basePerPerson
        )
    }
}
