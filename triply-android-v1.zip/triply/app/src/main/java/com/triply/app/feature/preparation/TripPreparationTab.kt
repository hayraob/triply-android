package com.triply.app.feature.preparation

import android.Manifest
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.triply.app.core.common.MoneyMath
import com.triply.app.core.common.TripDurationCalculator
import com.triply.app.core.common.WeatherFreshness
import com.triply.app.core.data.TriplyRepository
import com.triply.app.core.data.network.OpenMeteoClient
import com.triply.app.core.data.network.ParsedWeatherForecast
import com.triply.app.core.data.network.WeatherOutcome
import com.triply.app.core.database.*
import com.triply.app.core.designsystem.EmptyStateView
import com.triply.app.core.designsystem.ErrorBanner
import com.triply.app.core.designsystem.SectionHeader
import com.triply.app.core.designsystem.StatusPill
import com.triply.app.core.designsystem.TriplyCard
import com.triply.app.core.designsystem.TriplyColors
import com.triply.app.core.designsystem.TriplySpacing
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.UUID

private val PREP_SECTIONS = listOf("Checklist", "Stay & Transport", "Weather", "Reminders")

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TripPreparationTab(
    repository: TriplyRepository,
    tripId: String,
    trip: TripEntity?,
    isOnline: Boolean
) {
    var section by rememberSaveable { mutableIntStateOf(0) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(TriplySpacing.Lg),
        verticalArrangement = Arrangement.spacedBy(TriplySpacing.Md)
    ) {
        FlowRow(horizontalArrangement = Arrangement.spacedBy(TriplySpacing.Xs)) {
            PREP_SECTIONS.forEachIndexed { idx, label ->
                FilterChip(selected = section == idx, onClick = { section = idx }, label = { Text(label) })
            }
        }

        when (section) {
            0 -> PackingChecklistSection(repository, tripId)
            1 -> AccommodationAndTransportSection(repository, tripId, trip?.currencyCode ?: "IDR")
            2 -> WeatherSection(repository, tripId, isOnline)
            3 -> RemindersSection(repository, tripId, trip)
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PackingChecklistSection(repository: TriplyRepository, tripId: String) {
    val items by repository.observePackingItems(tripId).collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var showAddDialog by remember { mutableStateOf(false) }

    val packed = items.count { it.isPacked }
    val progress = if (items.isEmpty()) 0f else packed.toFloat() / items.size.toFloat()

    TriplyCard {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Packing Readiness: $packed / ${items.size}", style = MaterialTheme.typography.titleMedium)
            Text("${(progress * 100).toInt()}%", color = TriplyColors.Success, style = MaterialTheme.typography.titleMedium)
        }
        Spacer(Modifier.height(TriplySpacing.Xs))
        LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth(), color = TriplyColors.Success)
        Spacer(Modifier.height(TriplySpacing.Sm))
        Row(horizontalArrangement = Arrangement.spacedBy(TriplySpacing.Sm)) {
            Button(onClick = { showAddDialog = true }, modifier = Modifier.weight(1f)) {
                Icon(Icons.Outlined.Add, contentDescription = null)
                Text(" Add Item")
            }
            OutlinedButton(
                onClick = { scope.launch { repository.mergeSuggestedPackingItems(tripId) } },
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Outlined.AutoAwesome, contentDescription = null)
                Text(" Suggest Gear")
            }
        }
    }

    if (items.isEmpty()) {
        EmptyStateView(
            title = "Checklist is empty",
            message = "Tap 'Suggest Gear' to merge activity-based personal and group items without overwriting your custom items."
        )
    } else {
        val personal = items.filter { !it.isGroupGear }
        val group = items.filter { it.isGroupGear }

        if (personal.isNotEmpty()) {
            SectionHeader(title = "Personal Gear (${personal.size})")
            personal.forEach { item -> PackingItemRow(item, repository) }
        }
        if (group.isNotEmpty()) {
            SectionHeader(title = "Group Equipment (${group.size})")
            group.forEach { item -> PackingItemRow(item, repository) }
        }
    }

    if (showAddDialog) {
        var name by remember { mutableStateOf("") }
        var category by remember { mutableStateOf("Essentials") }
        var isGroup by remember { mutableStateOf(false) }
        var ownership by remember { mutableStateOf(GearOwnershipStatus.OWNED) }
        var qty by remember { mutableStateOf("1") }
        var owner by remember { mutableStateOf("") }
        var rentalPrice by remember { mutableStateOf("0") }

        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            containerColor = TriplyColors.Surface,
            title = { Text("Add Packing / Gear Item") },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(TriplySpacing.Xs)) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Item Name *") }, singleLine = true)
                    OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text("Category") }, singleLine = true)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("Group Equipment?")
                        Switch(checked = isGroup, onCheckedChange = { isGroup = it })
                    }
                    Text("Ownership Status", style = MaterialTheme.typography.labelMedium)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(TriplySpacing.Xs)) {
                        GearOwnershipStatus.entries.forEach { st ->
                            FilterChip(selected = ownership == st, onClick = { ownership = st }, label = { Text(st.label) })
                        }
                    }
                    OutlinedTextField(value = qty, onValueChange = { qty = it.filter { c -> c.isDigit() } }, label = { Text("Quantity") }, singleLine = true)
                    OutlinedTextField(value = owner, onValueChange = { owner = it }, label = { Text("Responsible Person (optional)") }, singleLine = true)
                    if (ownership == GearOwnershipStatus.RENT || ownership == GearOwnershipStatus.BUY) {
                        OutlinedTextField(value = rentalPrice, onValueChange = { rentalPrice = it.filter { c -> c.isDigit() } }, label = { Text("Estimated Price (IDR)") }, singleLine = true)
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (name.isNotBlank()) {
                        scope.launch {
                            repository.savePackingItem(
                                PackingItemEntity(
                                    id = UUID.randomUUID().toString(),
                                    tripId = tripId,
                                    name = name.trim(),
                                    categoryName = category.ifBlank { "General" },
                                    isGroupGear = isGroup,
                                    ownershipStatus = ownership.name,
                                    quantity = qty.toIntOrNull()?.coerceAtLeast(1) ?: 1,
                                    rentalPriceMinor = rentalPrice.toLongOrNull() ?: 0L,
                                    ownerName = owner.trim()
                                )
                            )
                            showAddDialog = false
                        }
                    }
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showAddDialog = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun PackingItemRow(item: PackingItemEntity, repository: TriplyRepository) {
    val scope = rememberCoroutineScope()
    val statusLabel = runCatching { GearOwnershipStatus.valueOf(item.ownershipStatus).label }.getOrDefault(item.ownershipStatus)
    TriplyCard {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Checkbox(
                checked = item.isPacked,
                onCheckedChange = { checked ->
                    scope.launch { repository.savePackingItem(item.copy(isPacked = checked)) }
                }
            )
            Column(modifier = Modifier.weight(1f)) {
                Text("${item.name} (x${item.quantity})", style = MaterialTheme.typography.titleMedium)
                Text(
                    "${item.categoryName} • $statusLabel" +
                        (if (item.ownerName.isNotBlank()) " • ${item.ownerName}" else "") +
                        (if (item.rentalPriceMinor > 0L) " • ${MoneyMath.format(item.rentalPriceMinor)}" else ""),
                    style = MaterialTheme.typography.bodyMedium
                )
            }
            IconButton(onClick = { scope.launch { repository.deletePackingItem(item.id) } }) {
                Icon(Icons.Outlined.Delete, contentDescription = "Remove item", tint = TriplyColors.Danger)
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AccommodationAndTransportSection(repository: TriplyRepository, tripId: String, currency: String) {
    val stays by repository.observeAccommodations(tripId).collectAsState(initial = emptyList())
    val transports by repository.observeTransportPlans(tripId).collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()

    var showAddStay by remember { mutableStateOf(false) }
    var showAddTransport by remember { mutableStateOf(false) }

    SectionHeader(
        title = "Accommodations (${stays.size})",
        subtitle = "User-entered lodging & campsite records (no live booking inventory).",
        actionLabel = "Add Stay",
        onActionClick = { showAddStay = true }
    )
    if (stays.isEmpty()) {
        EmptyStateView(title = "No accommodations saved", message = "Record hotels, homestays, basecamps, or campsites with check-in/out and payment status.")
    } else {
        stays.forEach { stay ->
            val total = stay.pricePerNightMinor * stay.nights.coerceAtLeast(1) * stay.rooms.coerceAtLeast(1)
            TriplyCard {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(stay.name, style = MaterialTheme.typography.titleMedium)
                        Text("${stay.checkInIso} -> ${stay.checkOutIso} (${stay.nights}n, ${stay.rooms} rm)", style = MaterialTheme.typography.bodyMedium)
                        Text("Total: ${MoneyMath.format(total, currency)} • ${stay.reservationStatus} • ${stay.paymentStatus}", style = MaterialTheme.typography.labelMedium)
                    }
                    IconButton(onClick = { scope.launch { repository.deleteAccommodation(stay.id) } }) {
                        Icon(Icons.Outlined.Delete, contentDescription = "Delete stay", tint = TriplyColors.Danger)
                    }
                }
            }
        }
    }

    SectionHeader(
        title = "Transport Plans (${transports.size})",
        subtitle = "Vehicle, rental, fuel estimates (clearly labelled), tolls, and public tickets.",
        actionLabel = "Add Transport",
        onActionClick = { showAddTransport = true }
    )
    if (transports.isEmpty()) {
        EmptyStateView(title = "No transport plans saved", message = "Add private/rental vehicle or public transport costs and schedule notes.")
    } else {
        transports.forEach { t ->
            val modeEnum = runCatching { TransportMode.valueOf(t.mode) }.getOrDefault(TransportMode.CUSTOM)
            val estFuel = TripDurationCalculator.estimateFuelCostIdr(
                t.estimatedDistanceKm, t.fuelEfficiencyKmPerLiter, t.fuelPricePerLiterMinor
            )
            val rentalTotal = t.pricePerDayMinor * t.rentalDays
            TriplyCard {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(modeEnum.label + (if (t.providerName.isNotBlank()) " — ${t.providerName}" else ""), style = MaterialTheme.typography.titleMedium)
                        if (rentalTotal > 0L) Text("Rental: ${MoneyMath.format(rentalTotal, currency)} (${t.rentalDays}d)", style = MaterialTheme.typography.bodyMedium)
                        if (estFuel != null) Text("Estimated Fuel: ${MoneyMath.format(estFuel, currency)} (Estimate)", style = MaterialTheme.typography.bodyMedium, color = TriplyColors.Warning)
                        if (t.parkingAndTollsMinor > 0L) Text("Parking & Tolls: ${MoneyMath.format(t.parkingAndTollsMinor, currency)}", style = MaterialTheme.typography.bodyMedium)
                        if (t.ticketCostMinor > 0L) Text("Tickets: ${MoneyMath.format(t.ticketCostMinor, currency)}", style = MaterialTheme.typography.bodyMedium)
                        if (t.scheduleNotes.isNotBlank()) Text(t.scheduleNotes, style = MaterialTheme.typography.labelMedium)
                    }
                    IconButton(onClick = { scope.launch { repository.deleteTransportPlan(t.id) } }) {
                        Icon(Icons.Outlined.Delete, contentDescription = "Delete transport", tint = TriplyColors.Danger)
                    }
                }
            }
        }
    }

    if (showAddStay) {
        var sName by remember { mutableStateOf("") }
        var checkIn by remember { mutableStateOf(LocalDate.now().toString()) }
        var checkOut by remember { mutableStateOf(LocalDate.now().plusDays(1).toString()) }
        var nights by remember { mutableStateOf("1") }
        var price by remember { mutableStateOf("0") }
        var resStatus by remember { mutableStateOf(ReservationStatus.NOT_BOOKED) }
        var payStatus by remember { mutableStateOf(PaymentStatus.UNPAID) }

        AlertDialog(
            onDismissRequest = { showAddStay = false },
            containerColor = TriplyColors.Surface,
            title = { Text("Add Accommodation") },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(TriplySpacing.Xs)) {
                    OutlinedTextField(value = sName, onValueChange = { sName = it }, label = { Text("Hotel / Campsite Name *") }, singleLine = true)
                    OutlinedTextField(value = checkIn, onValueChange = { checkIn = it }, label = { Text("Check-in (YYYY-MM-DD)") }, singleLine = true)
                    OutlinedTextField(value = checkOut, onValueChange = { checkOut = it }, label = { Text("Check-out (YYYY-MM-DD)") }, singleLine = true)
                    OutlinedTextField(value = nights, onValueChange = { nights = it.filter { c -> c.isDigit() } }, label = { Text("Nights") }, singleLine = true)
                    OutlinedTextField(value = price, onValueChange = { price = it.filter { c -> c.isDigit() } }, label = { Text("Price / Night (IDR)") }, singleLine = true)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(TriplySpacing.Xs)) {
                        ReservationStatus.entries.forEach { st ->
                            FilterChip(selected = resStatus == st, onClick = { resStatus = st }, label = { Text(st.label) })
                        }
                    }
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(TriplySpacing.Xs)) {
                        PaymentStatus.entries.forEach { st ->
                            FilterChip(selected = payStatus == st, onClick = { payStatus = st }, label = { Text(st.label) })
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (sName.isNotBlank()) {
                        scope.launch {
                            repository.saveAccommodation(
                                AccommodationEntity(
                                    id = UUID.randomUUID().toString(),
                                    tripId = tripId,
                                    name = sName.trim(),
                                    checkInIso = checkIn,
                                    checkOutIso = checkOut,
                                    nights = nights.toIntOrNull()?.coerceAtLeast(1) ?: 1,
                                    pricePerNightMinor = price.toLongOrNull() ?: 0L,
                                    reservationStatus = resStatus.name,
                                    paymentStatus = payStatus.name
                                )
                            )
                            showAddStay = false
                        }
                    }
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showAddStay = false }) { Text("Cancel") } }
        )
    }

    if (showAddTransport) {
        var mode by remember { mutableStateOf(TransportMode.PRIVATE_CAR) }
        var provider by remember { mutableStateOf("") }
        var distKm by remember { mutableStateOf("") }
        var kmPerL by remember { mutableStateOf("12") }
        var fuelPrice by remember { mutableStateOf("13000") }
        var tolls by remember { mutableStateOf("0") }
        var tickets by remember { mutableStateOf("0") }
        var notes by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddTransport = false },
            containerColor = TriplyColors.Surface,
            title = { Text("Add Transport Plan") },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(TriplySpacing.Xs)) {
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(TriplySpacing.Xs)) {
                        TransportMode.entries.forEach { m ->
                            FilterChip(selected = mode == m, onClick = { mode = m }, label = { Text(m.label) })
                        }
                    }
                    OutlinedTextField(value = provider, onValueChange = { provider = it }, label = { Text("Provider / Vehicle (optional)") }, singleLine = true)
                    if (mode.usesFuel) {
                        OutlinedTextField(value = distKm, onValueChange = { distKm = it }, label = { Text("Distance (km) for fuel estimate") }, singleLine = true)
                        OutlinedTextField(value = kmPerL, onValueChange = { kmPerL = it }, label = { Text("Fuel efficiency (km/L)") }, singleLine = true)
                        OutlinedTextField(value = fuelPrice, onValueChange = { fuelPrice = it.filter { c -> c.isDigit() } }, label = { Text("Fuel price / L (IDR)") }, singleLine = true)
                    }
                    OutlinedTextField(value = tolls, onValueChange = { tolls = it.filter { c -> c.isDigit() } }, label = { Text("Parking & Tolls (IDR)") }, singleLine = true)
                    OutlinedTextField(value = tickets, onValueChange = { tickets = it.filter { c -> c.isDigit() } }, label = { Text("Public Tickets (IDR)") }, singleLine = true)
                    OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Schedule / Notes") })
                }
            },
            confirmButton = {
                Button(onClick = {
                    scope.launch {
                        repository.saveTransportPlan(
                            TransportPlanEntity(
                                id = UUID.randomUUID().toString(),
                                tripId = tripId,
                                mode = mode.name,
                                providerName = provider.trim(),
                                estimatedDistanceKm = distKm.toDoubleOrNull(),
                                fuelEfficiencyKmPerLiter = kmPerL.toDoubleOrNull(),
                                fuelPricePerLiterMinor = fuelPrice.toLongOrNull(),
                                parkingAndTollsMinor = tolls.toLongOrNull() ?: 0L,
                                ticketCostMinor = tickets.toLongOrNull() ?: 0L,
                                scheduleNotes = notes.trim()
                            )
                        )
                        showAddTransport = false
                    }
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showAddTransport = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun WeatherSection(repository: TriplyRepository, tripId: String, isOnline: Boolean) {
    val destinations by repository.observeDestinations(tripId).collectAsState(initial = emptyList())
    val cachedWeather by repository.observeWeather(tripId).collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    val json = remember { Json { ignoreUnknownKeys = true } }
    var weatherError by remember { mutableStateOf<String?>(null) }
    var isRefreshing by remember { mutableStateOf(false) }

    val destsWithCoords = destinations.filter { it.latitude != null && it.longitude != null }

    TriplyCard {
        SectionHeader(title = "Weather Forecast (Open-Meteo)", subtitle = "Cached locally for offline viewing. Non-commercial free tier (<10,000 calls/day).")
        Button(
            enabled = isOnline && !isRefreshing && destsWithCoords.isNotEmpty(),
            onClick = {
                scope.launch {
                    isRefreshing = true
                    weatherError = null
                    destsWithCoords.forEach { d ->
                        val res = repository.refreshWeatherForDestination(tripId, d.name, d.latitude!!, d.longitude!!)
                        if (res is WeatherOutcome.Error) weatherError = res.message
                    }
                    isRefreshing = false
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Outlined.Refresh, contentDescription = null)
            Text(
                when {
                    !isOnline -> " Offline — Showing Cached Forecasts Only"
                    destsWithCoords.isEmpty() -> " Add Destination Coordinates in Map/Explore First"
                    isRefreshing -> " Refreshing..."
                    else -> " Refresh Weather (${destsWithCoords.size} destination(s))"
                }
            )
        }
    }

    weatherError?.let { ErrorBanner(it) }

    if (cachedWeather.isEmpty()) {
        EmptyStateView(
            title = "No weather forecast cached",
            message = "Add coordinates to a destination and refresh while online to cache a 7-day and 24-hour forecast."
        )
    } else {
        cachedWeather.forEach { cache ->
            val freshness = WeatherFreshness.evaluate(cache.fetchedAtEpochMillis, System.currentTimeMillis(), isOnline)
            val updatedStr = Instant.ofEpochMilli(cache.fetchedAtEpochMillis)
                .atZone(ZoneId.systemDefault())
                .format(DateTimeFormatter.ofPattern("d MMM yyyy, HH:mm"))
            val parsed = runCatching { json.decodeFromString<ParsedWeatherForecast>(cache.forecastJson) }.getOrNull()

            TriplyCard {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(cache.destinationName, style = MaterialTheme.typography.titleMedium)
                    StatusPill(
                        text = when (freshness) {
                            WeatherFreshness.FRESH -> "Fresh"
                            WeatherFreshness.STALE -> "Stale Cache"
                            WeatherFreshness.OFFLINE_CACHED -> "Offline Cache"
                        },
                        color = if (freshness == WeatherFreshness.FRESH) TriplyColors.Success else TriplyColors.Warning
                    )
                }
                Text("Last updated: $updatedStr • ${cache.providerName}", style = MaterialTheme.typography.labelMedium)
                cache.severeNotice?.let {
                    Spacer(Modifier.height(TriplySpacing.Xs))
                    ErrorBanner("Severe Weather Notice: $it")
                }
                Spacer(Modifier.height(TriplySpacing.Sm))
                parsed?.daily?.forEach { day ->
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(day.dateIso, style = MaterialTheme.typography.bodyMedium)
                        Text(
                            "${OpenMeteoClient.describeWmoCode(day.weatherCode)} • %.0f°/%.0f°C • %.1fmm".format(day.tempMaxC, day.tempMinC, day.precipitationSumMm),
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun RemindersSection(repository: TriplyRepository, tripId: String, trip: TripEntity?) {
    val context = LocalContext.current
    val reminders by repository.observeReminders(tripId).collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()

    var showAddDialog by remember { mutableStateOf(false) }
    var showExactAlarmRationale by remember { mutableStateOf(false) }
    var scheduleNotice by remember { mutableStateOf<String?>(null) }

    val notifPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        scheduleNotice = if (granted) "Notification permission granted." else "Notification permission denied — reminders remain visible inside the app timeline."
    }

    TriplyCard {
        SectionHeader(
            title = "Alarm & Preparation Timeline",
            subtitle = "Reminders reschedule after reboot where Android permits. Battery optimization or Doze may delay delivery."
        )
        Row(horizontalArrangement = Arrangement.spacedBy(TriplySpacing.Sm)) {
            Button(onClick = { showAddDialog = true }, modifier = Modifier.weight(1f)) {
                Text("Add Reminder")
            }
            OutlinedButton(
                onClick = {
                    val start = trip?.let { runCatching { LocalDate.parse(it.startDateIso) }.getOrNull() }
                    if (start != null) {
                        scope.launch {
                            listOf(7L to ReminderType.PREP_H7, 3L to ReminderType.PREP_H3, 1L to ReminderType.PREP_H1).forEach { (daysBefore, type) ->
                                val triggerMs = start.minusDays(daysBefore).atTime(9, 0)
                                    .atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
                                repository.saveAndScheduleReminder(
                                    ReminderEntity(
                                        id = UUID.randomUUID().toString(),
                                        tripId = tripId,
                                        title = "${type.label}: ${trip.name}",
                                        message = "Check gear, permits, and bookings.",
                                        type = type.name,
                                        triggerAtEpochMillis = triggerMs,
                                        useExactAlarm = false
                                    )
                                )
                            }
                            scheduleNotice = "Added H-7, H-3, and H-1 preparation reminders via WorkManager."
                        }
                    }
                },
                modifier = Modifier.weight(1f)
            ) {
                Text("Auto H-7/H-3/H-1")
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Spacer(Modifier.height(TriplySpacing.Xs))
            TextButton(onClick = { notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }) {
                Text("Grant Notification Permission")
            }
        }
        scheduleNotice?.let { Text(it, color = TriplyColors.Accent, style = MaterialTheme.typography.labelMedium) }
    }

    if (reminders.isEmpty()) {
        EmptyStateView(title = "No reminders scheduled", message = "Add departure, activity, check-in, or H-7/H-3/H-1 preparation reminders.")
    } else {
        reminders.forEach { r ->
            val whenText = Instant.ofEpochMilli(r.triggerAtEpochMillis)
                .atZone(ZoneId.systemDefault())
                .format(DateTimeFormatter.ofPattern("d MMM yyyy, HH:mm"))
            TriplyCard {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Checkbox(
                        checked = r.isCompleted,
                        onCheckedChange = { done ->
                            scope.launch { repository.saveAndScheduleReminder(r.copy(isCompleted = done)) }
                        }
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(r.title, style = MaterialTheme.typography.titleMedium)
                        Text("$whenText • ${r.type}", style = MaterialTheme.typography.bodyMedium)
                    }
                    IconButton(onClick = { scope.launch { repository.deleteReminder(r) } }) {
                        Icon(Icons.Outlined.Delete, contentDescription = "Cancel reminder", tint = TriplyColors.Danger)
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        var rTitle by remember { mutableStateOf("") }
        var rHoursFromNow by remember { mutableStateOf("24") }
        var rType by remember { mutableStateOf(ReminderType.DEPARTURE) }
        var exact by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            containerColor = TriplyColors.Surface,
            title = { Text("Create Reminder") },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(TriplySpacing.Xs)) {
                    OutlinedTextField(value = rTitle, onValueChange = { rTitle = it }, label = { Text("Reminder Title *") }, singleLine = true)
                    OutlinedTextField(value = rHoursFromNow, onValueChange = { rHoursFromNow = it.filter { c -> c.isDigit() } }, label = { Text("Trigger in N hours from now") }, singleLine = true)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(TriplySpacing.Xs)) {
                        ReminderType.entries.forEach { t ->
                            FilterChip(selected = rType == t, onClick = { rType = t }, label = { Text(t.label) })
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("Use Exact Alarm (AlarmManager)")
                        Switch(checked = exact, onCheckedChange = { wantExact ->
                            if (wantExact && !repository.reminderScheduler.canScheduleExactAlarms()) {
                                showExactAlarmRationale = true
                            } else {
                                exact = wantExact
                            }
                        })
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (rTitle.isNotBlank()) {
                        val hours = rHoursFromNow.toLongOrNull()?.coerceAtLeast(1L) ?: 1L
                        scope.launch {
                            scheduleNotice = repository.saveAndScheduleReminder(
                                ReminderEntity(
                                    id = UUID.randomUUID().toString(),
                                    tripId = tripId,
                                    title = rTitle.trim(),
                                    type = rType.name,
                                    triggerAtEpochMillis = System.currentTimeMillis() + hours * 3_600_000L,
                                    useExactAlarm = exact
                                )
                            )
                            showAddDialog = false
                        }
                    }
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showAddDialog = false }) { Text("Cancel") } }
        )
    }

    if (showExactAlarmRationale) {
        AlertDialog(
            onDismissRequest = { showExactAlarmRationale = false },
            containerColor = TriplyColors.Surface,
            title = { Text("Exact Alarm Permission") },
            text = {
                Text("Triply only requests Android's Alarms & Reminders special access for user-created time-critical alarms (like departure times). Deferrable reminders use WorkManager without this permission.")
            },
            confirmButton = {
                Button(onClick = {
                    showExactAlarmRationale = false
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        runCatching { context.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)) }
                    }
                }) { Text("Open Android Settings") }
            },
            dismissButton = {
                TextButton(onClick = { showExactAlarmRationale = false }) { Text("Use WorkManager Instead") }
            }
        )
    }
}
