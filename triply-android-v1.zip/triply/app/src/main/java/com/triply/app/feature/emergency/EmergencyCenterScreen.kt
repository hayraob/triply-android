package com.triply.app.feature.emergency

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Call
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Navigation
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.triply.app.core.data.TriplyRepository
import com.triply.app.core.database.EmergencyContactEntity
import com.triply.app.core.designsystem.EmptyStateView
import com.triply.app.core.designsystem.StatusPill
import com.triply.app.core.designsystem.TriplyCard
import com.triply.app.core.designsystem.TriplyColors
import com.triply.app.core.designsystem.TriplySpacing
import kotlinx.coroutines.launch
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EmergencyCenterScreen(
    repository: TriplyRepository,
    tripId: String,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val contacts by repository.observeEmergencyContacts(tripId).collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var showAddDialog by remember { mutableStateOf(false) }
    var copiedNotice by remember { mutableStateOf<String?>(null) }

    Scaffold(
        containerColor = TriplyColors.Background,
        topBar = {
            TopAppBar(
                title = { Text("Emergency Center") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { showAddDialog = true }) {
                        Icon(Icons.Outlined.Add, contentDescription = "Add emergency contact")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = TriplyColors.Surface)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(TriplySpacing.Lg),
            verticalArrangement = Arrangement.spacedBy(TriplySpacing.Md)
        ) {
            TriplyCard(containerColor = TriplyColors.Danger.copy(alpha = 0.12f)) {
                Text("Offline Emergency Reference", style = MaterialTheme.typography.titleMedium, color = TriplyColors.Danger)
                Text(
                    "All contacts, basecamps, hospitals, and coordinates stored here remain readable offline. Triply does NOT automatically transmit SOS messages or share live GPS location.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            copiedNotice?.let { Text(it, color = TriplyColors.Success, style = MaterialTheme.typography.labelMedium) }

            if (contacts.isEmpty()) {
                EmptyStateView(
                    title = "No emergency details saved",
                    message = "Save family contacts, basecamp phone numbers, verified local emergency numbers, and nearby hospitals before going offline.",
                    actionLabel = "Add Contact / Place",
                    onAction = { showAddDialog = true }
                )
            } else {
                contacts.forEach { c ->
                    TriplyCard {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(c.name, style = MaterialTheme.typography.titleMedium)
                                StatusPill(c.relationOrCategory, TriplyColors.Danger)
                                if (c.phoneNumber.isNotBlank()) Text("Phone: ${c.phoneNumber}", style = MaterialTheme.typography.bodyMedium)
                                if (c.address.isNotBlank()) Text("Address: ${c.address}", style = MaterialTheme.typography.bodyMedium)
                                if (c.latitude != null && c.longitude != null) {
                                    Text("Coordinates: %.5f, %.5f".format(c.latitude, c.longitude), style = MaterialTheme.typography.labelMedium)
                                }
                            }
                            IconButton(onClick = { scope.launch { repository.deleteEmergencyContact(c.id) } }) {
                                Icon(Icons.Outlined.Delete, contentDescription = "Delete", tint = TriplyColors.Danger)
                            }
                        }
                        Spacer(Modifier.height(TriplySpacing.Xs))
                        Row(horizontalArrangement = Arrangement.spacedBy(TriplySpacing.Sm)) {
                            if (c.phoneNumber.isNotBlank()) {
                                Button(onClick = {
                                    runCatching {
                                        context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${c.phoneNumber}")))
                                    }
                                }) {
                                    Icon(Icons.Outlined.Call, contentDescription = null)
                                    Text(" Call")
                                }
                            }
                            if (c.latitude != null && c.longitude != null) {
                                Button(onClick = {
                                    val geo = Uri.parse("geo:${c.latitude},${c.longitude}?q=${c.latitude},${c.longitude}(${Uri.encode(c.name)})")
                                    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, geo)) }
                                }) {
                                    Icon(Icons.Outlined.Navigation, contentDescription = null)
                                    Text(" Map")
                                }
                            }
                            TextButton(onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val text = buildString {
                                    append("${c.name} (${c.relationOrCategory})")
                                    if (c.phoneNumber.isNotBlank()) append(" | Tel: ${c.phoneNumber}")
                                    if (c.latitude != null && c.longitude != null) append(" | Coord: ${c.latitude}, ${c.longitude}")
                                }
                                clipboard.setPrimaryClip(ClipData.newPlainText("Emergency Details", text))
                                copiedNotice = "Copied '${c.name}' details to clipboard."
                            }) {
                                Icon(Icons.Outlined.ContentCopy, contentDescription = null)
                                Text(" Copy")
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        var name by remember { mutableStateOf("") }
        var category by remember { mutableStateOf("Emergency Contact") }
        var phone by remember { mutableStateOf("") }
        var address by remember { mutableStateOf("") }
        var lat by remember { mutableStateOf("") }
        var lon by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            containerColor = TriplyColors.Surface,
            title = { Text("Add Emergency Contact / Place") },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(TriplySpacing.Xs)) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name *") }, singleLine = true)
                    OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text("Type (Family, Basecamp, Hospital, Official)") }, singleLine = true)
                    OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Phone Number") }, singleLine = true)
                    OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("Address / Notes") })
                    OutlinedTextField(value = lat, onValueChange = { lat = it }, label = { Text("Latitude (optional)") }, singleLine = true)
                    OutlinedTextField(value = lon, onValueChange = { lon = it }, label = { Text("Longitude (optional)") }, singleLine = true)
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (name.isNotBlank()) {
                        scope.launch {
                            repository.saveEmergencyContact(
                                EmergencyContactEntity(
                                    id = UUID.randomUUID().toString(),
                                    tripId = tripId,
                                    name = name.trim(),
                                    relationOrCategory = category.trim().ifBlank { "Emergency" },
                                    phoneNumber = phone.trim(),
                                    address = address.trim(),
                                    latitude = lat.toDoubleOrNull(),
                                    longitude = lon.toDoubleOrNull()
                                )
                            )
                            showAddDialog = false
                        }
                    }
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showAddDialog = false }) { Text("Cancel") } }
        )
    }
}
