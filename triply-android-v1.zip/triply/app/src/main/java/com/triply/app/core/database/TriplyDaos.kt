package com.triply.app.core.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface TripDao {
    @Query("SELECT * FROM trips WHERE isTemplate = 0 ORDER BY startDateIso ASC")
    fun observeTrips(): Flow<List<TripEntity>>

    @Query("SELECT * FROM trips WHERE isTemplate = 1 ORDER BY name ASC")
    fun observeTemplates(): Flow<List<TripEntity>>

    @Query("SELECT * FROM trips WHERE id = :tripId")
    fun observeTrip(tripId: String): Flow<TripEntity?>

    @Query("SELECT * FROM trips WHERE id = :tripId")
    suspend fun getTrip(tripId: String): TripEntity?

    @Query("SELECT * FROM trips")
    suspend fun getAllTripsOnce(): List<TripEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTrip(trip: TripEntity)

    @Query("DELETE FROM trips WHERE id = :tripId")
    suspend fun deleteTrip(tripId: String)

    @Query("DELETE FROM trips")
    suspend fun deleteAllTrips()
}

@Dao
interface BlockAndDestinationDao {
    @Query("SELECT * FROM trip_blocks WHERE tripId = :tripId ORDER BY orderIndex ASC")
    fun observeBlocks(tripId: String): Flow<List<TripBlockEntity>>

    @Query("SELECT * FROM trip_blocks WHERE tripId = :tripId ORDER BY orderIndex ASC")
    suspend fun getBlocksOnce(tripId: String): List<TripBlockEntity>

    @Query("SELECT * FROM trip_blocks")
    suspend fun getAllBlocksOnce(): List<TripBlockEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertBlock(block: TripBlockEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertBlocks(blocks: List<TripBlockEntity>)

    @Query("DELETE FROM trip_blocks WHERE id = :blockId")
    suspend fun deleteBlock(blockId: String)

    @Query("DELETE FROM trip_blocks WHERE tripId = :tripId")
    suspend fun deleteBlocksForTrip(tripId: String)

    @Query("SELECT * FROM destinations WHERE tripId = :tripId ORDER BY orderIndex ASC")
    fun observeDestinations(tripId: String): Flow<List<DestinationEntity>>

    @Query("SELECT * FROM destinations WHERE tripId = :tripId ORDER BY orderIndex ASC")
    suspend fun getDestinationsOnce(tripId: String): List<DestinationEntity>

    @Query("SELECT * FROM destinations")
    suspend fun getAllDestinationsOnce(): List<DestinationEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertDestination(destination: DestinationEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertDestinations(destinations: List<DestinationEntity>)

    @Query("DELETE FROM destinations WHERE id = :id")
    suspend fun deleteDestination(id: String)

    @Query("SELECT * FROM saved_routes WHERE tripId = :tripId ORDER BY fetchedAtEpochMillis DESC")
    fun observeSavedRoutes(tripId: String): Flow<List<SavedRouteEntity>>

    @Query("SELECT * FROM saved_routes WHERE tripId = :tripId ORDER BY fetchedAtEpochMillis DESC")
    suspend fun getSavedRoutesOnce(tripId: String): List<SavedRouteEntity>

    @Query("SELECT * FROM saved_routes")
    suspend fun getAllSavedRoutesOnce(): List<SavedRouteEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSavedRoute(route: SavedRouteEntity)
}

@Dao
interface BudgetAndGroupDao {
    @Query("SELECT * FROM participants WHERE tripId = :tripId ORDER BY name ASC")
    fun observeParticipants(tripId: String): Flow<List<ParticipantEntity>>

    @Query("SELECT * FROM participants WHERE tripId = :tripId")
    suspend fun getParticipantsOnce(tripId: String): List<ParticipantEntity>

    @Query("SELECT * FROM participants")
    suspend fun getAllParticipantsOnce(): List<ParticipantEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertParticipant(participant: ParticipantEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertParticipants(participants: List<ParticipantEntity>)

    @Query("DELETE FROM participants WHERE id = :id")
    suspend fun deleteParticipant(id: String)

    @Query("SELECT * FROM expenses WHERE tripId = :tripId ORDER BY dateIso DESC, createdAtEpochMillis DESC")
    fun observeExpenses(tripId: String): Flow<List<ExpenseEntity>>

    @Query("SELECT * FROM expenses ORDER BY dateIso DESC, createdAtEpochMillis DESC")
    fun observeAllExpenses(): Flow<List<ExpenseEntity>>

    @Query("SELECT * FROM expenses WHERE tripId = :tripId")
    suspend fun getExpensesOnce(tripId: String): List<ExpenseEntity>

    @Query("SELECT * FROM expenses")
    suspend fun getAllExpensesOnce(): List<ExpenseEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertExpense(expense: ExpenseEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertExpenses(expenses: List<ExpenseEntity>)

    @Query("DELETE FROM expenses WHERE id = :expenseId")
    suspend fun deleteExpense(expenseId: String)

    @Query("SELECT * FROM expense_shares WHERE expenseId IN (SELECT id FROM expenses WHERE tripId = :tripId)")
    fun observeExpenseSharesForTrip(tripId: String): Flow<List<ExpenseShareEntity>>

    @Query("SELECT * FROM expense_shares WHERE expenseId = :expenseId")
    suspend fun getSharesForExpense(expenseId: String): List<ExpenseShareEntity>

    @Query("SELECT * FROM expense_shares")
    suspend fun getAllExpenseSharesOnce(): List<ExpenseShareEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertShares(shares: List<ExpenseShareEntity>)

    @Query("DELETE FROM expense_shares WHERE expenseId = :expenseId")
    suspend fun deleteSharesForExpense(expenseId: String)

    @Transaction
    suspend fun saveExpenseWithShares(expense: ExpenseEntity, shares: List<ExpenseShareEntity>) {
        upsertExpense(expense)
        deleteSharesForExpense(expense.id)
        if (shares.isNotEmpty()) upsertShares(shares)
    }

    @Query("SELECT * FROM settlements WHERE tripId = :tripId ORDER BY dateIso DESC")
    fun observeSettlements(tripId: String): Flow<List<SettlementEntity>>

    @Query("SELECT * FROM settlements WHERE tripId = :tripId")
    suspend fun getSettlementsOnce(tripId: String): List<SettlementEntity>

    @Query("SELECT * FROM settlements")
    suspend fun getAllSettlementsOnce(): List<SettlementEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSettlement(settlement: SettlementEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSettlements(settlements: List<SettlementEntity>)

    @Query("DELETE FROM settlements WHERE id = :id")
    suspend fun deleteSettlement(id: String)
}

@Dao
interface LogisticsDao {
    @Query("SELECT * FROM packing_items WHERE tripId = :tripId ORDER BY isGroupGear ASC, categoryName ASC, name ASC")
    fun observePackingItems(tripId: String): Flow<List<PackingItemEntity>>

    @Query("SELECT * FROM packing_items WHERE tripId = :tripId")
    suspend fun getPackingItemsOnce(tripId: String): List<PackingItemEntity>

    @Query("SELECT * FROM packing_items")
    suspend fun getAllPackingItemsOnce(): List<PackingItemEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPackingItem(item: PackingItemEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPackingItems(items: List<PackingItemEntity>)

    @Query("DELETE FROM packing_items WHERE id = :id")
    suspend fun deletePackingItem(id: String)

    @Query("SELECT * FROM accommodations WHERE tripId = :tripId ORDER BY checkInIso ASC")
    fun observeAccommodations(tripId: String): Flow<List<AccommodationEntity>>

    @Query("SELECT * FROM accommodations WHERE tripId = :tripId")
    suspend fun getAccommodationsOnce(tripId: String): List<AccommodationEntity>

    @Query("SELECT * FROM accommodations")
    suspend fun getAllAccommodationsOnce(): List<AccommodationEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAccommodation(item: AccommodationEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAccommodations(items: List<AccommodationEntity>)

    @Query("DELETE FROM accommodations WHERE id = :id")
    suspend fun deleteAccommodation(id: String)

    @Query("SELECT * FROM transport_plans WHERE tripId = :tripId")
    fun observeTransportPlans(tripId: String): Flow<List<TransportPlanEntity>>

    @Query("SELECT * FROM transport_plans WHERE tripId = :tripId")
    suspend fun getTransportPlansOnce(tripId: String): List<TransportPlanEntity>

    @Query("SELECT * FROM transport_plans")
    suspend fun getAllTransportPlansOnce(): List<TransportPlanEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTransportPlan(plan: TransportPlanEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTransportPlans(plans: List<TransportPlanEntity>)

    @Query("DELETE FROM transport_plans WHERE id = :id")
    suspend fun deleteTransportPlan(id: String)
}

@Dao
interface SafetyAndJournalDao {
    @Query("SELECT * FROM reminders WHERE tripId = :tripId AND isCancelled = 0 ORDER BY triggerAtEpochMillis ASC")
    fun observeRemindersForTrip(tripId: String): Flow<List<ReminderEntity>>

    @Query("SELECT * FROM reminders WHERE isCancelled = 0 AND isCompleted = 0 ORDER BY triggerAtEpochMillis ASC")
    fun observeUpcomingReminders(): Flow<List<ReminderEntity>>

    @Query("SELECT * FROM reminders WHERE isCancelled = 0 AND isCompleted = 0")
    suspend fun getActiveRemindersOnce(): List<ReminderEntity>

    @Query("SELECT * FROM reminders WHERE tripId = :tripId")
    suspend fun getRemindersOnce(tripId: String): List<ReminderEntity>

    @Query("SELECT * FROM reminders")
    suspend fun getAllRemindersOnce(): List<ReminderEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertReminder(reminder: ReminderEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertReminders(reminders: List<ReminderEntity>)

    @Query("DELETE FROM reminders WHERE id = :id")
    suspend fun deleteReminder(id: String)

    @Query("SELECT * FROM weather_cache WHERE tripId = :tripId ORDER BY fetchedAtEpochMillis DESC")
    fun observeWeatherForTrip(tripId: String): Flow<List<WeatherCacheEntity>>

    @Query("SELECT * FROM weather_cache WHERE tripId = :tripId")
    suspend fun getWeatherOnce(tripId: String): List<WeatherCacheEntity>

    @Query("SELECT * FROM weather_cache")
    suspend fun getAllWeatherOnce(): List<WeatherCacheEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertWeather(weather: WeatherCacheEntity)

    @Query("SELECT * FROM emergency_contacts WHERE tripId = :tripId ORDER BY relationOrCategory ASC, name ASC")
    fun observeEmergencyContacts(tripId: String): Flow<List<EmergencyContactEntity>>

    @Query("SELECT * FROM emergency_contacts WHERE tripId = :tripId")
    suspend fun getEmergencyContactsOnce(tripId: String): List<EmergencyContactEntity>

    @Query("SELECT * FROM emergency_contacts")
    suspend fun getAllEmergencyContactsOnce(): List<EmergencyContactEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertEmergencyContact(contact: EmergencyContactEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertEmergencyContacts(contacts: List<EmergencyContactEntity>)

    @Query("DELETE FROM emergency_contacts WHERE id = :id")
    suspend fun deleteEmergencyContact(id: String)

    @Query("SELECT * FROM journal_entries WHERE tripId = :tripId ORDER BY dayNumber ASC, createdAtEpochMillis DESC")
    fun observeJournalEntries(tripId: String): Flow<List<JournalEntryEntity>>

    @Query("SELECT * FROM journal_entries WHERE tripId = :tripId")
    suspend fun getJournalEntriesOnce(tripId: String): List<JournalEntryEntity>

    @Query("SELECT * FROM journal_entries")
    suspend fun getAllJournalEntriesOnce(): List<JournalEntryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertJournalEntry(entry: JournalEntryEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertJournalEntries(entries: List<JournalEntryEntity>)

    @Query("DELETE FROM journal_entries WHERE id = :id")
    suspend fun deleteJournalEntry(id: String)

    @Query("SELECT * FROM offline_map_regions ORDER BY updatedAtEpochMillis DESC")
    fun observeOfflineRegions(): Flow<List<OfflineMapRegionEntity>>

    @Query("SELECT * FROM offline_map_regions")
    suspend fun getAllOfflineRegionsOnce(): List<OfflineMapRegionEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertOfflineRegion(region: OfflineMapRegionEntity)

    @Query("DELETE FROM offline_map_regions WHERE id = :id")
    suspend fun deleteOfflineRegion(id: String)

    @Query("SELECT * FROM what_if_scenarios WHERE tripId = :tripId ORDER BY updatedAtEpochMillis DESC")
    fun observeWhatIfScenarios(tripId: String): Flow<List<WhatIfScenarioEntity>>

    @Query("SELECT * FROM what_if_scenarios WHERE tripId = :tripId")
    suspend fun getWhatIfScenariosOnce(tripId: String): List<WhatIfScenarioEntity>

    @Query("SELECT * FROM what_if_scenarios")
    suspend fun getAllWhatIfScenariosOnce(): List<WhatIfScenarioEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertWhatIfScenario(scenario: WhatIfScenarioEntity)

    @Query("DELETE FROM what_if_scenarios WHERE id = :id")
    suspend fun deleteWhatIfScenario(id: String)
}
