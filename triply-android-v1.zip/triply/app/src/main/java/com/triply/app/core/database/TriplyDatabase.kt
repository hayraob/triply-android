package com.triply.app.core.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        TripEntity::class,
        DestinationEntity::class,
        TripBlockEntity::class,
        SavedRouteEntity::class,
        ParticipantEntity::class,
        ExpenseEntity::class,
        ExpenseShareEntity::class,
        SettlementEntity::class,
        PackingItemEntity::class,
        AccommodationEntity::class,
        TransportPlanEntity::class,
        ReminderEntity::class,
        WeatherCacheEntity::class,
        EmergencyContactEntity::class,
        JournalEntryEntity::class,
        OfflineMapRegionEntity::class,
        WhatIfScenarioEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class TriplyDatabase : RoomDatabase() {
    abstract fun tripDao(): TripDao
    abstract fun blockAndDestinationDao(): BlockAndDestinationDao
    abstract fun budgetAndGroupDao(): BudgetAndGroupDao
    abstract fun logisticsDao(): LogisticsDao
    abstract fun safetyAndJournalDao(): SafetyAndJournalDao

    companion object {
        const val DATABASE_NAME = "triply_local.db"

        @Volatile
        private var INSTANCE: TriplyDatabase? = null

        fun getInstance(context: Context): TriplyDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    TriplyDatabase::class.java,
                    DATABASE_NAME
                ).build().also { INSTANCE = it }
            }
        }
    }
}
