package com.triply.app.core.designsystem

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object TriplyColors {
    val Background = Color(0xFF0B0D12)
    val Surface = Color(0xFF151922)
    val SurfaceSecondary = Color(0xFF1D2430)
    val Border = Color(0xFF283142)
    val TextPrimary = Color(0xFFF4F6FA)
    val TextSecondary = Color(0xFF929BAA)
    val Accent = Color(0xFF8B7CFF)
    val Success = Color(0xFF35C98A)
    val Warning = Color(0xFFF5B94C)
    val Danger = Color(0xFFF16D75)
}

object TriplySpacing {
    val Xs = 4.dp
    val Sm = 8.dp
    val Md = 12.dp
    val Lg = 16.dp
    val Xl = 24.dp
}

private val TriplyDarkScheme = darkColorScheme(
    primary = TriplyColors.Accent,
    onPrimary = TriplyColors.Background,
    secondary = TriplyColors.Success,
    onSecondary = TriplyColors.Background,
    tertiary = TriplyColors.Warning,
    background = TriplyColors.Background,
    onBackground = TriplyColors.TextPrimary,
    surface = TriplyColors.Surface,
    onSurface = TriplyColors.TextPrimary,
    surfaceVariant = TriplyColors.SurfaceSecondary,
    onSurfaceVariant = TriplyColors.TextSecondary,
    outline = TriplyColors.Border,
    error = TriplyColors.Danger,
    onError = TriplyColors.Background
)

private val TriplyTypography = Typography(
    headlineMedium = TextStyle(fontSize = 24.sp, lineHeight = 30.sp, fontWeight = FontWeight.SemiBold, color = TriplyColors.TextPrimary),
    titleLarge = TextStyle(fontSize = 20.sp, lineHeight = 26.sp, fontWeight = FontWeight.SemiBold, color = TriplyColors.TextPrimary),
    titleMedium = TextStyle(fontSize = 16.sp, lineHeight = 22.sp, fontWeight = FontWeight.SemiBold, color = TriplyColors.TextPrimary),
    bodyLarge = TextStyle(fontSize = 15.sp, lineHeight = 22.sp, fontWeight = FontWeight.Normal, color = TriplyColors.TextPrimary),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.Normal, color = TriplyColors.TextSecondary),
    labelLarge = TextStyle(fontSize = 14.sp, lineHeight = 18.sp, fontWeight = FontWeight.Medium, color = TriplyColors.TextPrimary),
    labelMedium = TextStyle(fontSize = 12.sp, lineHeight = 16.sp, fontWeight = FontWeight.Medium, color = TriplyColors.TextSecondary)
)

@Composable
fun TriplyTheme(content: @Composable () -> Unit) {
    // Dark mode only for V1 (locked product decision)
    MaterialTheme(
        colorScheme = TriplyDarkScheme,
        typography = TriplyTypography,
        content = content
    )
}
