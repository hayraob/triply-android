package com.triply.app.core.data.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.util.concurrent.TimeUnit

@Serializable
data class DailyForecastDay(
    val dateIso: String,
    val weatherCode: Int,
    val tempMaxC: Double,
    val tempMinC: Double,
    val precipitationSumMm: Double
)

@Serializable
data class HourlyForecastPoint(
    val timeIso: String,
    val tempC: Double,
    val precipitationProbPercent: Int,
    val weatherCode: Int
)

@Serializable
data class ParsedWeatherForecast(
    val timezone: String,
    val daily: List<DailyForecastDay>,
    val hourlyNext24h: List<HourlyForecastPoint>
)

@Serializable
data class GeocodedPlace(
    val name: String,
    val admin1: String = "",
    val country: String = "",
    val latitude: Double,
    val longitude: Double
) {
    val displayLabel: String
        get() = listOf(name, admin1, country).filter { it.isNotBlank() }.joinToString(", ")
}

sealed interface WeatherOutcome {
    data class Success(val forecastJson: String, val forecast: ParsedWeatherForecast, val providerLabel: String) : WeatherOutcome
    data class Error(val message: String) : WeatherOutcome
}

sealed interface GeocodeOutcome {
    data class Success(val places: List<GeocodedPlace>) : GeocodeOutcome
    data class Error(val message: String) : GeocodeOutcome
}

/**
 * Open-Meteo API client (Weather + Geocoding).
 * Non-commercial free endpoint: <10,000 calls/day, CC-BY 4.0.
 * Commercial use requires a paid Open-Meteo customer API key configured in Settings.
 */
class OpenMeteoClient(
    private val apiKeyProvider: suspend () -> String,
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()
) {
    private val json = Json { ignoreUnknownKeys = true }

    suspend fun fetchForecast(latitude: Double, longitude: Double): WeatherOutcome = withContext(Dispatchers.IO) {
        val key = apiKeyProvider().trim()
        val baseHost = if (key.isNotBlank()) "https://customer-api.open-meteo.com/v1/forecast" else "https://api.open-meteo.com/v1/forecast"
        val urlBuilder = baseHost.toHttpUrl().newBuilder()
            .addQueryParameter("latitude", latitude.toString())
            .addQueryParameter("longitude", longitude.toString())
            .addQueryParameter("daily", "weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum")
            .addQueryParameter("hourly", "temperature_2m,precipitation_probability,weather_code")
            .addQueryParameter("forecast_days", "7")
            .addQueryParameter("timezone", "auto")
        if (key.isNotBlank()) urlBuilder.addQueryParameter("apikey", key)

        val request = Request.Builder().url(urlBuilder.build()).get().build()
        try {
            client.newCall(request).execute().use { response ->
                if (response.code == 429) {
                    return@withContext WeatherOutcome.Error("Open-Meteo quota limit reached (HTTP 429). Showing cached forecast if available.")
                }
                if (!response.isSuccessful) {
                    return@withContext WeatherOutcome.Error("Weather service unavailable (HTTP ${response.code}).")
                }
                val body = response.body?.string().orEmpty()
                val root = json.parseToJsonElement(body).jsonObject
                val tz = root["timezone"]?.jsonPrimitive?.content ?: "UTC"
                val dailyObj = root["daily"]?.jsonObject
                val times = dailyObj?.get("time")?.jsonArray.orEmpty()
                val codes = dailyObj?.get("weather_code")?.jsonArray.orEmpty()
                val maxTemps = dailyObj?.get("temperature_2m_max")?.jsonArray.orEmpty()
                val minTemps = dailyObj?.get("temperature_2m_min")?.jsonArray.orEmpty()
                val precip = dailyObj?.get("precipitation_sum")?.jsonArray.orEmpty()

                val dailyList = times.indices.map { i ->
                    DailyForecastDay(
                        dateIso = times[i].jsonPrimitive.content,
                        weatherCode = codes.getOrNull(i)?.jsonPrimitive?.intOrNull ?: 0,
                        tempMaxC = maxTemps.getOrNull(i)?.jsonPrimitive?.doubleOrNull ?: 0.0,
                        tempMinC = minTemps.getOrNull(i)?.jsonPrimitive?.doubleOrNull ?: 0.0,
                        precipitationSumMm = precip.getOrNull(i)?.jsonPrimitive?.doubleOrNull ?: 0.0
                    )
                }

                val hourlyObj = root["hourly"]?.jsonObject
                val hTimes = hourlyObj?.get("time")?.jsonArray.orEmpty()
                val hTemps = hourlyObj?.get("temperature_2m")?.jsonArray.orEmpty()
                val hProbs = hourlyObj?.get("precipitation_probability")?.jsonArray.orEmpty()
                val hCodes = hourlyObj?.get("weather_code")?.jsonArray.orEmpty()

                val hourlyList = hTimes.indices.take(24).map { i ->
                    HourlyForecastPoint(
                        timeIso = hTimes[i].jsonPrimitive.content,
                        tempC = hTemps.getOrNull(i)?.jsonPrimitive?.doubleOrNull ?: 0.0,
                        precipitationProbPercent = hProbs.getOrNull(i)?.jsonPrimitive?.intOrNull ?: 0,
                        weatherCode = hCodes.getOrNull(i)?.jsonPrimitive?.intOrNull ?: 0
                    )
                }

                val parsed = ParsedWeatherForecast(tz, dailyList, hourlyList)
                WeatherOutcome.Success(
                    forecastJson = json.encodeToString(parsed),
                    forecast = parsed,
                    providerLabel = if (key.isNotBlank()) "Open-Meteo (Commercial)" else "Open-Meteo (Non-Commercial)"
                )
            }
        } catch (e: IOException) {
            WeatherOutcome.Error("Network error while fetching weather: ${e.localizedMessage ?: "offline or timeout"}")
        } catch (e: Exception) {
            WeatherOutcome.Error("Weather data could not be parsed: ${e.localizedMessage ?: "malformed response"}")
        }
    }

    suspend fun searchPlaces(query: String): GeocodeOutcome = withContext(Dispatchers.IO) {
        val trimmed = query.trim()
        if (trimmed.length < 2) return@withContext GeocodeOutcome.Success(emptyList())
        val url = "https://geocoding-api.open-meteo.com/v1/search".toHttpUrl().newBuilder()
            .addQueryParameter("name", trimmed)
            .addQueryParameter("count", "8")
            .addQueryParameter("language", "en")
            .addQueryParameter("format", "json")
            .build()

        val request = Request.Builder().url(url).get().build()
        try {
            client.newCall(request).execute().use { response ->
                if (response.code == 429) {
                    return@withContext GeocodeOutcome.Error("Search rate limit reached. Please wait a moment.")
                }
                if (!response.isSuccessful) {
                    return@withContext GeocodeOutcome.Error("Place search failed (HTTP ${response.code}).")
                }
                val body = response.body?.string().orEmpty()
                val root = json.parseToJsonElement(body).jsonObject
                val results = root["results"]?.jsonArray.orEmpty().mapNotNull { el ->
                    val obj = el.jsonObject
                    val lat = obj["latitude"]?.jsonPrimitive?.doubleOrNull ?: return@mapNotNull null
                    val lon = obj["longitude"]?.jsonPrimitive?.doubleOrNull ?: return@mapNotNull null
                    val name = obj["name"]?.jsonPrimitive?.content ?: return@mapNotNull null
                    GeocodedPlace(
                        name = name,
                        admin1 = obj["admin1"]?.jsonPrimitive?.content.orEmpty(),
                        country = obj["country"]?.jsonPrimitive?.content.orEmpty(),
                        latitude = lat,
                        longitude = lon
                    )
                }
                GeocodeOutcome.Success(results)
            }
        } catch (e: IOException) {
            GeocodeOutcome.Error("Offline or network timeout during place search.")
        } catch (e: Exception) {
            GeocodeOutcome.Error("Unable to read search results.")
        }
    }

    companion object {
        fun describeWmoCode(code: Int): String = when (code) {
            0 -> "Clear sky"
            1, 2, 3 -> "Partly cloudy"
            45, 48 -> "Fog"
            51, 53, 55 -> "Drizzle"
            61, 63, 65 -> "Rain"
            71, 73, 75 -> "Snow"
            80, 81, 82 -> "Rain showers"
            95, 96, 99 -> "Thunderstorm"
            else -> "Code $code"
        }
    }
}
