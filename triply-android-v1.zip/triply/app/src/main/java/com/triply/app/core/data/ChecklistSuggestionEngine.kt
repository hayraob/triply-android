package com.triply.app.core.data

import com.triply.app.core.database.ActivityCategory
import com.triply.app.core.database.GearOwnershipStatus
import com.triply.app.core.database.PackingItemEntity
import java.util.UUID

object ChecklistSuggestionEngine {

    data class SuggestedItem(
        val name: String,
        val category: String,
        val isGroupGear: Boolean
    )

    fun suggestionsForCategories(categories: Set<ActivityCategory>): List<SuggestedItem> {
        val list = mutableListOf(
            SuggestedItem("ID / Passport & Emergency Card", "Documents", false),
            SuggestedItem("Power Bank & Charging Cables", "Electronics", false),
            SuggestedItem("Personal First Aid & Medications", "Safety", false),
            SuggestedItem("Reusable Water Bottle", "Essentials", false)
        )
        if (ActivityCategory.HIKING in categories) {
            list += listOf(
                SuggestedItem("Hiking Boots & Wool Socks", "Hiking Gear", false),
                SuggestedItem("Headlamp + Spare Batteries", "Hiking Gear", false),
                SuggestedItem("Rain Jacket / Poncho", "Hiking Gear", false),
                SuggestedItem("Sleeping Bag & Thermal Layer", "Hiking Gear", false),
                SuggestedItem("Trekking Poles", "Hiking Gear", false),
                SuggestedItem("Group Tent & Flysheet", "Group Equipment", true),
                SuggestedItem("Portable Stove & Fuel Canisters", "Group Equipment", true),
                SuggestedItem("Group First Aid Kit & Navigation Map", "Group Equipment", true),
                SuggestedItem("Basecamp Registration & Trail Permits", "Logistics", true)
            )
        }
        if (ActivityCategory.BEACH in categories) {
            list += listOf(
                SuggestedItem("Swimwear & Quick-Dry Towel", "Beach", false),
                SuggestedItem("Reef-Safe Sunscreen & Sunglasses", "Beach", false),
                SuggestedItem("Dry Bag for Electronics", "Beach", false),
                SuggestedItem("Sandals / Water Shoes", "Beach", false)
            )
        }
        if (ActivityCategory.CAMPING in categories) {
            list += listOf(
                SuggestedItem("Sleeping Pad / Mat", "Camping", false),
                SuggestedItem("Camp Lantern", "Group Equipment", true),
                SuggestedItem("Cookset & Utensils", "Group Equipment", true),
                SuggestedItem("Trash Bags (Leave No Trace)", "Group Equipment", true)
            )
        }
        if (ActivityCategory.ROAD_TRIP in categories) {
            list += listOf(
                SuggestedItem("Driver License & Vehicle Registration", "Vehicle", false),
                SuggestedItem("Car/Bike Phone Mount & Charger", "Vehicle", false),
                SuggestedItem("Tire Repair Kit & Jumper Cables", "Group Equipment", true),
                SuggestedItem("E-Toll / Highway Card", "Vehicle", true)
            )
        }
        if (ActivityCategory.CITY in categories) {
            list += listOf(
                SuggestedItem("Comfortable Walking Shoes", "City", false),
                SuggestedItem("Daypack / Crossbody Bag", "City", false),
                SuggestedItem("Compact Umbrella", "City", false)
            )
        }
        if (ActivityCategory.FAMILY in categories) {
            list += listOf(
                SuggestedItem("Snacks & Travel Entertainment", "Family", true),
                SuggestedItem("Wet Wipes & Extra Clothes", "Family", true)
            )
        }
        if (ActivityCategory.BACKPACKING in categories) {
            list += listOf(
                SuggestedItem("40-55L Travel Backpack & Rain Cover", "Backpacking", false),
                SuggestedItem("Padlock for Hostel Lockers", "Backpacking", false),
                SuggestedItem("Microfiber Travel Towel", "Backpacking", false)
            )
        }
        return list.distinctBy { it.name }
    }

    /**
     * Merges suggestions into existing checklist WITHOUT overwriting or duplicating existing items.
     */
    fun buildNonDestructiveAdditions(
        tripId: String,
        existingItems: List<PackingItemEntity>,
        categories: Set<ActivityCategory>
    ): List<PackingItemEntity> {
        val existingNames = existingItems.map { it.name.trim().lowercase() }.toSet()
        return suggestionsForCategories(categories)
            .filter { it.name.trim().lowercase() !in existingNames }
            .map { s ->
                PackingItemEntity(
                    id = UUID.randomUUID().toString(),
                    tripId = tripId,
                    name = s.name,
                    categoryName = s.category,
                    isGroupGear = s.isGroupGear,
                    ownershipStatus = GearOwnershipStatus.OWNED.name,
                    quantity = 1
                )
            }
    }
}
