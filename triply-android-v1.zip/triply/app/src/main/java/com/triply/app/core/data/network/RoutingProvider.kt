package com.triply.app.core.data.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.double
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.util.concurrent.TimeUnit

enum class RoutingProfile(val label: String, val orsProfileId: String?, val note: String? = null) {
    CAR("Car (driving-car)", "driving-car"),
    CYCLING("Bicycle (cycling-regular)", "cycling-regular"),
    WALKING("Walking (foot-walking)", "foot-walking"),
    HIKING("Hiking (foot-hiking)", "foot-hiking"),
    MOTORCYCLE(
        "Motorcycle (Unavailable in ORS)",
        null,
        "OpenRouteService does not provide a dedicated motorcycle profile. You may optionally request a car route as an approximate alternative, clearly labelled as a car estimate."
    )
}

@Serializable
data class GeoPoint(val latitude: Double, val longitude: Double)

data class RouteCalculationResult(
    val providerName: String,
    val profileName: String,
    val isApproximateAlternative: Boolean,
    val approximationNote: String,
    val totalDistanceMeters: Double,
    val totalDurationSeconds: Double,
    val includesLiveTraffic: Boolean,
    val polyline: List<GeoPoint>
)

sealed interface RoutingOutcome {
    data class Success(val result: RouteCalculationResult) : RoutingOutcome
    data class ApiNotConfigured(val message: String) : RoutingOutcome
    data class ProfileUnsupported(val message: String) : RoutingOutcome
    data class Error(val message: String) : RoutingOutcome
}

interface RoutingProvider {
    suspend fun calculateRoute(
        waypoints: List<GeoPoint>,
        profile: RoutingProfile,
        allowCarApproximationForMotorcycle: Boolean = false
    ): RoutingOutcome
}

class OpenRouteServiceRoutingProvider(
    private val apiKeyProvider: suspend () -> String,
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()
) : RoutingProvider {

    private val json = Json { ignoreUnknownKeys = true }

    override suspend fun calculateRoute(
        waypoints: List<GeoPoint>,
        profile: RoutingProfile,
        allowCarApproximationForMotorcycle: Boolean
    ): RoutingOutcome = withContext(Dispatchers.IO) {
        if (waypoints.size < 2) {
            return@withContext RoutingOutcome.Error("Add at least 2 destinations with coordinates to calculate a route.")
        }
        val apiKey = apiKeyProvider().trim()
        if (apiKey.isBlank()) {
            return@withContext RoutingOutcome.ApiNotConfigured(
                "OpenRouteService API key is not configured. Add your key in Profile > Map & API Settings to calculate live routes."
            )
        }

        val effectiveProfileId: String
        val isApprox: Boolean
        val approxNote: String

        if (profile == RoutingProfile.MOTORCYCLE) {
            if (!allowCarApproximationForMotorcycle) {
                return@withContext RoutingOutcome.ProfileUnsupported(
                    profile.note ?: "Motorcycle routing is unavailable on OpenRouteService."
                )
            }
            effectiveProfileId = "driving-car"
            isApprox = true
            approxNote = "Approximate alternative using driving-car profile (dedicated motorcycle routing is unavailable on OpenRouteService). Does not include live traffic."
        } else {
            effectiveProfileId = profile.orsProfileId
                ?: return@withContext RoutingOutcome.ProfileUnsupported("Profile ${profile.label} is not supported.")
            isApprox = false
            approxNote = "Route estimate does not include live traffic and may vary with road conditions, weather, or closures."
        }

        val coordsArray = JsonArray(
            waypoints.map { pt ->
                JsonArray(listOf(kotlinx.serialization.json.JsonPrimitive(pt.longitude), kotlinx.serialization.json.JsonPrimitive(pt.latitude)))
            }
        )
        val payload = buildJsonObject {
            put("coordinates", coordsArray)
        }.toString()

        val request = Request.Builder()
            .url("https://api.openrouteservice.org/v2/directions/$effectiveProfileId/geojson")
            .header("Authorization", apiKey)
            .header("Content-Type", "application/json")
            .post(payload.toRequestBody("application/json".toMediaType()))
            .build()

        try {
            client.newCall(request).execute().use { response ->
                when (response.code) {
                    401, 403 -> return@withContext RoutingOutcome.Error("OpenRouteService rejected the API key (HTTP ${response.code}). Check your key in Map & API Settings.")
                    429 -> return@withContext RoutingOutcome.Error("OpenRouteService rate limit or daily quota reached (HTTP 429). Please wait before refreshing.")
                }
                if (!response.isSuccessful) {
                    return@withContext RoutingOutcome.Error("Routing service returned HTTP ${response.code}.")
                }
                val body = response.body?.string().orEmpty()
                val root = json.parseToJsonElement(body).jsonObject
                val feature = root["features"]?.jsonArray?.firstOrNull()?.jsonObject
                    ?: return@withContext RoutingOutcome.Error("Routing response contained no route feature.")
                val summary = feature["properties"]?.jsonObject?.get("summary")?.jsonObject
                    ?: return@withContext RoutingOutcome.Error("Routing response missing distance/duration summary.")
                val distance = summary["distance"]?.jsonPrimitive?.double ?: 0.0
                val duration = summary["duration"]?.jsonPrimitive?.double ?: 0.0
                val coordinates = feature["geometry"]?.jsonObject?.get("coordinates")?.jsonArray.orEmpty()
                val points = coordinates.mapNotNull { el ->
                    val arr = el.jsonArray
                    if (arr.size >= 2) GeoPoint(arr[1].jsonPrimitive.double, arr[0].jsonPrimitive.double) else null
                }

                RoutingOutcome.Success(
                    RouteCalculationResult(
                        providerName = "OpenRouteService",
                        profileName = if (isApprox) "driving-car (approx. for motorcycle)" else effectiveProfileId,
                        isApproximateAlternative = isApprox,
                        approximationNote = approxNote,
                        totalDistanceMeters = distance,
                        totalDurationSeconds = duration,
                        includesLiveTraffic = false,
                        polyline = points
                    )
                )
            }
        } catch (e: IOException) {
            RoutingOutcome.Error("Network error while contacting routing service: ${e.localizedMessage ?: "offline or timeout"}")
        } catch (e: Exception) {
            RoutingOutcome.Error("Could not parse routing response: ${e.localizedMessage ?: "malformed response"}")
        }
    }
}
