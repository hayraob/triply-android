package com.triply.app.feature.itinerary

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.ArrowDownward
import androidx.compose.material.icons.outlined.ArrowUpward
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.LocalHospital
import androidx.compose.material.icons.outlined.Science
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.triply.app.core.common.MoneyMath
import com.triply.app.core.common.TripDurationCalculator
import com.triply.app.core.data.TriplyRepository
import com.triply.app.core.database.ActivityCategory
import com.triply.app.core.database.TripBlockEntity
import com.triply.app.core.database.TripEntity
import com.triply.app.core.designsystem.EmptyStateView
import com.triply.app.core.designsystem.SectionHeader
import com.triply.app.core.designsystem.StatusPill
import com.triply.app.core.designsystem.TriplyCard
import com.triply.app.core.designsystem.TriplyColors
import com.triply.app.core.designsystem.TriplySpacing
import com.triply.app.feature.budget.TripBudgetTab
import com.triply.app.feature.journal.TripJournalTab
import com.triply.app.feature.map.TripMapTab
import com.triply.app.feature.preparation.TripPreparationTab
import kotlinx.coroutines.launch
import java.time.LocalDate

private val TRIP_TABS = listOf("Overview", "Itinerary", "Map", "Budget", "Preparation", "Journal")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TripDetailScreen(
    repository: TriplyRepository,
    tripId: String,
    initialTab: Int,
    isOnline: Boolean,
    onBack: () -> Unit,
    onEditTrip: () -> Unit,
    onOpenWhatIf: () -> Unit,
    onOpenEmergency: () -> Unit,
    onOpenOfflineMaps: () -> Unit
) {
    val trip by repository.observeTrip(tripId).collectAsState(initial = null)
    val blocks by repository.observeBlocks(tripId).collectAsState(initial = emptyList())
    val expenses by repository.observeExpenses(tripId).collectAsState(initial = emptyList())
    val packing by repository.observePackingItems(tripId).collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()

    var selectedTab by rememberSaveable { mutableIntStateOf(initialTab.coerceIn(0, TRIP_TABS.lastIndex)) }
    var exportStatus by remember { mutableStateOf<String?>(null) }

    val exportTripLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val res = repository.archiveManager.exportSingleTrip(tripId, uri)
                exportStatus = res.fold(
                    onSuccess = { "Trip exported (${it.attachmentCount} attachment(s), schema v${it.schemaVersion})." },
                    onFailure = { "Export failed: ${it.localizedMessage}" }
                )
            }
        }
    }

    Scaffold(
        containerColor = TriplyColors.Background,
        topBar = {
            TopAppBar(
                title = { Text(trip?.name ?: "Trip Details") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = onEditTrip) {
                        Icon(Icons.Outlined.Edit, contentDescription = "Edit trip")
                    }
                    IconButton(onClick = {
                        val safeName = (trip?.name ?: "trip").replace(Regex("[^a-zA-Z0-9_-]"), "_")
                        exportTripLauncher.launch("triply_${safeName}.zip")
                    }) {
                        Icon(Icons.Outlined.Share, contentDescription = "Export trip package")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = TriplyColors.Surface)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                containerColor = TriplyColors.Surface,
                contentColor = TriplyColors.Accent,
                edgePadding = 8.dp
            ) {
                TRIP_TABS.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = { Text(title) }
                    )
                }
            }

            exportStatus?.let { msg ->
                Text(
                    text = msg,
                    color = TriplyColors.Success,
                    style = MaterialTheme.typography.labelMedium,
                    modifier = Modifier.padding(horizontal = TriplySpacing.Lg, vertical = TriplySpacing.Xs)
                )
            }

            when (selectedTab) {
                0 -> TripOverviewTab(
                    trip = trip,
                    blocks = blocks,
                    actualSpentMinor = expenses.sumOf { it.amountMinor },
                    packedCount = packing.count { it.isPacked },
                    totalPackingCount = packing.size,
                    onEditTrip = onEditTrip,
                    onOpenWhatIf = onOpenWhatIf,
                    onOpenEmergency = onOpenEmergency
                )
                1 -> TripItineraryTab(
                    repository = repository,
                    tripId = tripId,
                    trip = trip,
                    blocks = blocks,
                    onEditTrip = onEditTrip
                )
                2 -> TripMapTab(
                    repository = repository,
                    tripId = tripId,
                    isOnline = isOnline,
                    onOpenOfflineMaps = onOpenOfflineMaps
                )
                3 -> TripBudgetTab(
                    repository = repository,
                    tripId = tripId,
                    trip = trip
                )
                4 -> TripPreparationTab(
                    repository = repository,
                    tripId = tripId,
                    trip = trip,
                    isOnline = isOnline
                )
                5 -> TripJournalTab(
                    repository = repository,
                    tripId = tripId,
                    trip = trip,
                    blocks = blocks
                )
            }
        }
    }
}

@Composable
private fun TripOverviewTab(
    trip: TripEntity?,
    blocks: List<TripBlockEntity>,
    actualSpentMinor: Long,
    packedCount: Int,
    totalPackingCount: Int,
    onEditTrip: () -> Unit,
    onOpenWhatIf: () -> Unit,
    onOpenEmergency: () -> Unit
) {
    if (trip == null) {
        Column(Modifier.padding(TriplySpacing.Lg)) {
            EmptyStateView(title = "Trip not found", message = "This trip may have been deleted.")
        }
        return
    }
    val start = runCatching { LocalDate.parse(trip.startDateIso) }.getOrNull()
    val duration = TripDurationCalculator.calculate(
        start,
        blocks.map { TripDurationCalculator.BlockSpan(it.durationDays, it.transferDaysBefore) }
    )
    val remaining = trip.plannedBudgetMinor - actualSpentMinor

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(TriplySpacing.Lg),
        verticalArrangement = Arrangement.spacedBy(TriplySpacing.Md)
    ) {
        TriplyCard {
            Text(trip.name, style = MaterialTheme.typography.titleLarge)
            Text("${trip.startDateIso} -> ${trip.endDateIso}", style = MaterialTheme.typography.bodyMedium)
            if (trip.description.isNotBlank()) {
                Spacer(Modifier.height(TriplySpacing.Xs))
                Text(trip.description, style = MaterialTheme.typography.bodyLarge)
            }
            Spacer(Modifier.height(TriplySpacing.Sm))
            Row(horizontalArrangement = Arrangement.spacedBy(TriplySpacing.Sm)) {
                StatusPill("${duration.totalTripDays} days total", TriplyColors.Accent)
                if (duration.totalTransferDays > 0) {
                    StatusPill("${duration.totalTransferDays} transfer day(s)", TriplyColors.Warning)
                }
                StatusPill("${blocks.size} block(s)", TriplyColors.Success)
            }
        }

        TriplyCard {
            SectionHeader(title = "Trip Snapshot")
            Text("Planned Budget: ${MoneyMath.format(trip.plannedBudgetMinor, trip.currencyCode)}", style = MaterialTheme.typography.bodyLarge)
            Text("Actual Expenses: ${MoneyMath.format(actualSpentMinor, trip.currencyCode)}", style = MaterialTheme.typography.bodyLarge)
            Text(
                text = if (remaining >= 0) "Remaining: ${MoneyMath.format(remaining, trip.currencyCode)}"
                else "Over Budget by: ${MoneyMath.format(-remaining, trip.currencyCode)}",
                color = if (remaining >= 0) TriplyColors.Success else TriplyColors.Danger,
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(Modifier.height(TriplySpacing.Xs))
            Text("Packing Progress: $packedCount / $totalPackingCount items ready", style = MaterialTheme.typography.bodyMedium)
        }

        SectionHeader(title = "Planning & Safety Tools")
        Row(horizontalArrangement = Arrangement.spacedBy(TriplySpacing.Sm), modifier = Modifier.fillMaxWidth()) {
            Button(onClick = onOpenWhatIf, modifier = Modifier.weight(1f)) {
                Icon(Icons.Outlined.Science, contentDescription = null)
                Text(" What-If Planner")
            }
            OutlinedButton(onClick = onOpenEmergency, modifier = Modifier.weight(1f)) {
                Icon(Icons.Outlined.LocalHospital, contentDescription = null, tint = TriplyColors.Danger)
                Text(" Emergency")
            }
        }
        OutlinedButton(onClick = onEditTrip, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Outlined.Edit, contentDescription = null)
            Text(" Edit Trip & Activity Forms")
        }
    }
}

@Composable
private fun TripItineraryTab(
    repository: TriplyRepository,
    tripId: String,
    trip: TripEntity?,
    blocks: List<TripBlockEntity>,
    onEditTrip: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val start = trip?.let { runCatching { LocalDate.parse(it.startDateIso) }.getOrNull() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(TriplySpacing.Lg),
        verticalArrangement = Arrangement.spacedBy(TriplySpacing.Md)
    ) {
        SectionHeader(
            title = "Itinerary Order",
            subtitle = "Reorder, duplicate, or remove blocks. Trip duration and transfer days recalculate automatically.",
            actionLabel = "Edit Blocks",
            onActionClick = onEditTrip
        )

        if (blocks.isEmpty()) {
            EmptyStateView(
                title = "No itinerary blocks yet",
                message = "Add activity blocks (Hiking, Beach, City, Road Trip, etc.) in the Trip Builder.",
                actionLabel = "Add Blocks",
                onAction = onEditTrip
            )
        } else {
            var dayCursor = 1
            blocks.forEachIndexed { index, block ->
                if (block.transferDaysBefore > 0) {
                    val tEnd = dayCursor + block.transferDaysBefore - 1
                    TriplyCard(containerColor = TriplyColors.SurfaceSecondary) {
                        Text(
                            text = "Day $dayCursor${if (tEnd > dayCursor) "–$tEnd" else ""}: Travel / Transfer",
                            style = MaterialTheme.typography.labelLarge,
                            color = TriplyColors.Warning
                        )
                        if (block.transferNotes.isNotBlank()) {
                            Text(block.transferNotes, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                    dayCursor = tEnd + 1
                }

                val bStart = dayCursor
                val bEnd = dayCursor + block.durationDays.coerceAtLeast(1) - 1
                val dateRange = if (start != null) {
                    "${start.plusDays((bStart - 1).toLong())} -> ${start.plusDays((bEnd - 1).toLong())}"
                } else ""
                dayCursor = bEnd + 1

                val catLabel = runCatching { ActivityCategory.valueOf(block.category).label }.getOrDefault(block.category)

                TriplyCard {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Day $bStart${if (bEnd > bStart) "–$bEnd" else ""} • ${block.title}", style = MaterialTheme.typography.titleMedium)
                            if (block.destinationName.isNotBlank()) {
                                Text("Destination: ${block.destinationName}", style = MaterialTheme.typography.bodyMedium)
                            }
                            if (dateRange.isNotBlank()) {
                                Text(dateRange, style = MaterialTheme.typography.labelMedium)
                            }
                        }
                        StatusPill(catLabel, TriplyColors.Accent)
                    }
                    if (block.estimatedCostMinor > 0L) {
                        Spacer(Modifier.height(TriplySpacing.Xs))
                        Text("Estimated cost: ${MoneyMath.format(block.estimatedCostMinor)}", style = MaterialTheme.typography.labelMedium)
                    }
                    if (block.notes.isNotBlank()) {
                        Spacer(Modifier.height(TriplySpacing.Xs))
                        Text(block.notes, style = MaterialTheme.typography.bodyMedium)
                    }
                    Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                        IconButton(
                            enabled = index > 0,
                            onClick = {
                                val mutable = blocks.toMutableList()
                                val item = mutable.removeAt(index)
                                mutable.add(index - 1, item)
                                scope.launch { repository.reorderBlocks(tripId, mutable) }
                            }
                        ) { Icon(Icons.Outlined.ArrowUpward, contentDescription = "Move up") }
                        IconButton(
                            enabled = index < blocks.lastIndex,
                            onClick = {
                                val mutable = blocks.toMutableList()
                                val item = mutable.removeAt(index)
                                mutable.add(index + 1, item)
                                scope.launch { repository.reorderBlocks(tripId, mutable) }
                            }
                        ) { Icon(Icons.Outlined.ArrowDownward, contentDescription = "Move down") }
                        IconButton(onClick = { scope.launch { repository.duplicateBlock(block) } }) {
                            Icon(Icons.Outlined.ContentCopy, contentDescription = "Duplicate block")
                        }
                        IconButton(onClick = { scope.launch { repository.deleteBlockAndRecalculateTrip(tripId, block.id) } }) {
                            Icon(Icons.Outlined.Delete, contentDescription = "Delete block", tint = TriplyColors.Danger)
                        }
                    }
                }
            }
        }
    }
}
