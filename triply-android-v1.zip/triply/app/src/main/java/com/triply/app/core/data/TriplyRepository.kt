package com.triply.app.core.data

import android.content.Context
import android.os.StatFs
import androidx.room.withTransaction
import com.triply.app.core.common.MoneyMath
import com.triply.app.core.common.TileSourcePolicyGuard
import com.triply.app.core.common.TripDurationCalculator
import com.triply.app.core.data.backup.TriplyArchiveManager
import com.triply.app.core.data.config.ProviderConfigStore
import com.triply.app.core.data.network.GeoPoint
import com.triply.app.core.data.network.OpenMeteoClient
import com.triply.app.core.data.network.OpenRouteServiceRoutingProvider
import com.triply.app.core.data.network.RoutingOutcome
import com.triply.app.core.data.network.RoutingProfile
import com.triply.app.core.data.network.WeatherOutcome
import com.triply.app.core.data.reminder.ReminderScheduler
import com.triply.app.core.database.*
import kotlinx.coroutines.flow.Flow
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.time.LocalDate
import java.util.UUID

class TriplyRepository(
    val context: Context,
    val db: TriplyDatabase,
    val configStore: ProviderConfigStore,
    val reminderScheduler: ReminderScheduler
) {
    private val json = Json { ignoreUnknownKeys = true }

    val routingProvider = OpenRouteServiceRoutingProvider(
        apiKeyProvider = { configStore.getCurrent().orsApiKey }
    )
    val openMeteoClient = OpenMeteoClient(
        apiKeyProvider = { configStore.getCurrent().openMeteoApiKey }
    )
    val archiveManager = TriplyArchiveManager(context, db)

    // --- Trips & Templates ---
    fun observeTrips(): Flow<List<TripEntity>> = db.tripDao().observeTrips()
    fun observeTemplates(): Flow<List<TripEntity>> = db.tripDao().observeTemplates()
    fun observeTrip(tripId: String): Flow<TripEntity?> = db.tripDao().observeTrip(tripId)

    suspend fun saveTrip(trip: TripEntity) = db.tripDao().upsertTrip(trip)
    suspend fun deleteTrip(tripId: String) = db.tripDao().deleteTrip(tripId)

    // --- Blocks & Destinations (with automatic duration + transfer recalculation) ---
    fun observeBlocks(tripId: String): Flow<List<TripBlockEntity>> = db.blockAndDestinationDao().observeBlocks(tripId)
    fun observeDestinations(tripId: String): Flow<List<DestinationEntity>> = db.blockAndDestinationDao().observeDestinations(tripId)
    fun observeSavedRoutes(tripId: String): Flow<List<SavedRouteEntity>> = db.blockAndDestinationDao().observeSavedRoutes(tripId)

    suspend fun saveBlockAndRecalculateTrip(block: TripBlockEntity) {
        db.withTransaction {
            db.blockAndDestinationDao().upsertBlock(block)
            recalculateTripDates(block.tripId)
        }
    }

    suspend fun deleteBlockAndRecalculateTrip(tripId: String, blockId: String) {
        db.withTransaction {
            db.blockAndDestinationDao().deleteBlock(blockId)
            val remaining = db.blockAndDestinationDao().getBlocksOnce(tripId)
                .mapIndexed { idx, b -> b.copy(orderIndex = idx) }
            db.blockAndDestinationDao().upsertBlocks(remaining)
            recalculateTripDates(tripId)
        }
    }

    suspend fun duplicateBlock(block: TripBlockEntity) {
        db.withTransaction {
            val current = db.blockAndDestinationDao().getBlocksOnce(block.tripId)
            val copy = block.copy(
                id = UUID.randomUUID().toString(),
                title = "${block.title} (Copy)",
                orderIndex = current.size
            )
            db.blockAndDestinationDao().upsertBlock(copy)
            recalculateTripDates(block.tripId)
        }
    }

    suspend fun reorderBlocks(tripId: String, orderedBlocks: List<TripBlockEntity>) {
        db.withTransaction {
            val indexed = orderedBlocks.mapIndexed { idx, b -> b.copy(orderIndex = idx) }
            db.blockAndDestinationDao().upsertBlocks(indexed)
            recalculateTripDates(tripId)
        }
    }

    suspend fun saveDestination(destination: DestinationEntity) = db.blockAndDestinationDao().upsertDestination(destination)
    suspend fun deleteDestination(id: String) = db.blockAndDestinationDao().deleteDestination(id)
    suspend fun reorderDestinations(ordered: List<DestinationEntity>) {
        db.blockAndDestinationDao().upsertDestinations(ordered.mapIndexed { idx, d -> d.copy(orderIndex = idx) })
    }

    private suspend fun recalculateTripDates(tripId: String) {
        val trip = db.tripDao().getTrip(tripId) ?: return
        val blocks = db.blockAndDestinationDao().getBlocksOnce(tripId)
        val start = runCatching { LocalDate.parse(trip.startDateIso) }.getOrNull()
        val summary = TripDurationCalculator.calculate(
            start,
            blocks.map { TripDurationCalculator.BlockSpan(it.durationDays, it.transferDaysBefore) }
        )
        val updatedEnd = summary.computedEndDate?.toString() ?: trip.endDateIso
        db.tripDao().upsertTrip(
            trip.copy(endDateIso = updatedEnd, updatedAtEpochMillis = System.currentTimeMillis())
        )
    }

    // --- Routing ---
    suspend fun refreshRouteForTrip(
        tripId: String,
        profile: RoutingProfile,
        allowCarApproximationForMotorcycle: Boolean = false
    ): RoutingOutcome {
        val destinations = db.blockAndDestinationDao().getDestinationsOnce(tripId)
        val points = destinations.mapNotNull { d ->
            if (d.latitude != null && d.longitude != null) GeoPoint(d.latitude, d.longitude) else null
        }
        val outcome = routingProvider.calculateRoute(points, profile, allowCarApproximationForMotorcycle)
        if (outcome is RoutingOutcome.Success) {
            val r = outcome.result
            val orderHash = destinations.joinToString("|") { "${it.orderIndex}:${it.id}" }
            db.blockAndDestinationDao().upsertSavedRoute(
                SavedRouteEntity(
                    id = UUID.randomUUID().toString(),
                    tripId = tripId,
                    providerName = r.providerName,
                    profileName = r.profileName,
                    isApproximateAlternative = r.isApproximateAlternative,
                    approximationNote = r.approximationNote,
                    totalDistanceMeters = r.totalDistanceMeters,
                    totalDurationSeconds = r.totalDurationSeconds,
                    includesLiveTraffic = r.includesLiveTraffic,
                    polylineJson = json.encodeToString(r.polyline),
                    waypointOrderHash = orderHash,
                    fetchedAtEpochMillis = System.currentTimeMillis()
                )
            )
        }
        return outcome
    }

    // --- Budget & Group ---
    fun observeParticipants(tripId: String) = db.budgetAndGroupDao().observeParticipants(tripId)
    fun observeExpenses(tripId: String) = db.budgetAndGroupDao().observeExpenses(tripId)
    fun observeAllExpenses() = db.budgetAndGroupDao().observeAllExpenses()
    fun observeExpenseShares(tripId: String) = db.budgetAndGroupDao().observeExpenseSharesForTrip(tripId)
    fun observeSettlements(tripId: String) = db.budgetAndGroupDao().observeSettlements(tripId)

    suspend fun saveParticipant(p: ParticipantEntity) = db.budgetAndGroupDao().upsertParticipant(p)
    suspend fun deleteParticipant(id: String) = db.budgetAndGroupDao().deleteParticipant(id)

    suspend fun saveExpenseEqualSplit(expense: ExpenseEntity, participantIds: List<String>) {
        val shares = if (participantIds.isNotEmpty()) {
            val split = MoneyMath.splitEqually(expense.amountMinor, participantIds)
            split.shares.map { (pid, shareAmt) ->
                ExpenseShareEntity(
                    id = UUID.randomUUID().toString(),
                    expenseId = expense.id,
                    participantId = pid,
                    shareMinor = shareAmt,
                    includesRemainderUnit = pid in split.remainderRecipients
                )
            }
        } else emptyList()
        db.budgetAndGroupDao().saveExpenseWithShares(expense, shares)
    }

    suspend fun saveExpenseCustomShares(expense: ExpenseEntity, shares: List<ExpenseShareEntity>) {
        db.budgetAndGroupDao().saveExpenseWithShares(expense, shares)
    }

    suspend fun deleteExpense(id: String) = db.budgetAndGroupDao().deleteExpense(id)
    suspend fun saveSettlement(s: SettlementEntity) = db.budgetAndGroupDao().upsertSettlement(s)
    suspend fun deleteSettlement(id: String) = db.budgetAndGroupDao().deleteSettlement(id)

    // --- Logistics: Packing, Accommodation, Transport ---
    fun observePackingItems(tripId: String) = db.logisticsDao().observePackingItems(tripId)
    suspend fun savePackingItem(item: PackingItemEntity) = db.logisticsDao().upsertPackingItem(item)
    suspend fun deletePackingItem(id: String) = db.logisticsDao().deletePackingItem(id)
    suspend fun mergeSuggestedPackingItems(tripId: String) {
        val existing = db.logisticsDao().getPackingItemsOnce(tripId)
        val blocks = db.blockAndDestinationDao().getBlocksOnce(tripId)
        val cats = blocks.mapNotNull { runCatching { ActivityCategory.valueOf(it.category) }.getOrNull() }.toSet()
        val additions = ChecklistSuggestionEngine.buildNonDestructiveAdditions(tripId, existing, cats)
        if (additions.isNotEmpty()) db.logisticsDao().upsertPackingItems(additions)
    }

    fun observeAccommodations(tripId: String) = db.logisticsDao().observeAccommodations(tripId)
    suspend fun saveAccommodation(a: AccommodationEntity) = db.logisticsDao().upsertAccommodation(a)
    suspend fun deleteAccommodation(id: String) = db.logisticsDao().deleteAccommodation(id)

    fun observeTransportPlans(tripId: String) = db.logisticsDao().observeTransportPlans(tripId)
    suspend fun saveTransportPlan(t: TransportPlanEntity) = db.logisticsDao().upsertTransportPlan(t)
    suspend fun deleteTransportPlan(id: String) = db.logisticsDao().deleteTransportPlan(id)

    // --- Reminders ---
    fun observeReminders(tripId: String) = db.safetyAndJournalDao().observeRemindersForTrip(tripId)
    fun observeUpcomingReminders() = db.safetyAndJournalDao().observeUpcomingReminders()
    suspend fun saveAndScheduleReminder(reminder: ReminderEntity): String {
        db.safetyAndJournalDao().upsertReminder(reminder)
        return if (!reminder.isCancelled && !reminder.isCompleted) {
            reminderScheduler.schedule(reminder)
        } else {
            reminderScheduler.cancel(reminder)
            "Reminder updated."
        }
    }
    suspend fun deleteReminder(reminder: ReminderEntity) {
        reminderScheduler.cancel(reminder)
        db.safetyAndJournalDao().deleteReminder(reminder.id)
    }

    // --- Weather ---
    fun observeWeather(tripId: String) = db.safetyAndJournalDao().observeWeatherForTrip(tripId)
    suspend fun refreshWeatherForDestination(
        tripId: String,
        destinationName: String,
        latitude: Double,
        longitude: Double
    ): WeatherOutcome {
        val outcome = openMeteoClient.fetchForecast(latitude, longitude)
        if (outcome is WeatherOutcome.Success) {
            db.safetyAndJournalDao().upsertWeather(
                WeatherCacheEntity(
                    id = "${tripId}_${destinationName.lowercase().replace(" ", "_")}",
                    tripId = tripId,
                    destinationName = destinationName,
                    latitude = latitude,
                    longitude = longitude,
                    providerName = outcome.providerLabel,
                    forecastJson = outcome.forecastJson,
                    severeNotice = null, // Only populated if returned by an official alert source
                    fetchedAtEpochMillis = System.currentTimeMillis()
                )
            )
        }
        return outcome
    }

    // --- Emergency Center ---
    fun observeEmergencyContacts(tripId: String) = db.safetyAndJournalDao().observeEmergencyContacts(tripId)
    suspend fun saveEmergencyContact(c: EmergencyContactEntity) = db.safetyAndJournalDao().upsertEmergencyContact(c)
    suspend fun deleteEmergencyContact(id: String) = db.safetyAndJournalDao().deleteEmergencyContact(id)

    // --- Journal ---
    fun observeJournal(tripId: String) = db.safetyAndJournalDao().observeJournalEntries(tripId)
    suspend fun saveJournalEntry(e: JournalEntryEntity) = db.safetyAndJournalDao().upsertJournalEntry(e)
    suspend fun deleteJournalEntry(id: String) = db.safetyAndJournalDao().deleteJournalEntry(id)

    // --- Offline Map Regions ---
    fun observeOfflineRegions() = db.safetyAndJournalDao().observeOfflineRegions()
    suspend fun saveOfflineRegion(region: OfflineMapRegionEntity) = db.safetyAndJournalDao().upsertOfflineRegion(region)
    suspend fun deleteOfflineRegion(id: String) = db.safetyAndJournalDao().deleteOfflineRegion(id)

    fun availableStorageMb(): Long {
        val stat = StatFs(context.filesDir.absolutePath)
        return (stat.availableBlocksLong * stat.blockSizeLong) / (1024L * 1024L)
    }

    suspend fun validateOfflineRegionPolicy(): TileSourcePolicyGuard.PolicyCheckResult {
        val cfg = configStore.getCurrent()
        return TileSourcePolicyGuard.validateForOfflineDownload(cfg.resolvedMapStyleUrl(), cfg.mapProviderId)
    }

    // --- What-If Scenarios ---
    fun observeWhatIfScenarios(tripId: String) = db.safetyAndJournalDao().observeWhatIfScenarios(tripId)
    suspend fun saveWhatIfScenario(scenario: WhatIfScenarioEntity) = db.safetyAndJournalDao().upsertWhatIfScenario(scenario)
    suspend fun deleteWhatIfScenario(id: String) = db.safetyAndJournalDao().deleteWhatIfScenario(id)

    /**
     * Applies a What-If scenario to the main trip ONLY after explicit user confirmation.
     */
    suspend fun applyWhatIfToMainTrip(tripId: String, snapshot: WhatIfSnapshot) {
        db.withTransaction {
            db.blockAndDestinationDao().deleteBlocksForTrip(tripId)
            val reindexed = snapshot.blocks.mapIndexed { idx, b -> b.copy(tripId = tripId, orderIndex = idx) }
            db.blockAndDestinationDao().upsertBlocks(reindexed)
            val trip = db.tripDao().getTrip(tripId)
            if (trip != null) {
                val delta = snapshot.accommodationCostDeltaMinor + snapshot.transportCostDeltaMinor + snapshot.gearAndTicketDeltaMinor
                val newBudget = (trip.plannedBudgetMinor + delta).coerceAtLeast(0L)
                db.tripDao().upsertTrip(trip.copy(plannedBudgetMinor = newBudget, updatedAtEpochMillis = System.currentTimeMillis()))
            }
            recalculateTripDates(tripId)
        }
    }

    /**
     * Copies a user-selected media Uri into app-private storage so backup/export references remain stable.
     */
    fun copyMediaToAppStorage(uri: android.net.Uri, prefix: String = "media"): String? {
        return runCatching {
            val dir = File(context.filesDir, "media").apply { mkdirs() }
            val outFile = File(dir, "${prefix}_${UUID.randomUUID()}.bin")
            context.contentResolver.openInputStream(uri)?.use { input ->
                outFile.outputStream().use { output -> input.copyTo(output) }
            } ?: return null
            outFile.absolutePath
        }.getOrNull()
    }
}
