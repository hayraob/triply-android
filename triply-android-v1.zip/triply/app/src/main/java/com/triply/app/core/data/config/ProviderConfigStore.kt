package com.triply.app.core.data.config

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.triplyConfigDataStore by preferencesDataStore(name = "triply_provider_config")

data class ProviderConfig(
    val mapProviderId: String = "openfreemap",
    val mapStyleUrl: String = "https://tiles.openfreemap.org/styles/liberty",
    val mapApiKey: String = "",
    val orsApiKey: String = "",
    val openMeteoApiKey: String = "" // Optional commercial key; blank uses non-commercial endpoint
) {
    fun resolvedMapStyleUrl(): String {
        return when (mapProviderId) {
            "stadia_maps" -> if (mapApiKey.isNotBlank()) {
                "https://tiles.stadiamaps.com/styles/alidade_smooth_dark.json?api_key=$mapApiKey"
            } else ""
            "maptiler" -> if (mapApiKey.isNotBlank()) {
                "https://api.maptiler.com/maps/streets-v2-dark/style.json?key=$mapApiKey"
            } else ""
            "openfreemap" -> "https://tiles.openfreemap.org/styles/liberty"
            "self_hosted" -> mapStyleUrl.trim()
            else -> ""
        }
    }
}

class ProviderConfigStore(private val context: Context) {
    private val KEY_MAP_PROVIDER = stringPreferencesKey("map_provider_id")
    private val KEY_MAP_STYLE_URL = stringPreferencesKey("map_style_url")
    private val KEY_MAP_API_KEY = stringPreferencesKey("map_api_key")
    private val KEY_ORS_API_KEY = stringPreferencesKey("ors_api_key")
    private val KEY_OPEN_METEO_KEY = stringPreferencesKey("open_meteo_api_key")

    val configFlow: Flow<ProviderConfig> = context.triplyConfigDataStore.data.map { prefs ->
        ProviderConfig(
            mapProviderId = prefs[KEY_MAP_PROVIDER] ?: "openfreemap",
            mapStyleUrl = prefs[KEY_MAP_STYLE_URL] ?: "https://tiles.openfreemap.org/styles/liberty",
            mapApiKey = prefs[KEY_MAP_API_KEY] ?: "",
            orsApiKey = prefs[KEY_ORS_API_KEY] ?: "",
            openMeteoApiKey = prefs[KEY_OPEN_METEO_KEY] ?: ""
        )
    }

    suspend fun getCurrent(): ProviderConfig = configFlow.first()

    suspend fun save(config: ProviderConfig) {
        context.triplyConfigDataStore.edit { prefs ->
            prefs[KEY_MAP_PROVIDER] = config.mapProviderId
            prefs[KEY_MAP_STYLE_URL] = config.mapStyleUrl
            prefs[KEY_MAP_API_KEY] = config.mapApiKey.trim()
            prefs[KEY_ORS_API_KEY] = config.orsApiKey.trim()
            prefs[KEY_OPEN_METEO_KEY] = config.openMeteoApiKey.trim()
        }
    }
}
