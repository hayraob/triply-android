package com.triply.app.feature.map

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AddLocation
import androidx.compose.material.icons.outlined.ArrowDownward
import androidx.compose.material.icons.outlined.ArrowUpward
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.DownloadForOffline
import androidx.compose.material.icons.outlined.Navigation
import androidx.compose.material.icons.outlined.Route
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.triply.app.core.data.TriplyRepository
import com.triply.app.core.data.config.ProviderConfig
import com.triply.app.core.data.network.GeoPoint
import com.triply.app.core.data.network.RoutingOutcome
import com.triply.app.core.data.network.RoutingProfile
import com.triply.app.core.database.DestinationEntity
import com.triply.app.core.designsystem.EmptyStateView
import com.triply.app.core.designsystem.ErrorBanner
import com.triply.app.core.designsystem.SectionHeader
import com.triply.app.core.designsystem.StatusPill
import com.triply.app.core.designsystem.TriplyCard
import com.triply.app.core.designsystem.TriplyColors
import com.triply.app.core.designsystem.TriplySpacing
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import org.maplibre.android.annotations.MarkerOptions
import org.maplibre.android.annotations.PolylineOptions
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapView
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.UUID

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TripMapTab(
    repository: TriplyRepository,
    tripId: String,
    isOnline: Boolean,
    onOpenOfflineMaps: () -> Unit
) {
    val context = LocalContext.current
    val destinations by repository.observeDestinations(tripId).collectAsState(initial = emptyList())
    val savedRoutes by repository.observeSavedRoutes(tripId).collectAsState(initial = emptyList())
    val providerConfig by repository.configStore.configFlow.collectAsState(initial = ProviderConfig())
    val scope = rememberCoroutineScope()
    val json = remember { Json { ignoreUnknownKeys = true } }

    var selectedProfile by remember { mutableStateOf(RoutingProfile.CAR) }
    var allowCarApproxForMoto by remember { mutableStateOf(false) }
    var isCalculating by remember { mutableStateOf(false) }
    var routeError by remember { mutableStateOf<String?>(null) }
    var showAddDestDialog by remember { mutableStateOf(false) }

    val latestRoute = savedRoutes.firstOrNull()
    val polylinePoints = remember(latestRoute) {
        if (latestRoute == null) emptyList()
        else runCatching { json.decodeFromString<List<GeoPoint>>(latestRoute.polylineJson) }.getOrDefault(emptyList())
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(TriplySpacing.Lg),
        verticalArrangement = Arrangement.spacedBy(TriplySpacing.Md)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Interactive Map & Route", style = MaterialTheme.typography.titleLarge)
            OutlinedButton(onClick = onOpenOfflineMaps) {
                Icon(Icons.Outlined.DownloadForOffline, contentDescription = null)
                Text(" Offline Regions")
            }
        }

        // MapLibre Native Android MapView
        val styleUrl = providerConfig.resolvedMapStyleUrl()
        if (styleUrl.isBlank()) {
            ErrorBanner("No map style URL is configured for the selected provider (${providerConfig.mapProviderId}). Configure your API key in Profile > Map & API Settings.")
        } else {
            TriplyMapLibreCanvas(
                styleUrl = styleUrl,
                destinations = destinations,
                routePoints = polylinePoints,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(260.dp)
            )
            Text(
                text = "Map attribution: OpenStreetMap contributors & configured tile provider (${providerConfig.mapProviderId}).",
                style = MaterialTheme.typography.labelMedium
            )
        }

        // Route Profile & Calculation
        TriplyCard {
            SectionHeader(title = "Route Estimate", subtitle = "Calculated from real routing API; never fabricated.")
            FlowRow(horizontalArrangement = Arrangement.spacedBy(TriplySpacing.Xs)) {
                RoutingProfile.entries.forEach { profile ->
                    FilterChip(
                        selected = selectedProfile == profile,
                        onClick = { selectedProfile = profile; routeError = null },
                        label = { Text(profile.label) }
                    )
                }
            }
            if (selectedProfile == RoutingProfile.MOTORCYCLE) {
                Spacer(Modifier.height(TriplySpacing.Xs))
                Text(
                    text = RoutingProfile.MOTORCYCLE.note.orEmpty(),
                    style = MaterialTheme.typography.bodyMedium,
                    color = TriplyColors.Warning
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = allowCarApproxForMoto, onCheckedChange = { allowCarApproxForMoto = it })
                    Text("Use driving-car as a clearly labelled approximate alternative", style = MaterialTheme.typography.bodyMedium)
                }
            }
            Spacer(Modifier.height(TriplySpacing.Sm))
            Button(
                enabled = !isCalculating && isOnline,
                onClick = {
                    scope.launch {
                        isCalculating = true
                        routeError = null
                        when (val out = repository.refreshRouteForTrip(tripId, selectedProfile, allowCarApproxForMoto)) {
                            is RoutingOutcome.Success -> routeError = null
                            is RoutingOutcome.ApiNotConfigured -> routeError = out.message
                            is RoutingOutcome.ProfileUnsupported -> routeError = out.message
                            is RoutingOutcome.Error -> routeError = out.message
                        }
                        isCalculating = false
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Outlined.Route, contentDescription = null)
                Text(if (isOnline) " Refresh Route Estimate" else " Offline — Using Saved Route Only")
            }

            if (isCalculating) {
                Spacer(Modifier.height(TriplySpacing.Sm))
                CircularProgressIndicator(color = TriplyColors.Accent)
            }
            routeError?.let {
                Spacer(Modifier.height(TriplySpacing.Sm))
                ErrorBanner(it)
            }

            if (latestRoute != null) {
                Spacer(Modifier.height(TriplySpacing.Md))
                val km = latestRoute.totalDistanceMeters / 1000.0
                val hours = (latestRoute.totalDurationSeconds / 3600.0).toInt()
                val mins = ((latestRoute.totalDurationSeconds % 3600.0) / 60.0).toInt()
                val fetchedStr = Instant.ofEpochMilli(latestRoute.fetchedAtEpochMillis)
                    .atZone(ZoneId.systemDefault())
                    .format(DateTimeFormatter.ofPattern("d MMM yyyy, HH:mm"))

                Row(horizontalArrangement = Arrangement.spacedBy(TriplySpacing.Sm)) {
                    StatusPill(if (isOnline) "Saved Route" else "Offline Saved Route", TriplyColors.Accent)
                    StatusPill("No live traffic", TriplyColors.Warning)
                }
                Spacer(Modifier.height(TriplySpacing.Xs))
                Text("Distance: %.1f km • Est. Duration: %dh %dm".format(km, hours, mins), style = MaterialTheme.typography.titleMedium)
                Text("Provider: ${latestRoute.providerName} (${latestRoute.profileName})", style = MaterialTheme.typography.bodyMedium)
                Text("Last calculated: $fetchedStr", style = MaterialTheme.typography.labelMedium)
                Text(latestRoute.approximationNote, style = MaterialTheme.typography.labelMedium)
            }
        }

        // Ordered Destinations List (Numbered Pins)
        SectionHeader(
            title = "Destinations (${destinations.size})",
            subtitle = "Pins and route lines strictly follow this user-defined order.",
            actionLabel = "Add Pin",
            onActionClick = { showAddDestDialog = true }
        )

        if (destinations.isEmpty()) {
            EmptyStateView(
                icon = Icons.Outlined.AddLocation,
                title = "No destinations pinned",
                message = "Add destinations with coordinates here or from the Explore tab.",
                actionLabel = "Add Destination",
                onAction = { showAddDestDialog = true }
            )
        } else {
            destinations.forEachIndexed { idx, dest ->
                TriplyCard {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("#${idx + 1} ${dest.name}", style = MaterialTheme.typography.titleMedium)
                            if (dest.latitude != null && dest.longitude != null) {
                                Text("%.5f, %.5f".format(dest.latitude, dest.longitude), style = MaterialTheme.typography.labelMedium)
                            } else {
                                Text("Coordinates not set — tap Explore or edit to add coordinates", style = MaterialTheme.typography.labelMedium, color = TriplyColors.Warning)
                            }
                        }
                        Row {
                            if (dest.latitude != null && dest.longitude != null) {
                                IconButton(onClick = {
                                    val geoUri = Uri.parse("geo:${dest.latitude},${dest.longitude}?q=${dest.latitude},${dest.longitude}(${Uri.encode(dest.name)})")
                                    val intent = Intent(Intent.ACTION_VIEW, geoUri)
                                    runCatching { context.startActivity(intent) }
                                }) {
                                    Icon(Icons.Outlined.Navigation, contentDescription = "Open in external navigation", tint = TriplyColors.Success)
                                }
                            }
                            IconButton(
                                enabled = idx > 0,
                                onClick = {
                                    val list = destinations.toMutableList()
                                    val moved = list.removeAt(idx)
                                    list.add(idx - 1, moved)
                                    scope.launch { repository.reorderDestinations(list) }
                                }
                            ) { Icon(Icons.Outlined.ArrowUpward, contentDescription = "Move up") }
                            IconButton(
                                enabled = idx < destinations.lastIndex,
                                onClick = {
                                    val list = destinations.toMutableList()
                                    val moved = list.removeAt(idx)
                                    list.add(idx + 1, moved)
                                    scope.launch { repository.reorderDestinations(list) }
                                }
                            ) { Icon(Icons.Outlined.ArrowDownward, contentDescription = "Move down") }
                            IconButton(onClick = { scope.launch { repository.deleteDestination(dest.id) } }) {
                                Icon(Icons.Outlined.Delete, contentDescription = "Remove destination", tint = TriplyColors.Danger)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDestDialog) {
        var dName by remember { mutableStateOf("") }
        var dLat by remember { mutableStateOf("") }
        var dLon by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAddDestDialog = false },
            containerColor = TriplyColors.Surface,
            title = { Text("Add Destination Pin") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(TriplySpacing.Sm)) {
                    OutlinedTextField(value = dName, onValueChange = { dName = it }, label = { Text("Place Name *") }, singleLine = true)
                    OutlinedTextField(value = dLat, onValueChange = { dLat = it }, label = { Text("Latitude (e.g. -7.7956)") }, singleLine = true)
                    OutlinedTextField(value = dLon, onValueChange = { dLon = it }, label = { Text("Longitude (e.g. 110.3695)") }, singleLine = true)
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (dName.isNotBlank()) {
                        scope.launch {
                            repository.saveDestination(
                                DestinationEntity(
                                    id = UUID.randomUUID().toString(),
                                    tripId = tripId,
                                    name = dName.trim(),
                                    latitude = dLat.toDoubleOrNull(),
                                    longitude = dLon.toDoubleOrNull(),
                                    orderIndex = destinations.size
                                )
                            )
                            showAddDestDialog = false
                        }
                    }
                }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { showAddDestDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Suppress("DEPRECATION")
@Composable
private fun TriplyMapLibreCanvas(
    styleUrl: String,
    destinations: List<DestinationEntity>,
    routePoints: List<GeoPoint>,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val mapView = remember { MapView(context).apply { onCreate(null) } }

    DisposableEffect(lifecycle, mapView) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> mapView.onStart()
                Lifecycle.Event.ON_RESUME -> mapView.onResume()
                Lifecycle.Event.ON_PAUSE -> mapView.onPause()
                Lifecycle.Event.ON_STOP -> mapView.onStop()
                Lifecycle.Event.ON_DESTROY -> mapView.onDestroy()
                else -> Unit
            }
        }
        lifecycle.addObserver(observer)
        onDispose { lifecycle.removeObserver(observer) }
    }

    AndroidView(
        factory = { mapView },
        modifier = modifier,
        update = { mv ->
            mv.getMapAsync { map ->
                map.setStyle(styleUrl) {
                    map.clear()
                    val validDests = destinations.filter { it.latitude != null && it.longitude != null }
                    validDests.forEachIndexed { idx, dest ->
                        val latLng = LatLng(dest.latitude!!, dest.longitude!!)
                        map.addMarker(
                            MarkerOptions()
                                .position(latLng)
                                .title("#${idx + 1} ${dest.name}")
                                .snippet(dest.address)
                        )
                    }
                    val lineCoords = if (routePoints.size >= 2) {
                        routePoints.map { LatLng(it.latitude, it.longitude) }
                    } else {
                        validDests.map { LatLng(it.latitude!!, it.longitude!!) }
                    }
                    if (lineCoords.size >= 2) {
                        map.addPolyline(
                            PolylineOptions()
                                .addAll(lineCoords)
                                .color(android.graphics.Color.parseColor("#8B7CFF"))
                                .width(4f)
                        )
                    }
                    validDests.firstOrNull()?.let { first ->
                        map.cameraPosition = CameraPosition.Builder()
                            .target(LatLng(first.latitude!!, first.longitude!!))
                            .zoom(10.0)
                            .build()
                    }
                }
            }
        }
    )
}
