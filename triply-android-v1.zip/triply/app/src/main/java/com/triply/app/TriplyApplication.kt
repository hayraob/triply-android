package com.triply.app

import android.app.Application
import com.triply.app.core.common.ConnectivityMonitor
import com.triply.app.core.data.TriplyRepository
import com.triply.app.core.data.config.ProviderConfigStore
import com.triply.app.core.data.reminder.ReminderScheduler
import com.triply.app.core.data.reminder.TriplyNotificationHelper
import com.triply.app.core.database.TriplyDatabase
import org.maplibre.android.MapLibre

class AppContainer(application: Application) {
    val database: TriplyDatabase = TriplyDatabase.getInstance(application)
    val configStore: ProviderConfigStore = ProviderConfigStore(application)
    val connectivityMonitor: ConnectivityMonitor = ConnectivityMonitor(application)
    val reminderScheduler: ReminderScheduler = ReminderScheduler(application)
    val repository: TriplyRepository = TriplyRepository(
        context = application,
        db = database,
        configStore = configStore,
        reminderScheduler = reminderScheduler
    )
}

class TriplyApplication : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        MapLibre.getInstance(this)
        TriplyNotificationHelper.ensureChannel(this)
        container = AppContainer(this)
    }
}
