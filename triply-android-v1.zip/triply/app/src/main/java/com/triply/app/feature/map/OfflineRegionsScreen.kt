package com.triply.app.feature.map

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.triply.app.core.common.TileSourcePolicyGuard
import com.triply.app.core.data.TriplyRepository
import com.triply.app.core.data.config.ProviderConfig
import com.triply.app.core.database.OfflineMapRegionEntity
import com.triply.app.core.database.OfflineRegionStatus
import com.triply.app.core.designsystem.EmptyStateView
import com.triply.app.core.designsystem.ErrorBanner
import com.triply.app.core.designsystem.SectionHeader
import com.triply.app.core.designsystem.StatusPill
import com.triply.app.core.designsystem.TriplyCard
import com.triply.app.core.designsystem.TriplyColors
import com.triply.app.core.designsystem.TriplySpacing
import kotlinx.coroutines.launch
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.geometry.LatLngBounds
import org.maplibre.android.offline.OfflineManager
import org.maplibre.android.offline.OfflineRegion
import org.maplibre.android.offline.OfflineRegionError
import org.maplibre.android.offline.OfflineRegionStatus as MlStatus
import org.maplibre.android.offline.OfflineTilePyramidRegionDefinition
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OfflineRegionsScreen(
    repository: TriplyRepository,
    isOnline: Boolean,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val regions by repository.observeOfflineRegions().collectAsState(initial = emptyList())
    val config by repository.configStore.configFlow.collectAsState(initial = ProviderConfig())
    val scope = rememberCoroutineScope()

    var regionName by remember { mutableStateOf("") }
    var northLat by remember { mutableStateOf("-6.80") }
    var southLat by remember { mutableStateOf("-7.90") }
    var eastLon by remember { mutableStateOf("110.60") }
    var westLon by remember { mutableStateOf("109.50") }
    var minZoom by remember { mutableStateOf("8") }
    var maxZoom by remember { mutableStateOf("13") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    val freeMb = remember { repository.availableStorageMb() }
    val policy = remember(config) {
        TileSourcePolicyGuard.validateForOfflineDownload(config.resolvedMapStyleUrl(), config.mapProviderId)
    }

    Scaffold(
        containerColor = TriplyColors.Background,
        topBar = {
            TopAppBar(
                title = { Text("Offline Map Regions") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = TriplyColors.Surface)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(TriplySpacing.Lg),
            verticalArrangement = Arrangement.spacedBy(TriplySpacing.Md)
        ) {
            TriplyCard {
                Text("Available device storage: $freeMb MB", style = MaterialTheme.typography.titleMedium)
                Text("Active tile provider: ${config.mapProviderId}", style = MaterialTheme.typography.bodyMedium)
                when (policy) {
                    is TileSourcePolicyGuard.PolicyCheckResult.Permitted -> {
                        Text("Attribution: ${policy.attribution}", style = MaterialTheme.typography.labelMedium)
                        policy.maxCacheMb?.let {
                            Text("Provider offline cache cap: $it MB per device.", style = MaterialTheme.typography.labelMedium, color = TriplyColors.Warning)
                        }
                    }
                    is TileSourcePolicyGuard.PolicyCheckResult.Blocked -> {
                        Spacer(Modifier.height(TriplySpacing.Xs))
                        ErrorBanner(policy.reason)
                    }
                }
            }

            errorMsg?.let { ErrorBanner(it) }

            TriplyCard {
                SectionHeader(title = "Download New Offline Region")
                OutlinedTextField(
                    value = regionName,
                    onValueChange = { regionName = it },
                    label = { Text("Region Name (e.g. Central Java Mountains)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(TriplySpacing.Xs))
                Row(horizontalArrangement = Arrangement.spacedBy(TriplySpacing.Sm)) {
                    OutlinedTextField(value = northLat, onValueChange = { northLat = it }, label = { Text("North Lat") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = southLat, onValueChange = { southLat = it }, label = { Text("South Lat") }, singleLine = true, modifier = Modifier.weight(1f))
                }
                Spacer(Modifier.height(TriplySpacing.Xs))
                Row(horizontalArrangement = Arrangement.spacedBy(TriplySpacing.Sm)) {
                    OutlinedTextField(value = westLon, onValueChange = { westLon = it }, label = { Text("West Lon") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = eastLon, onValueChange = { eastLon = it }, label = { Text("East Lon") }, singleLine = true, modifier = Modifier.weight(1f))
                }
                Spacer(Modifier.height(TriplySpacing.Xs))
                Row(horizontalArrangement = Arrangement.spacedBy(TriplySpacing.Sm)) {
                    OutlinedTextField(value = minZoom, onValueChange = { minZoom = it }, label = { Text("Min Zoom") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = maxZoom, onValueChange = { maxZoom = it }, label = { Text("Max Zoom (<=15)") }, singleLine = true, modifier = Modifier.weight(1f))
                }
                Spacer(Modifier.height(TriplySpacing.Sm))
                Button(
                    enabled = isOnline && policy is TileSourcePolicyGuard.PolicyCheckResult.Permitted,
                    onClick = {
                        errorMsg = null
                        if (freeMb < 200L) {
                            errorMsg = "Insufficient free storage ($freeMb MB). Free at least 200 MB before downloading map regions."
                            return@Button
                        }
                        val n = northLat.toDoubleOrNull()
                        val s = southLat.toDoubleOrNull()
                        val e = eastLon.toDoubleOrNull()
                        val w = westLon.toDoubleOrNull()
                        val zMin = minZoom.toDoubleOrNull()?.coerceIn(0.0, 14.0)
                        val zMax = maxZoom.toDoubleOrNull()?.coerceIn(1.0, 15.0)
                        if (regionName.isBlank() || n == null || s == null || e == null || w == null || zMin == null || zMax == null || n <= s || e <= w) {
                            errorMsg = "Please enter a valid region name, bounding box (North > South, East > West), and zoom range."
                            return@Button
                        }
                        val allowed = policy as TileSourcePolicyGuard.PolicyCheckResult.Permitted
                        val regionId = UUID.randomUUID().toString()
                        val styleUrl = config.resolvedMapStyleUrl()
                        val initialEntity = OfflineMapRegionEntity(
                            id = regionId,
                            name = regionName.trim(),
                            providerId = config.mapProviderId,
                            styleUrl = styleUrl,
                            attribution = allowed.attribution,
                            northLat = n,
                            southLat = s,
                            eastLon = e,
                            westLon = w,
                            minZoom = zMin,
                            maxZoom = zMax,
                            status = OfflineRegionStatus.DOWNLOADING.name,
                            progressPercent = 0,
                            updatedAtEpochMillis = System.currentTimeMillis()
                        )
                        scope.launch { repository.saveOfflineRegion(initialEntity) }

                        // Trigger real MapLibre Native OfflineManager download
                        val bounds = LatLngBounds.Builder()
                            .include(LatLng(n, e))
                            .include(LatLng(s, w))
                            .build()
                        val definition = OfflineTilePyramidRegionDefinition(
                            styleUrl,
                            bounds,
                            zMin,
                            zMax,
                            context.resources.displayMetrics.density
                        )
                        val offlineManager = OfflineManager.getInstance(context)
                        offlineManager.createOfflineRegion(
                            definition,
                            regionName.trim().toByteArray(Charsets.UTF_8),
                            object : OfflineManager.CreateOfflineRegionCallback {
                                override fun onCreate(offlineRegion: OfflineRegion) {
                                    offlineRegion.setDownloadState(OfflineRegion.STATE_ACTIVE)
                                    offlineRegion.setObserver(object : OfflineRegion.OfflineRegionObserver {
                                        override fun onStatusChanged(status: MlStatus) {
                                            val pct = if (status.requiredResourceCount > 0) {
                                                ((status.completedResourceCount * 100L) / status.requiredResourceCount).toInt().coerceIn(0, 100)
                                            } else 0
                                            val st = if (status.isComplete) OfflineRegionStatus.DOWNLOADED else OfflineRegionStatus.DOWNLOADING
                                            scope.launch {
                                                repository.saveOfflineRegion(
                                                    initialEntity.copy(
                                                        mapLibreRegionId = offlineRegion.id,
                                                        status = st.name,
                                                        progressPercent = pct,
                                                        downloadedBytes = status.completedResourceSize,
                                                        updatedAtEpochMillis = System.currentTimeMillis()
                                                    )
                                                )
                                            }
                                        }
                                        override fun onError(error: OfflineRegionError) {
                                            scope.launch {
                                                repository.saveOfflineRegion(
                                                    initialEntity.copy(
                                                        mapLibreRegionId = offlineRegion.id,
                                                        status = OfflineRegionStatus.FAILED.name,
                                                        errorMessage = error.message,
                                                        updatedAtEpochMillis = System.currentTimeMillis()
                                                    )
                                                )
                                            }
                                        }
                                        override fun mapboxTileCountLimitExceeded(limit: Long) {
                                            scope.launch {
                                                repository.saveOfflineRegion(
                                                    initialEntity.copy(
                                                        mapLibreRegionId = offlineRegion.id,
                                                        status = OfflineRegionStatus.FAILED.name,
                                                        errorMessage = "Tile count limit exceeded ($limit tiles). Reduce area or max zoom.",
                                                        updatedAtEpochMillis = System.currentTimeMillis()
                                                    )
                                                )
                                            }
                                        }
                                    })
                                }

                                override fun onError(error: String) {
                                    scope.launch {
                                        repository.saveOfflineRegion(
                                            initialEntity.copy(
                                                status = OfflineRegionStatus.FAILED.name,
                                                errorMessage = error,
                                                updatedAtEpochMillis = System.currentTimeMillis()
                                            )
                                        )
                                    }
                                }
                            }
                        )
                        regionName = ""
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Outlined.Download, contentDescription = null)
                    Text(if (isOnline) " Download Offline Region" else " Connect to Internet to Download")
                }
            }

            SectionHeader(title = "Saved Offline Regions (${regions.size})")
            if (regions.isEmpty()) {
                EmptyStateView(
                    title = "No offline regions downloaded",
                    message = "Download a region above while online to view vector map tiles in airplane mode."
                )
            } else {
                regions.forEach { region ->
                    val statusEnum = runCatching { OfflineRegionStatus.valueOf(region.status) }.getOrDefault(OfflineRegionStatus.QUEUED)
                    val color = when (statusEnum) {
                        OfflineRegionStatus.DOWNLOADED -> TriplyColors.Success
                        OfflineRegionStatus.FAILED -> TriplyColors.Danger
                        else -> TriplyColors.Accent
                    }
                    TriplyCard {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(region.name, style = MaterialTheme.typography.titleMedium)
                                Text("Zoom ${region.minZoom.toInt()}–${region.maxZoom.toInt()} • %.1f MB".format(region.downloadedBytes / (1024.0 * 1024.0)), style = MaterialTheme.typography.bodyMedium)
                                Text(region.attribution, style = MaterialTheme.typography.labelMedium)
                            }
                            StatusPill(statusEnum.label, color)
                        }
                        if (statusEnum == OfflineRegionStatus.DOWNLOADING) {
                            Spacer(Modifier.height(TriplySpacing.Xs))
                            LinearProgressIndicator(
                                progress = { region.progressPercent / 100f },
                                modifier = Modifier.fillMaxWidth(),
                                color = TriplyColors.Accent
                            )
                        }
                        region.errorMessage?.let {
                            Text(it, color = TriplyColors.Danger, style = MaterialTheme.typography.labelMedium)
                        }
                        Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                            IconButton(onClick = { scope.launch { repository.deleteOfflineRegion(region.id) } }) {
                                Icon(Icons.Outlined.Delete, contentDescription = "Delete region", tint = TriplyColors.Danger)
                            }
                        }
                    }
                }
            }
        }
    }
}
