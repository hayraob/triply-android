package com.triply.app.core.common

import java.net.URI
import java.util.Locale

/**
 * Enforces tile-provider compliance for offline region downloads.
 * Standard public OpenStreetMap tile servers explicitly prohibit bulk downloading and offline prefetching
 * (https://operations.osmfoundation.org/policies/tiles/ and /vector/).
 */
object TileSourcePolicyGuard {

    private val prohibitedHosts = setOf(
        "tile.openstreetmap.org",
        "a.tile.openstreetmap.org",
        "b.tile.openstreetmap.org",
        "c.tile.openstreetmap.org",
        "vector.openstreetmap.org",
        "tile.osm.org"
    )

    sealed interface PolicyCheckResult {
        data class Permitted(val attribution: String, val maxCacheMb: Int?) : PolicyCheckResult
        data class Blocked(val reason: String) : PolicyCheckResult
    }

    fun validateForOfflineDownload(styleUrl: String, providerId: String): PolicyCheckResult {
        if (styleUrl.isBlank()) {
            return PolicyCheckResult.Blocked(
                "No compliant offline map style URL is configured. Configure Stadia Maps, MapTiler, OpenFreeMap, or a self-hosted style in Profile > Map & API Settings."
            )
        }
        val host = runCatching { URI(styleUrl).host?.lowercase(Locale.ROOT) }.getOrNull()
            ?: return PolicyCheckResult.Blocked("Invalid map style URL.")

        if (prohibitedHosts.any { host == it || host.endsWith(".$it") }) {
            return PolicyCheckResult.Blocked(
                "Offline downloads from public OpenStreetMap tile servers ($host) are prohibited by the OSM Foundation Tile Usage Policy. Use a permitted provider instead."
            )
        }

        return when (providerId) {
            "stadia_maps" -> PolicyCheckResult.Permitted(
                attribution = "© Stadia Maps, © OpenMapTiles, © OpenStreetMap contributors",
                maxCacheMb = 100 // Per Stadia Maps ToS: max 100 MB cached offline per device
            )
            "maptiler" -> PolicyCheckResult.Permitted(
                attribution = "© MapTiler, © OpenStreetMap contributors",
                maxCacheMb = 500
            )
            "openfreemap" -> PolicyCheckResult.Permitted(
                attribution = "OpenFreeMap © OpenMapTiles, Data from OpenStreetMap",
                maxCacheMb = 150
            )
            "self_hosted" -> PolicyCheckResult.Permitted(
                attribution = "Self-hosted tiles (verify OpenStreetMap attribution if OSM-derived)",
                maxCacheMb = null
            )
            else -> PolicyCheckResult.Blocked(
                "Unknown tile provider '$providerId'. Only explicitly verified providers may be used for offline region downloads."
            )
        }
    }
}
