package com.triply.app.core.common

import java.time.LocalDate
import java.time.temporal.ChronoUnit

/**
 * Computes overall trip duration including explicit travel/transfer days between blocks.
 * Never omits transfer time or silently squeezes transfers into activity days.
 */
object TripDurationCalculator {

    data class BlockSpan(
        val durationDays: Int,
        val transferDaysBefore: Int = 0
    )

    data class DurationSummary(
        val totalActivityDays: Int,
        val totalTransferDays: Int,
        val totalTripDays: Int,
        val computedEndDate: LocalDate?
    )

    fun calculate(startDate: LocalDate?, blocks: List<BlockSpan>): DurationSummary {
        val activityDays = blocks.sumOf { it.durationDays.coerceAtLeast(1) }
        val transferDays = blocks.sumOf { it.transferDaysBefore.coerceAtLeast(0) }
        val totalDays = (activityDays + transferDays).coerceAtLeast(if (blocks.isEmpty()) 0 else 1)
        val endDate = if (startDate != null && totalDays > 0) {
            startDate.plusDays((totalDays - 1).toLong())
        } else {
            startDate
        }
        return DurationSummary(
            totalActivityDays = activityDays,
            totalTransferDays = transferDays,
            totalTripDays = totalDays,
            computedEndDate = endDate
        )
    }

    fun daysInclusive(start: LocalDate, end: LocalDate): Int {
        if (end.isBefore(start)) return 1
        return (ChronoUnit.DAYS.between(start, end) + 1L).toInt()
    }

    /**
     * Estimates fuel volume and cost cleanly marked as an estimate.
     * Returns null when distance or efficiency is unavailable/invalid (never fabricates numbers).
     */
    fun estimateFuelCostIdr(
        distanceKm: Double?,
        fuelEfficiencyKmPerLiter: Double?,
        fuelPricePerLiterIdr: Long?
    ): Long? {
        if (distanceKm == null || fuelEfficiencyKmPerLiter == null || fuelPricePerLiterIdr == null) return null
        if (distanceKm <= 0.0 || fuelEfficiencyKmPerLiter <= 0.0 || fuelPricePerLiterIdr <= 0L) return null
        val liters = distanceKm / fuelEfficiencyKmPerLiter
        return Math.round(liters * fuelPricePerLiterIdr)
    }
}
