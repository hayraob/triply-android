package com.triply.app.feature.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Checklist
import androidx.compose.material.icons.outlined.Map
import androidx.compose.material.icons.outlined.NotificationsActive
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.triply.app.core.common.MoneyMath
import com.triply.app.core.data.TriplyRepository
import com.triply.app.core.designsystem.EmptyStateView
import com.triply.app.core.designsystem.SectionHeader
import com.triply.app.core.designsystem.StatusPill
import com.triply.app.core.designsystem.TriplyCard
import com.triply.app.core.designsystem.TriplyColors
import com.triply.app.core.designsystem.TriplySpacing
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit

@Composable
fun HomeScreen(
    repository: TriplyRepository,
    onCreateTrip: () -> Unit,
    onOpenTrip: (String, Int) -> Unit,
    onOpenBudget: () -> Unit,
    onOpenExplore: () -> Unit
) {
    val trips by repository.observeTrips().collectAsState(initial = emptyList())
    val reminders by repository.observeUpcomingReminders().collectAsState(initial = emptyList())
    val allExpenses by repository.observeAllExpenses().collectAsState(initial = emptyList())

    val today = LocalDate.now()
    val dateLabel = today.format(DateTimeFormatter.ofPattern("EEEE, d MMM yyyy"))

    val nextOrActiveTrip = trips.firstOrNull { trip ->
        val end = runCatching { LocalDate.parse(trip.endDateIso) }.getOrNull()
        end == null || !end.isBefore(today)
    } ?: trips.firstOrNull()

    val nextReminder = reminders.firstOrNull { it.triggerAtEpochMillis >= System.currentTimeMillis() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(TriplySpacing.Lg),
        verticalArrangement = Arrangement.spacedBy(TriplySpacing.Md)
    ) {
        Text(text = "Triply", style = MaterialTheme.typography.headlineMedium)
        Text(text = dateLabel, style = MaterialTheme.typography.bodyMedium)

        if (nextOrActiveTrip == null) {
            EmptyStateView(
                title = "No trips planned yet",
                message = "Create your first offline-ready trip with destinations, itinerary blocks, budget, and checklists.",
                actionLabel = "Create Trip",
                onAction = onCreateTrip
            )
        } else {
            val start = runCatching { LocalDate.parse(nextOrActiveTrip.startDateIso) }.getOrNull()
            val end = runCatching { LocalDate.parse(nextOrActiveTrip.endDateIso) }.getOrNull()
            val countdownLabel = when {
                start == null -> "Dates not set"
                today.isBefore(start) -> "Starts in ${ChronoUnit.DAYS.between(today, start)} day(s)"
                end != null && !today.isAfter(end) -> "Active trip"
                else -> "Completed"
            }
            val pillColor = when (countdownLabel) {
                "Active trip" -> TriplyColors.Success
                "Completed" -> TriplyColors.TextSecondary
                else -> TriplyColors.Accent
            }

            TriplyCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = nextOrActiveTrip.name, style = MaterialTheme.typography.titleLarge)
                    StatusPill(text = countdownLabel, color = pillColor)
                }
                Spacer(Modifier.height(TriplySpacing.Xs))
                Text(
                    text = "${nextOrActiveTrip.startDateIso} -> ${nextOrActiveTrip.endDateIso}",
                    style = MaterialTheme.typography.bodyMedium
                )
                if (nextOrActiveTrip.description.isNotBlank()) {
                    Spacer(Modifier.height(TriplySpacing.Xs))
                    Text(text = nextOrActiveTrip.description, style = MaterialTheme.typography.bodyMedium)
                }
                Spacer(Modifier.height(TriplySpacing.Md))
                Button(
                    onClick = { onOpenTrip(nextOrActiveTrip.id, 0) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Open Trip Plan")
                }
            }
        }

        SectionHeader(title = "Quick Actions")
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(TriplySpacing.Sm)
        ) {
            FilledTonalButton(onClick = onCreateTrip, modifier = Modifier.weight(1f)) {
                Icon(Icons.Outlined.Add, contentDescription = null)
                Text(" Create Trip")
            }
            FilledTonalButton(
                onClick = {
                    if (nextOrActiveTrip != null) onOpenTrip(nextOrActiveTrip.id, 3) else onOpenBudget()
                },
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Outlined.ReceiptLong, contentDescription = null)
                Text(" Add Expense")
            }
        }
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(TriplySpacing.Sm)
        ) {
            FilledTonalButton(
                onClick = {
                    if (nextOrActiveTrip != null) onOpenTrip(nextOrActiveTrip.id, 4) else onCreateTrip()
                },
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Outlined.Checklist, contentDescription = null)
                Text(" Checklist")
            }
            FilledTonalButton(
                onClick = {
                    if (nextOrActiveTrip != null) onOpenTrip(nextOrActiveTrip.id, 2) else onOpenExplore()
                },
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Outlined.Map, contentDescription = null)
                Text(" Map")
            }
        }

        SectionHeader(title = "Next Reminder")
        TriplyCard {
            if (nextReminder == null) {
                Text("No upcoming reminders scheduled.", style = MaterialTheme.typography.bodyMedium)
            } else {
                val triggerText = Instant.ofEpochMilli(nextReminder.triggerAtEpochMillis)
                    .atZone(ZoneId.systemDefault())
                    .format(DateTimeFormatter.ofPattern("d MMM yyyy, HH:mm"))
                Row(horizontalArrangement = Arrangement.spacedBy(TriplySpacing.Sm)) {
                    Icon(Icons.Outlined.NotificationsActive, contentDescription = null, tint = TriplyColors.Warning)
                    Column {
                        Text(nextReminder.title, style = MaterialTheme.typography.titleMedium)
                        Text(triggerText, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }

        SectionHeader(title = "Budget Summary", actionLabel = "View All", onActionClick = onOpenBudget)
        TriplyCard {
            val totalPlanned = trips.sumOf { it.plannedBudgetMinor }
            val totalActual = allExpenses.sumOf { it.amountMinor }
            val remaining = totalPlanned - totalActual
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("Planned", style = MaterialTheme.typography.labelMedium)
                    Text(MoneyMath.format(totalPlanned), style = MaterialTheme.typography.titleMedium)
                }
                Column {
                    Text("Actual", style = MaterialTheme.typography.labelMedium)
                    Text(MoneyMath.format(totalActual), style = MaterialTheme.typography.titleMedium)
                }
                Column {
                    Text(if (remaining >= 0) "Remaining" else "Over Budget", style = MaterialTheme.typography.labelMedium)
                    Text(
                        MoneyMath.format(kotlin.math.abs(remaining)),
                        style = MaterialTheme.typography.titleMedium,
                        color = if (remaining >= 0) TriplyColors.Success else TriplyColors.Danger
                    )
                }
            }
        }
    }
}
