package com.triply.app.core.common

/**
 * Evaluates cached weather freshness so Triply never presents stale cached data as live weather.
 */
object WeatherFreshness {
    const val STALE_THRESHOLD_MILLIS: Long = 3L * 60L * 60L * 1000L // 3 hours

    enum class FreshnessState {
        FRESH,
        STALE,
        OFFLINE_CACHED
    }

    fun evaluate(fetchedAtEpochMillis: Long, nowEpochMillis: Long, isOnline: Boolean): FreshnessState {
        if (!isOnline) return FreshnessState.OFFLINE_CACHED
        val age = (nowEpochMillis - fetchedAtEpochMillis).coerceAtLeast(0L)
        return if (age >= STALE_THRESHOLD_MILLIS) FreshnessState.STALE else FreshnessState.FRESH
    }
}
