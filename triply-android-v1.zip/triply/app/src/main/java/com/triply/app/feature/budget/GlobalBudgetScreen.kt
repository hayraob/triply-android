package com.triply.app.feature.budget

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.triply.app.core.common.MoneyMath
import com.triply.app.core.data.TriplyRepository
import com.triply.app.core.designsystem.EmptyStateView
import com.triply.app.core.designsystem.SectionHeader
import com.triply.app.core.designsystem.TriplyCard
import com.triply.app.core.designsystem.TriplyColors
import com.triply.app.core.designsystem.TriplySpacing

@Composable
fun GlobalBudgetScreen(
    repository: TriplyRepository,
    onOpenTripBudget: (String) -> Unit
) {
    val trips by repository.observeTrips().collectAsState(initial = emptyList())
    val expenses by repository.observeAllExpenses().collectAsState(initial = emptyList())

    val totalPlanned = trips.sumOf { it.plannedBudgetMinor }
    val totalActual = expenses.sumOf { it.amountMinor }
    val remaining = totalPlanned - totalActual

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(TriplySpacing.Lg),
        verticalArrangement = Arrangement.spacedBy(TriplySpacing.Md)
    ) {
        Text("Budget Overview", style = MaterialTheme.typography.headlineMedium)

        TriplyCard {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("Total Planned", style = MaterialTheme.typography.labelMedium)
                    Text(MoneyMath.format(totalPlanned), style = MaterialTheme.typography.titleMedium)
                }
                Column {
                    Text("Total Actual", style = MaterialTheme.typography.labelMedium)
                    Text(MoneyMath.format(totalActual), style = MaterialTheme.typography.titleMedium)
                }
                Column {
                    Text(if (remaining >= 0) "Remaining" else "Over Budget", style = MaterialTheme.typography.labelMedium)
                    Text(
                        MoneyMath.format(kotlin.math.abs(remaining)),
                        style = MaterialTheme.typography.titleMedium,
                        color = if (remaining >= 0) TriplyColors.Success else TriplyColors.Danger
                    )
                }
            }
        }

        SectionHeader(title = "By Trip", subtitle = "Tap a trip to manage expenses, receipts, and group splits.")
        if (trips.isEmpty()) {
            EmptyStateView(title = "No trips yet", message = "Create a trip to start tracking planned and actual costs.")
        } else {
            trips.forEach { trip ->
                val spent = expenses.filter { it.tripId == trip.id }.sumOf { it.amountMinor }
                val rem = trip.plannedBudgetMinor - spent
                TriplyCard(modifier = Modifier.clickable { onOpenTripBudget(trip.id) }) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(trip.name, style = MaterialTheme.typography.titleMedium)
                            Text("Planned ${MoneyMath.format(trip.plannedBudgetMinor, trip.currencyCode)} • Actual ${MoneyMath.format(spent, trip.currencyCode)}", style = MaterialTheme.typography.bodyMedium)
                        }
                        Text(
                            text = if (rem >= 0) MoneyMath.format(rem, trip.currencyCode) else "-${MoneyMath.format(-rem, trip.currencyCode)}",
                            color = if (rem >= 0) TriplyColors.Success else TriplyColors.Danger,
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                }
            }
        }
    }
}
