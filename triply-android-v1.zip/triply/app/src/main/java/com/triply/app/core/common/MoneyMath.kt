package com.triply.app.core.common

import java.text.NumberFormat
import java.util.Locale
import kotlin.math.abs

/**
 * Exact integer minor-unit financial utilities.
 * For IDR, 1 minor unit == 1 Rupiah (zero decimal digits).
 * Never uses floating-point arithmetic for totals or splits.
 */
object MoneyMath {

    fun format(amountMinorUnits: Long, currencyCode: String = "IDR"): String {
        val sign = if (amountMinorUnits < 0) "-" else ""
        val absVal = abs(amountMinorUnits)
        return when (currencyCode.uppercase(Locale.ROOT)) {
            "IDR" -> {
                val nf = NumberFormat.getIntegerInstance(Locale("id", "ID"))
                "${sign}Rp ${nf.format(absVal)}"
            }
            "USD" -> {
                val dollars = absVal / 100
                val cents = absVal % 100
                "${sign}$${dollars}.${cents.toString().padStart(2, '0')}"
            }
            else -> {
                val nf = NumberFormat.getIntegerInstance(Locale.US)
                "$sign$currencyCode ${nf.format(absVal)}"
            }
        }
    }

    data class EqualSplitResult(
        val shares: Map<String, Long>,
        val baseShare: Long,
        val remainder: Long,
        val remainderRecipients: List<String>
    )

    /**
     * Splits [totalMinorUnits] across [participantIds] deterministically without losing any remainder.
     * Any remainder (+1 unit each) is distributed to the first [remainder] participants in sorted order
     * and explicitly reported so the UI can show rounding differences transparently.
     */
    fun splitEqually(totalMinorUnits: Long, participantIds: List<String>): EqualSplitResult {
        require(participantIds.isNotEmpty()) { "At least one participant is required to split." }
        require(totalMinorUnits >= 0L) { "Amount cannot be negative." }

        val distinct = participantIds.distinct()
        val count = distinct.size.toLong()
        val base = totalMinorUnits / count
        val remainder = totalMinorUnits % count

        val shares = LinkedHashMap<String, Long>(distinct.size)
        val remainderRecipients = mutableListOf<String>()
        distinct.forEachIndexed { idx, id ->
            val extra = if (idx < remainder) 1L else 0L
            if (extra > 0L) remainderRecipients.add(id)
            shares[id] = base + extra
        }
        return EqualSplitResult(
            shares = shares,
            baseShare = base,
            remainder = remainder,
            remainderRecipients = remainderRecipients
        )
    }

    data class ParticipantBalance(
        val participantId: String,
        val participantName: String,
        val totalPaid: Long,
        val totalShare: Long,
        val settlementsPaid: Long,
        val settlementsReceived: Long
    ) {
        /** Positive means others owe this participant; negative means this participant owes others. */
        val netBalance: Long
            get() = (totalPaid - totalShare) + settlementsPaid - settlementsReceived
    }

    data class TransferSuggestion(
        val fromParticipantId: String,
        val fromName: String,
        val toParticipantId: String,
        val toName: String,
        val amount: Long
    )

    /**
     * Computes minimal "who owes whom" settlement transfers from exact integer balances.
     */
    fun computeSettlementTransfers(balances: List<ParticipantBalance>): List<TransferSuggestion> {
        data class Entry(val id: String, val name: String, var amount: Long)

        val debtors = balances
            .filter { it.netBalance < 0L }
            .map { Entry(it.participantId, it.participantName, -it.netBalance) }
            .sortedByDescending { it.amount }
            .toMutableList()

        val creditors = balances
            .filter { it.netBalance > 0L }
            .map { Entry(it.participantId, it.participantName, it.netBalance) }
            .sortedByDescending { it.amount }
            .toMutableList()

        val transfers = mutableListOf<TransferSuggestion>()
        var dIdx = 0
        var cIdx = 0
        while (dIdx < debtors.size && cIdx < creditors.size) {
            val debtor = debtors[dIdx]
            val creditor = creditors[cIdx]
            val transferAmount = minOf(debtor.amount, creditor.amount)
            if (transferAmount > 0L) {
                transfers.add(
                    TransferSuggestion(
                        fromParticipantId = debtor.id,
                        fromName = debtor.name,
                        toParticipantId = creditor.id,
                        toName = creditor.name,
                        amount = transferAmount
                    )
                )
            }
            debtor.amount -= transferAmount
            creditor.amount -= transferAmount
            if (debtor.amount == 0L) dIdx++
            if (creditor.amount == 0L) cIdx++
        }
        return transfers
    }
}
