package com.triply.app.feature.budget

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.PersonAdd
import androidx.compose.material.icons.outlined.Receipt
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.unit.dp
import com.triply.app.core.common.MoneyMath
import com.triply.app.core.data.TriplyRepository
import com.triply.app.core.database.ExpenseCategory
import com.triply.app.core.database.ExpenseEntity
import com.triply.app.core.database.ParticipantEntity
import com.triply.app.core.database.SettlementEntity
import com.triply.app.core.database.TripEntity
import com.triply.app.core.designsystem.ConfirmDestructiveDialog
import com.triply.app.core.designsystem.EmptyStateView
import com.triply.app.core.designsystem.SectionHeader
import com.triply.app.core.designsystem.TriplyCard
import com.triply.app.core.designsystem.TriplyColors
import com.triply.app.core.designsystem.TriplySpacing
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.util.UUID

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TripBudgetTab(
    repository: TriplyRepository,
    tripId: String,
    trip: TripEntity?
) {
    val expenses by repository.observeExpenses(tripId).collectAsState(initial = emptyList())
    val participants by repository.observeParticipants(tripId).collectAsState(initial = emptyList())
    val shares by repository.observeExpenseShares(tripId).collectAsState(initial = emptyList())
    val settlements by repository.observeSettlements(tripId).collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()

    var showAddExpense by remember { mutableStateOf(false) }
    var showAddParticipant by remember { mutableStateOf(false) }
    var pendingDeleteExpense by remember { mutableStateOf<ExpenseEntity?>(null) }

    val currency = trip?.currencyCode ?: "IDR"
    val planned = trip?.plannedBudgetMinor ?: 0L
    val actual = expenses.sumOf { it.amountMinor }
    val remaining = planned - actual

    val categoryTotals = ExpenseCategory.entries.map { cat ->
        cat to expenses.filter { it.category == cat.name }.sumOf { it.amountMinor }
    }.filter { it.second > 0L }.sortedByDescending { it.second }

    // Group balances & who owes whom
    val balances = participants.map { p ->
        val paid = expenses.filter { it.paidByParticipantId == p.id }.sumOf { it.amountMinor }
        val owed = shares.filter { it.participantId == p.id }.sumOf { it.shareMinor }
        val sent = settlements.filter { it.fromParticipantId == p.id }.sumOf { it.amountMinor }
        val recv = settlements.filter { it.toParticipantId == p.id }.sumOf { it.amountMinor }
        MoneyMath.ParticipantBalance(p.id, p.name, paid, owed, sent, recv)
    }
    val transfers = MoneyMath.computeSettlementTransfers(balances)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(TriplySpacing.Lg),
        verticalArrangement = Arrangement.spacedBy(TriplySpacing.Md)
    ) {
        // Planned vs Actual Summary
        TriplyCard {
            Text("Planned vs. Actual ($currency)", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(TriplySpacing.Sm))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("Planned", style = MaterialTheme.typography.labelMedium)
                    Text(MoneyMath.format(planned, currency), style = MaterialTheme.typography.titleMedium)
                }
                Column {
                    Text("Actual", style = MaterialTheme.typography.labelMedium)
                    Text(MoneyMath.format(actual, currency), style = MaterialTheme.typography.titleMedium)
                }
                Column {
                    Text(if (remaining >= 0) "Remaining" else "Over Budget", style = MaterialTheme.typography.labelMedium)
                    Text(
                        MoneyMath.format(kotlin.math.abs(remaining), currency),
                        style = MaterialTheme.typography.titleMedium,
                        color = if (remaining >= 0) TriplyColors.Success else TriplyColors.Danger
                    )
                }
            }
            Spacer(Modifier.height(TriplySpacing.Md))
            Row(horizontalArrangement = Arrangement.spacedBy(TriplySpacing.Sm)) {
                Button(onClick = { showAddExpense = true }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Outlined.Add, contentDescription = null)
                    Text(" Add Expense")
                }
                OutlinedButton(onClick = { showAddParticipant = true }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Outlined.PersonAdd, contentDescription = null)
                    Text(" Participant")
                }
            }
        }

        // Category Breakdown Chart (real Compose Canvas bars, zero fake chart)
        if (categoryTotals.isNotEmpty()) {
            TriplyCard {
                SectionHeader(title = "Spending by Category")
                val maxVal = categoryTotals.maxOf { it.second }.coerceAtLeast(1L)
                categoryTotals.forEach { (cat, total) ->
                    val fraction = (total.toFloat() / maxVal.toFloat()).coerceIn(0.05f, 1f)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(cat.label, style = MaterialTheme.typography.bodyMedium)
                        Text(MoneyMath.format(total, currency), style = MaterialTheme.typography.labelLarge)
                    }
                    Canvas(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                            .padding(vertical = 2.dp)
                    ) {
                        drawRoundRect(
                            color = TriplyColors.SurfaceSecondary,
                            size = size,
                            cornerRadius = CornerRadius(6f, 6f)
                        )
                        drawRoundRect(
                            color = TriplyColors.Accent,
                            size = Size(size.width * fraction, size.height),
                            cornerRadius = CornerRadius(6f, 6f)
                        )
                    }
                    Spacer(Modifier.height(TriplySpacing.Xs))
                }
            }
        }

        // Group Split & Settlements (Module 10)
        if (participants.isNotEmpty()) {
            TriplyCard {
                SectionHeader(title = "Group Split & Balances (${participants.size} people)")
                balances.forEach { b ->
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(b.participantName, style = MaterialTheme.typography.titleMedium)
                            Text("Paid ${MoneyMath.format(b.totalPaid, currency)} • Share ${MoneyMath.format(b.totalShare, currency)}", style = MaterialTheme.typography.labelMedium)
                        }
                        Text(
                            text = when {
                                b.netBalance > 0 -> "+${MoneyMath.format(b.netBalance, currency)}"
                                b.netBalance < 0 -> "-${MoneyMath.format(-b.netBalance, currency)}"
                                else -> "Settled"
                            },
                            color = when {
                                b.netBalance > 0 -> TriplyColors.Success
                                b.netBalance < 0 -> TriplyColors.Danger
                                else -> TriplyColors.TextSecondary
                            },
                            style = MaterialTheme.typography.titleMedium
                        )
                    }
                    Spacer(Modifier.height(TriplySpacing.Xs))
                }

                if (transfers.isNotEmpty()) {
                    Spacer(Modifier.height(TriplySpacing.Sm))
                    Text("Suggested Settlements", style = MaterialTheme.typography.labelLarge, color = TriplyColors.Accent)
                    transfers.forEach { t ->
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${t.fromName} -> ${t.toName}: ${MoneyMath.format(t.amount, currency)}", style = MaterialTheme.typography.bodyMedium)
                            TextButton(onClick = {
                                scope.launch {
                                    repository.saveSettlement(
                                        SettlementEntity(
                                            id = UUID.randomUUID().toString(),
                                            tripId = tripId,
                                            fromParticipantId = t.fromParticipantId,
                                            toParticipantId = t.toParticipantId,
                                            amountMinor = t.amount,
                                            dateIso = LocalDate.now().toString(),
                                            note = "Recorded settlement"
                                        )
                                    )
                                }
                            }) { Text("Mark Settled") }
                        }
                    }
                }
            }
        }

        // Expense Records List
        SectionHeader(title = "Expenses (${expenses.size})")
        if (expenses.isEmpty()) {
            EmptyStateView(
                icon = Icons.Outlined.Receipt,
                title = "No expenses recorded",
                message = "Track actual spending separately from your planned budget.",
                actionLabel = "Add First Expense",
                onAction = { showAddExpense = true }
            )
        } else {
            expenses.forEach { exp ->
                val catLabel = runCatching { ExpenseCategory.valueOf(exp.category).label }.getOrDefault(exp.category)
                val payerName = participants.firstOrNull { it.id == exp.paidByParticipantId }?.name
                val expShares = shares.filter { it.expenseId == exp.id }
                val remainderCount = expShares.count { it.includesRemainderUnit }

                TriplyCard {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(exp.description.ifBlank { catLabel }, style = MaterialTheme.typography.titleMedium)
                            Text("$catLabel • ${exp.dateIso}${if (payerName != null) " • Paid by $payerName" else ""}", style = MaterialTheme.typography.bodyMedium)
                            if (remainderCount > 0) {
                                Text("Includes +1 unit rounding remainder on $remainderCount share(s).", style = MaterialTheme.typography.labelMedium, color = TriplyColors.Warning)
                            }
                            if (!exp.receiptPath.isNullOrBlank()) {
                                Text("Receipt photo attached", style = MaterialTheme.typography.labelMedium, color = TriplyColors.Success)
                            }
                        }
                        Column {
                            Text(MoneyMath.format(exp.amountMinor, exp.currencyCode), style = MaterialTheme.typography.titleMedium)
                            IconButton(onClick = { pendingDeleteExpense = exp }) {
                                Icon(Icons.Outlined.Delete, contentDescription = "Delete expense", tint = TriplyColors.Danger)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddExpense) {
        var amountText by remember { mutableStateOf("") }
        var desc by remember { mutableStateOf("") }
        var dateIso by remember { mutableStateOf(LocalDate.now().toString()) }
        var category by remember { mutableStateOf(ExpenseCategory.FOOD) }
        var paidById by remember { mutableStateOf(participants.firstOrNull()?.id) }
        var receiptPath by remember { mutableStateOf<String?>(null) }

        val receiptPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
            if (uri != null) receiptPath = repository.copyMediaToAppStorage(uri, "receipt")
        }

        AlertDialog(
            onDismissRequest = { showAddExpense = false },
            containerColor = TriplyColors.Surface,
            title = { Text("Add Expense") },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(TriplySpacing.Sm)
                ) {
                    OutlinedTextField(
                        value = amountText,
                        onValueChange = { amountText = it.filter { ch -> ch.isDigit() } },
                        label = { Text("Amount ($currency) *") },
                        singleLine = true
                    )
                    OutlinedTextField(value = desc, onValueChange = { desc = it }, label = { Text("Description") }, singleLine = true)
                    OutlinedTextField(value = dateIso, onValueChange = { dateIso = it }, label = { Text("Date (YYYY-MM-DD)") }, singleLine = true)
                    Text("Category", style = MaterialTheme.typography.labelMedium)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(TriplySpacing.Xs)) {
                        ExpenseCategory.entries.forEach { cat ->
                            FilterChip(selected = category == cat, onClick = { category = cat }, label = { Text(cat.label) })
                        }
                    }
                    if (participants.isNotEmpty()) {
                        Text("Paid By", style = MaterialTheme.typography.labelMedium)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(TriplySpacing.Xs)) {
                            participants.forEach { p ->
                                FilterChip(selected = paidById == p.id, onClick = { paidById = p.id }, label = { Text(p.name) })
                            }
                        }
                    }
                    OutlinedButton(onClick = {
                        receiptPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }) {
                        Text(if (receiptPath != null) "Receipt Attached (Change)" else "Attach Receipt Photo")
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    val amt = amountText.toLongOrNull() ?: 0L
                    if (amt > 0L) {
                        scope.launch {
                            val exp = ExpenseEntity(
                                id = UUID.randomUUID().toString(),
                                tripId = tripId,
                                dateIso = dateIso,
                                category = category.name,
                                amountMinor = amt,
                                currencyCode = currency,
                                description = desc.trim(),
                                paidByParticipantId = paidById,
                                receiptPath = receiptPath,
                                createdAtEpochMillis = System.currentTimeMillis()
                            )
                            repository.saveExpenseEqualSplit(exp, participants.map { it.id })
                            showAddExpense = false
                        }
                    }
                }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { showAddExpense = false }) { Text("Cancel") }
            }
        )
    }

    if (showAddParticipant) {
        var pName by remember { mutableStateOf("") }
        var pPhone by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAddParticipant = false },
            containerColor = TriplyColors.Surface,
            title = { Text("Add Trip Participant") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(TriplySpacing.Sm)) {
                    OutlinedTextField(value = pName, onValueChange = { pName = it }, label = { Text("Name *") }, singleLine = true)
                    OutlinedTextField(value = pPhone, onValueChange = { pPhone = it }, label = { Text("Phone (optional)") }, singleLine = true)
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (pName.isNotBlank()) {
                        scope.launch {
                            repository.saveParticipant(
                                ParticipantEntity(
                                    id = UUID.randomUUID().toString(),
                                    tripId = tripId,
                                    name = pName.trim(),
                                    phone = pPhone.trim()
                                )
                            )
                            showAddParticipant = false
                        }
                    }
                }) { Text("Add") }
            },
            dismissButton = {
                TextButton(onClick = { showAddParticipant = false }) { Text("Cancel") }
            }
        )
    }

    pendingDeleteExpense?.let { exp ->
        ConfirmDestructiveDialog(
            title = "Delete expense?",
            message = "Remove '${exp.description.ifBlank { exp.category }}' (${MoneyMath.format(exp.amountMinor, exp.currencyCode)})?",
            onConfirm = {
                scope.launch { repository.deleteExpense(exp.id) }
                pendingDeleteExpense = null
            },
            onDismiss = { pendingDeleteExpense = null }
        )
    }
}
