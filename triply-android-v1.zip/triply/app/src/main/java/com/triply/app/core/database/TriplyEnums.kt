package com.triply.app.core.database

import kotlinx.serialization.Serializable

@Serializable
enum class ActivityCategory(val label: String) {
    HIKING("Hiking / Mountaineering"),
    BEACH("Beach"),
    CITY("City Sightseeing"),
    ROAD_TRIP("Road Trip"),
    CAMPING("Camping"),
    FAMILY("Family Trip"),
    BACKPACKING("Backpacking"),
    GENERAL("General / Custom")
}

@Serializable
enum class HikingGearReadiness(val label: String) {
    OWN_ALL("I already own all required gear"),
    OWN_SOME("I own some gear and need to rent, borrow, or buy the rest"),
    OWN_NONE("I do not own the gear yet")
}

@Serializable
enum class GearOwnershipStatus(val label: String) {
    OWNED("Owned"),
    RENT("Rent"),
    BUY("Buy"),
    BORROW("Borrow")
}

@Serializable
enum class ExpenseCategory(val label: String) {
    TRANSPORT("Transport"),
    FUEL("Fuel"),
    ACCOMMODATION("Accommodation"),
    GEAR_RENTAL("Gear Rental"),
    TICKETS("Tickets / Entrance Fees"),
    FOOD("Food & Drinks"),
    PARKING_TOLLS("Parking & Tolls"),
    SHOPPING("Shopping"),
    EMERGENCY_FUND("Emergency Fund"),
    OTHER("Other")
}

@Serializable
enum class ReservationStatus(val label: String) {
    NOT_BOOKED("Not Booked"),
    PENDING("Pending"),
    CONFIRMED("Confirmed"),
    CANCELLED("Cancelled")
}

@Serializable
enum class PaymentStatus(val label: String) {
    UNPAID("Unpaid"),
    DEPOSIT_PAID("Deposit Paid"),
    PAID_IN_FULL("Paid in Full")
}

@Serializable
enum class TransportMode(val label: String, val usesFuel: Boolean) {
    PRIVATE_MOTORCYCLE("Private Motorcycle", true),
    PRIVATE_CAR("Private Car", true),
    PUBLIC_TRANSPORT("Public Transport", false),
    RENTAL_MOTORCYCLE("Rental Motorcycle", true),
    RENTAL_CAR("Rental Car", true),
    CUSTOM("Custom Mode", false)
}

@Serializable
enum class ReminderType(val label: String) {
    PREP_H7("H-7 Preparation"),
    PREP_H3("H-3 Preparation"),
    PREP_H1("H-1 Preparation"),
    DEPARTURE("Departure"),
    ACTIVITY_START("Activity Start"),
    MEAL_REST("Meal / Rest"),
    HOTEL_CHECKIN("Hotel Check-in"),
    HOTEL_CHECKOUT("Hotel Check-out"),
    RETURN_JOURNEY("Return Journey"),
    CUSTOM("Custom Reminder")
}

@Serializable
enum class OfflineRegionStatus(val label: String) {
    QUEUED("Queued"),
    DOWNLOADING("Downloading"),
    PAUSED("Paused"),
    DOWNLOADED("Downloaded"),
    FAILED("Failed")
}
