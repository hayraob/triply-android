package com.triply.app.core.data.backup

import android.content.Context
import android.net.Uri
import androidx.room.withTransaction
import com.triply.app.core.database.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.ByteArrayOutputStream
import java.io.File
import java.security.MessageDigest
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

const val TRIPLY_ARCHIVE_SCHEMA_VERSION = 1

@Serializable
data class ArchiveManifest(
    val schemaVersion: Int = TRIPLY_ARCHIVE_SCHEMA_VERSION,
    val archiveType: String, // "FULL_BACKUP" or "SINGLE_TRIP"
    val appVersion: String = "1.0.0",
    val createdAtEpochMillis: Long,
    val tripCount: Int,
    val attachmentCount: Int,
    val dataSha256: String
)

@Serializable
data class FullBackupPayload(
    val trips: List<TripEntity>,
    val destinations: List<DestinationEntity>,
    val blocks: List<TripBlockEntity>,
    val savedRoutes: List<SavedRouteEntity>,
    val participants: List<ParticipantEntity>,
    val expenses: List<ExpenseEntity>,
    val expenseShares: List<ExpenseShareEntity>,
    val settlements: List<SettlementEntity>,
    val packingItems: List<PackingItemEntity>,
    val accommodations: List<AccommodationEntity>,
    val transportPlans: List<TransportPlanEntity>,
    val reminders: List<ReminderEntity>,
    val weatherCache: List<WeatherCacheEntity>,
    val emergencyContacts: List<EmergencyContactEntity>,
    val journalEntries: List<JournalEntryEntity>,
    val whatIfScenarios: List<WhatIfScenarioEntity>
)

@Serializable
data class SingleTripExportPayload(
    val trip: TripEntity,
    val destinations: List<DestinationEntity>,
    val blocks: List<TripBlockEntity>,
    val savedRoutes: List<SavedRouteEntity>,
    val participants: List<ParticipantEntity>,
    val expenses: List<ExpenseEntity>,
    val expenseShares: List<ExpenseShareEntity>,
    val settlements: List<SettlementEntity>,
    val packingItems: List<PackingItemEntity>,
    val accommodations: List<AccommodationEntity>,
    val transportPlans: List<TransportPlanEntity>,
    val reminders: List<ReminderEntity>,
    val emergencyContacts: List<EmergencyContactEntity>,
    val journalEntries: List<JournalEntryEntity>
)

data class ArchivePreview(
    val manifest: ArchiveManifest,
    val summaryTitle: String,
    val missingAttachments: Int = 0
)

class TriplyArchiveManager(
    private val context: Context,
    private val db: TriplyDatabase
) {
    private val json = Json {
        prettyPrint = true
        ignoreUnknownKeys = true
    }

    suspend fun exportFullBackup(destinationUri: Uri): Result<ArchiveManifest> = withContext(Dispatchers.IO) {
        runCatching {
            val payload = FullBackupPayload(
                trips = db.tripDao().getAllTripsOnce(),
                destinations = db.blockAndDestinationDao().getAllDestinationsOnce(),
                blocks = db.blockAndDestinationDao().getAllBlocksOnce(),
                savedRoutes = db.blockAndDestinationDao().getAllSavedRoutesOnce(),
                participants = db.budgetAndGroupDao().getAllParticipantsOnce(),
                expenses = db.budgetAndGroupDao().getAllExpensesOnce(),
                expenseShares = db.budgetAndGroupDao().getAllExpenseSharesOnce(),
                settlements = db.budgetAndGroupDao().getAllSettlementsOnce(),
                packingItems = db.logisticsDao().getAllPackingItemsOnce(),
                accommodations = db.logisticsDao().getAllAccommodationsOnce(),
                transportPlans = db.logisticsDao().getAllTransportPlansOnce(),
                reminders = db.safetyAndJournalDao().getAllRemindersOnce(),
                weatherCache = db.safetyAndJournalDao().getAllWeatherOnce(),
                emergencyContacts = db.safetyAndJournalDao().getAllEmergencyContactsOnce(),
                journalEntries = db.safetyAndJournalDao().getAllJournalEntriesOnce(),
                whatIfScenarios = db.safetyAndJournalDao().getAllWhatIfScenariosOnce()
            )
            val dataBytes = json.encodeToString(payload).toByteArray(Charsets.UTF_8)
            val attachments = collectExistingMediaFiles(payload.expenses, payload.accommodations, payload.journalEntries)
            val manifest = ArchiveManifest(
                archiveType = "FULL_BACKUP",
                createdAtEpochMillis = System.currentTimeMillis(),
                tripCount = payload.trips.size,
                attachmentCount = attachments.size,
                dataSha256 = sha256Hex(dataBytes)
            )
            writeZip(destinationUri, manifest, dataBytes, attachments)
            manifest
        }
    }

    suspend fun exportSingleTrip(tripId: String, destinationUri: Uri): Result<ArchiveManifest> = withContext(Dispatchers.IO) {
        runCatching {
            val trip = db.tripDao().getTrip(tripId) ?: error("Trip not found.")
            val expenses = db.budgetAndGroupDao().getExpensesOnce(tripId)
            val shares = expenses.flatMap { db.budgetAndGroupDao().getSharesForExpense(it.id) }
            val accommodations = db.logisticsDao().getAccommodationsOnce(tripId)
            val journal = db.safetyAndJournalDao().getJournalEntriesOnce(tripId)

            val payload = SingleTripExportPayload(
                trip = trip,
                destinations = db.blockAndDestinationDao().getDestinationsOnce(tripId),
                blocks = db.blockAndDestinationDao().getBlocksOnce(tripId),
                savedRoutes = db.blockAndDestinationDao().getSavedRoutesOnce(tripId),
                participants = db.budgetAndGroupDao().getParticipantsOnce(tripId),
                expenses = expenses,
                expenseShares = shares,
                settlements = db.budgetAndGroupDao().getSettlementsOnce(tripId),
                packingItems = db.logisticsDao().getPackingItemsOnce(tripId),
                accommodations = accommodations,
                transportPlans = db.logisticsDao().getTransportPlansOnce(tripId),
                reminders = db.safetyAndJournalDao().getRemindersOnce(tripId),
                emergencyContacts = db.safetyAndJournalDao().getEmergencyContactsOnce(tripId),
                journalEntries = journal
            )
            val dataBytes = json.encodeToString(payload).toByteArray(Charsets.UTF_8)
            val attachments = collectExistingMediaFiles(expenses, accommodations, journal)
            val manifest = ArchiveManifest(
                archiveType = "SINGLE_TRIP",
                createdAtEpochMillis = System.currentTimeMillis(),
                tripCount = 1,
                attachmentCount = attachments.size,
                dataSha256 = sha256Hex(dataBytes)
            )
            writeZip(destinationUri, manifest, dataBytes, attachments)
            manifest
        }
    }

    suspend fun inspectArchive(sourceUri: Uri): Result<ArchivePreview> = withContext(Dispatchers.IO) {
        runCatching {
            val entries = readZipEntries(sourceUri)
            val manifestBytes = entries["manifest.json"] ?: error("Invalid archive: missing manifest.json.")
            val dataBytes = entries["data.json"] ?: error("Invalid archive: missing data.json.")
            val manifest = json.decodeFromString<ArchiveManifest>(manifestBytes.toString(Charsets.UTF_8))
            if (manifest.schemaVersion > TRIPLY_ARCHIVE_SCHEMA_VERSION) {
                error("Unsupported archive schema version ${manifest.schemaVersion}. Update Triply to import.")
            }
            val actualHash = sha256Hex(dataBytes)
            if (actualHash != manifest.dataSha256) {
                error("Integrity check failed: archive data checksum does not match manifest.")
            }
            val summaryTitle = if (manifest.archiveType == "SINGLE_TRIP") {
                val payload = json.decodeFromString<SingleTripExportPayload>(dataBytes.toString(Charsets.UTF_8))
                payload.trip.name
            } else {
                "Full Backup (${manifest.tripCount} trips)"
            }
            ArchivePreview(manifest = manifest, summaryTitle = summaryTitle)
        }
    }

    /**
     * Restores a validated FULL_BACKUP inside a single Room transaction so partial failure never corrupts the DB.
     */
    suspend fun restoreFullBackup(sourceUri: Uri): Result<Int> = withContext(Dispatchers.IO) {
        runCatching {
            val entries = readZipEntries(sourceUri)
            val manifest = json.decodeFromString<ArchiveManifest>(
                (entries["manifest.json"] ?: error("Missing manifest.json")).toString(Charsets.UTF_8)
            )
            require(manifest.archiveType == "FULL_BACKUP") { "Selected file is not a full backup archive." }
            val dataBytes = entries["data.json"] ?: error("Missing data.json")
            require(sha256Hex(dataBytes) == manifest.dataSha256) { "Backup checksum verification failed." }

            val payload = json.decodeFromString<FullBackupPayload>(dataBytes.toString(Charsets.UTF_8))
            restoreMediaFiles(entries)

            db.withTransaction {
                db.tripDao().deleteAllTrips()
                payload.trips.forEach { db.tripDao().upsertTrip(it) }
                db.blockAndDestinationDao().upsertDestinations(payload.destinations)
                db.blockAndDestinationDao().upsertBlocks(payload.blocks)
                payload.savedRoutes.forEach { db.blockAndDestinationDao().upsertSavedRoute(it) }
                db.budgetAndGroupDao().upsertParticipants(payload.participants)
                db.budgetAndGroupDao().upsertExpenses(payload.expenses)
                db.budgetAndGroupDao().upsertShares(payload.expenseShares)
                db.budgetAndGroupDao().upsertSettlements(payload.settlements)
                db.logisticsDao().upsertPackingItems(payload.packingItems)
                db.logisticsDao().upsertAccommodations(payload.accommodations)
                db.logisticsDao().upsertTransportPlans(payload.transportPlans)
                db.safetyAndJournalDao().upsertReminders(payload.reminders)
                payload.weatherCache.forEach { db.safetyAndJournalDao().upsertWeather(it) }
                db.safetyAndJournalDao().upsertEmergencyContacts(payload.emergencyContacts)
                db.safetyAndJournalDao().upsertJournalEntries(payload.journalEntries)
                payload.whatIfScenarios.forEach { db.safetyAndJournalDao().upsertWhatIfScenario(it) }
            }
            payload.trips.size
        }
    }

    /**
     * Imports a SINGLE_TRIP package as a brand-new trip with regenerated IDs by default (collision-safe).
     */
    suspend fun importSingleTripAsNew(sourceUri: Uri): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val entries = readZipEntries(sourceUri)
            val manifest = json.decodeFromString<ArchiveManifest>(
                (entries["manifest.json"] ?: error("Missing manifest.json")).toString(Charsets.UTF_8)
            )
            require(manifest.archiveType == "SINGLE_TRIP") { "Selected file is not a single-trip package." }
            val dataBytes = entries["data.json"] ?: error("Missing data.json")
            require(sha256Hex(dataBytes) == manifest.dataSha256) { "Trip package checksum verification failed." }

            val payload = json.decodeFromString<SingleTripExportPayload>(dataBytes.toString(Charsets.UTF_8))
            restoreMediaFiles(entries)

            val newTripId = UUID.randomUUID().toString()
            val participantIdMap = payload.participants.associate { it.id to UUID.randomUUID().toString() }
            val expenseIdMap = payload.expenses.associate { it.id to UUID.randomUUID().toString() }
            val blockIdMap = payload.blocks.associate { it.id to UUID.randomUUID().toString() }

            db.withTransaction {
                val now = System.currentTimeMillis()
                db.tripDao().upsertTrip(
                    payload.trip.copy(
                        id = newTripId,
                        name = "${payload.trip.name} (Imported)",
                        createdAtEpochMillis = now,
                        updatedAtEpochMillis = now
                    )
                )
                db.blockAndDestinationDao().upsertDestinations(
                    payload.destinations.map { it.copy(id = UUID.randomUUID().toString(), tripId = newTripId) }
                )
                db.blockAndDestinationDao().upsertBlocks(
                    payload.blocks.map { it.copy(id = blockIdMap[it.id] ?: UUID.randomUUID().toString(), tripId = newTripId) }
                )
                payload.savedRoutes.forEach {
                    db.blockAndDestinationDao().upsertSavedRoute(it.copy(id = UUID.randomUUID().toString(), tripId = newTripId))
                }
                db.budgetAndGroupDao().upsertParticipants(
                    payload.participants.map { it.copy(id = participantIdMap[it.id]!!, tripId = newTripId) }
                )
                db.budgetAndGroupDao().upsertExpenses(
                    payload.expenses.map {
                        it.copy(
                            id = expenseIdMap[it.id]!!,
                            tripId = newTripId,
                            paidByParticipantId = it.paidByParticipantId?.let { old -> participantIdMap[old] }
                        )
                    }
                )
                db.budgetAndGroupDao().upsertShares(
                    payload.expenseShares.mapNotNull { share ->
                        val newExp = expenseIdMap[share.expenseId] ?: return@mapNotNull null
                        val newPart = participantIdMap[share.participantId] ?: return@mapNotNull null
                        share.copy(id = UUID.randomUUID().toString(), expenseId = newExp, participantId = newPart)
                    }
                )
                db.budgetAndGroupDao().upsertSettlements(
                    payload.settlements.mapNotNull { s ->
                        val from = participantIdMap[s.fromParticipantId] ?: return@mapNotNull null
                        val to = participantIdMap[s.toParticipantId] ?: return@mapNotNull null
                        s.copy(id = UUID.randomUUID().toString(), tripId = newTripId, fromParticipantId = from, toParticipantId = to)
                    }
                )
                db.logisticsDao().upsertPackingItems(
                    payload.packingItems.map { it.copy(id = UUID.randomUUID().toString(), tripId = newTripId) }
                )
                db.logisticsDao().upsertAccommodations(
                    payload.accommodations.map { it.copy(id = UUID.randomUUID().toString(), tripId = newTripId) }
                )
                db.logisticsDao().upsertTransportPlans(
                    payload.transportPlans.map { it.copy(id = UUID.randomUUID().toString(), tripId = newTripId) }
                )
                db.safetyAndJournalDao().upsertReminders(
                    payload.reminders.map { it.copy(id = UUID.randomUUID().toString(), tripId = newTripId) }
                )
                db.safetyAndJournalDao().upsertEmergencyContacts(
                    payload.emergencyContacts.map { it.copy(id = UUID.randomUUID().toString(), tripId = newTripId) }
                )
                db.safetyAndJournalDao().upsertJournalEntries(
                    payload.journalEntries.map {
                        it.copy(
                            id = UUID.randomUUID().toString(),
                            tripId = newTripId,
                            blockId = it.blockId?.let { old -> blockIdMap[old] }
                        )
                    }
                )
            }
            newTripId
        }
    }

    private fun collectExistingMediaFiles(
        expenses: List<ExpenseEntity>,
        accommodations: List<AccommodationEntity>,
        journal: List<JournalEntryEntity>
    ): List<File> {
        val paths = mutableSetOf<String>()
        expenses.mapNotNullTo(paths) { it.receiptPath }
        accommodations.mapNotNullTo(paths) { it.bookingProofPath }
        journal.forEach { entry ->
            runCatching { json.decodeFromString<List<String>>(entry.mediaPathsJson) }
                .getOrDefault(emptyList())
                .forEach { paths.add(it) }
        }
        return paths.map { File(it) }.filter { it.exists() && it.isFile }
    }

    private fun writeZip(uri: Uri, manifest: ArchiveManifest, dataBytes: ByteArray, attachments: List<File>) {
        context.contentResolver.openOutputStream(uri)?.use { os ->
            ZipOutputStream(os).use { zos ->
                zos.putNextEntry(ZipEntry("manifest.json"))
                zos.write(json.encodeToString(manifest).toByteArray(Charsets.UTF_8))
                zos.closeEntry()

                zos.putNextEntry(ZipEntry("data.json"))
                zos.write(dataBytes)
                zos.closeEntry()

                attachments.forEach { file ->
                    zos.putNextEntry(ZipEntry("media/${file.name}"))
                    file.inputStream().use { it.copyTo(zos) }
                    zos.closeEntry()
                }
            }
        } ?: error("Could not open output stream for selected file.")
    }

    private fun readZipEntries(uri: Uri): Map<String, ByteArray> {
        val result = LinkedHashMap<String, ByteArray>()
        context.contentResolver.openInputStream(uri)?.use { input ->
            ZipInputStream(input).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    if (!entry.isDirectory) {
                        val baos = ByteArrayOutputStream()
                        zis.copyTo(baos)
                        result[entry.name] = baos.toByteArray()
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
        } ?: error("Could not open input stream for selected file.")
        return result
    }

    private fun restoreMediaFiles(entries: Map<String, ByteArray>) {
        val mediaDir = File(context.filesDir, "media").apply { mkdirs() }
        entries.filterKeys { it.startsWith("media/") }.forEach { (name, bytes) ->
            val fileName = name.removePrefix("media/").substringAfterLast('/')
            if (fileName.isNotBlank()) {
                File(mediaDir, fileName).writeBytes(bytes)
            }
        }
    }

    companion object {
        fun sha256Hex(bytes: ByteArray): String {
            val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
            return digest.joinToString("") { "%02x".format(it) }
        }
    }
}
