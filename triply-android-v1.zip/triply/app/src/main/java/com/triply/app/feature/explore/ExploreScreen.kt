package com.triply.app.feature.explore

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AddLocationAlt
import androidx.compose.material.icons.outlined.DownloadForOffline
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.triply.app.core.data.TriplyRepository
import com.triply.app.core.data.network.GeocodeOutcome
import com.triply.app.core.data.network.GeocodedPlace
import com.triply.app.core.database.DestinationEntity
import com.triply.app.core.designsystem.EmptyStateView
import com.triply.app.core.designsystem.ErrorBanner
import com.triply.app.core.designsystem.TriplyCard
import com.triply.app.core.designsystem.TriplyColors
import com.triply.app.core.designsystem.TriplySpacing
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.util.UUID

@Composable
fun ExploreScreen(
    repository: TriplyRepository,
    isOnline: Boolean,
    onOpenOfflineMaps: () -> Unit
) {
    val trips by repository.observeTrips().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()

    var query by rememberSaveable { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var errorMsg by remember { mutableStateOf<String?>(null) }
    var results by remember { mutableStateOf<List<GeocodedPlace>>(emptyList()) }
    var selectedPlaceForTrip by remember { mutableStateOf<GeocodedPlace?>(null) }
    var statusNotice by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(query, isOnline) {
        errorMsg = null
        if (query.trim().length < 2) {
            results = emptyList()
            return@LaunchedEffect
        }
        if (!isOnline) {
            errorMsg = "Place search requires an internet connection. Offline maps and saved trip destinations remain available."
            return@LaunchedEffect
        }
        delay(600)
        isLoading = true
        when (val out = repository.openMeteoClient.searchPlaces(query)) {
            is GeocodeOutcome.Success -> results = out.places
            is GeocodeOutcome.Error -> errorMsg = out.message
        }
        isLoading = false
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(TriplySpacing.Lg),
        verticalArrangement = Arrangement.spacedBy(TriplySpacing.Md)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Explore", style = MaterialTheme.typography.headlineMedium)
            OutlinedButton(onClick = onOpenOfflineMaps) {
                Icon(Icons.Outlined.DownloadForOffline, contentDescription = null)
                Text(" Offline Maps")
            }
        }

        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            label = { Text("Search destinations (Open-Meteo Geocoding)") },
            leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        statusNotice?.let {
            Text(it, color = TriplyColors.Success, style = MaterialTheme.typography.bodyMedium)
        }
        errorMsg?.let { ErrorBanner(message = it) }
        if (isLoading) CircularProgressIndicator(color = TriplyColors.Accent)

        if (!isLoading && results.isEmpty() && errorMsg == null) {
            EmptyStateView(
                title = "Search real destinations",
                message = "Type at least 2 characters to search places via Open-Meteo Geocoding (non-commercial free tier) and add them with exact coordinates to any trip."
            )
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(TriplySpacing.Sm)) {
                items(results) { place ->
                    TriplyCard {
                        Text(place.displayLabel, style = MaterialTheme.typography.titleMedium)
                        Text(
                            "Coordinates: %.4f, %.4f".format(place.latitude, place.longitude),
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Spacer(Modifier.height(TriplySpacing.Sm))
                        Button(onClick = { selectedPlaceForTrip = place }) {
                            Icon(Icons.Outlined.AddLocationAlt, contentDescription = null)
                            Text(" Add to Existing Trip")
                        }
                    }
                }
            }
        }
    }

    selectedPlaceForTrip?.let { place ->
        AlertDialog(
            onDismissRequest = { selectedPlaceForTrip = null },
            containerColor = TriplyColors.Surface,
            title = { Text("Add '${place.name}' to Trip") },
            text = {
                if (trips.isEmpty()) {
                    Text("No trips exist yet. Create a trip first from My Trips.")
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(TriplySpacing.Xs)) {
                        trips.forEach { trip ->
                            OutlinedButton(
                                onClick = {
                                    scope.launch {
                                        val currentDests = repository.observeDestinations(trip.id).first()
                                        repository.saveDestination(
                                            DestinationEntity(
                                                id = UUID.randomUUID().toString(),
                                                tripId = trip.id,
                                                name = place.name,
                                                address = place.displayLabel,
                                                latitude = place.latitude,
                                                longitude = place.longitude,
                                                orderIndex = currentDests.size
                                            )
                                        )
                                        statusNotice = "Added ${place.name} to '${trip.name}'."
                                        selectedPlaceForTrip = null
                                    }
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(trip.name)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { selectedPlaceForTrip = null }) { Text("Close") }
            }
        )
    }
}
