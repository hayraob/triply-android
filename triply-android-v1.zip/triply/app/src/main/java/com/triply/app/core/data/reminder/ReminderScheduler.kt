package com.triply.app.core.data.reminder

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.triply.app.core.database.ReminderEntity
import com.triply.app.core.database.TriplyDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

object TriplyNotificationHelper {
    const val CHANNEL_ID = "triply_reminders"

    fun ensureChannel(context: Context) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val existing = manager.getNotificationChannel(CHANNEL_ID)
        if (existing == null) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Trip Reminders & Timeline",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Departure, preparation (H-7/H-3/H-1), and itinerary reminders."
            }
            manager.createNotificationChannel(channel)
        }
    }

    fun showReminderNotification(context: Context, reminderId: String, title: String, message: String) {
        ensureChannel(context)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) return
        }
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(message.ifBlank { "Scheduled Triply reminder" })
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()

        NotificationManagerCompat.from(context).notify(reminderId.hashCode(), notification)
    }
}

class ReminderAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getStringExtra("reminder_id") ?: return
        val title = intent.getStringExtra("reminder_title") ?: "Triply Reminder"
        val message = intent.getStringExtra("reminder_message") ?: ""
        TriplyNotificationHelper.showReminderNotification(context, id, title, message)
    }
}

class DeferrableReminderWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val id = inputData.getString("reminder_id") ?: return Result.failure()
        val title = inputData.getString("reminder_title") ?: "Triply Reminder"
        val message = inputData.getString("reminder_message") ?: ""
        TriplyNotificationHelper.showReminderNotification(applicationContext, id, title, message)
        return Result.success()
    }
}

class BootCompletedReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED || intent.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            val pending = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val db = TriplyDatabase.getInstance(context)
                    val active = db.safetyAndJournalDao().getActiveRemindersOnce()
                    val scheduler = ReminderScheduler(context)
                    val now = System.currentTimeMillis()
                    active.filter { it.triggerAtEpochMillis > now }.forEach { scheduler.schedule(it) }
                } finally {
                    pending.finish()
                }
            }
        }
    }
}

class ReminderScheduler(private val context: Context) {

    fun canScheduleExactAlarms(): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        return alarmManager.canScheduleExactAlarms()
    }

    /**
     * Schedules exact alarms via AlarmManager ONLY when user requested exact timing and permission is granted.
     * Falls back to WorkManager for deferrable preparation reminders or when exact alarm permission is denied.
     */
    fun schedule(reminder: ReminderEntity): String {
        val delayMs = reminder.triggerAtEpochMillis - System.currentTimeMillis()
        if (delayMs <= 0L) return "Trigger time is in the past; saved in timeline only."

        return if (reminder.useExactAlarm && canScheduleExactAlarms()) {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pendingIntent = buildAlarmPendingIntent(reminder)
            alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                reminder.triggerAtEpochMillis,
                pendingIntent
            )
            "Scheduled with Android AlarmManager (subject to device battery/Doze policies)."
        } else {
            val data = Data.Builder()
                .putString("reminder_id", reminder.id)
                .putString("reminder_title", reminder.title)
                .putString("reminder_message", reminder.message)
                .build()
            val request = OneTimeWorkRequestBuilder<DeferrableReminderWorker>()
                .setInitialDelay(delayMs, TimeUnit.MILLISECONDS)
                .setInputData(data)
                .build()
            WorkManager.getInstance(context).enqueueUniqueWork(
                "reminder_${reminder.id}",
                ExistingWorkPolicy.REPLACE,
                request
            )
            if (reminder.useExactAlarm) {
                "Exact alarm permission not granted; scheduled via WorkManager (timing may vary under Doze)."
            } else {
                "Scheduled via WorkManager (subject to Android battery optimization)."
            }
        }
    }

    fun cancel(reminder: ReminderEntity) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarmManager.cancel(buildAlarmPendingIntent(reminder))
        WorkManager.getInstance(context).cancelUniqueWork("reminder_${reminder.id}")
    }

    private fun buildAlarmPendingIntent(reminder: ReminderEntity): PendingIntent {
        val intent = Intent(context, ReminderAlarmReceiver::class.java).apply {
            putExtra("reminder_id", reminder.id)
            putExtra("reminder_title", reminder.title)
            putExtra("reminder_message", reminder.message)
        }
        return PendingIntent.getBroadcast(
            context,
            reminder.id.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }
}
