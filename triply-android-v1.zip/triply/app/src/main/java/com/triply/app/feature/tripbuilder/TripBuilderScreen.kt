package com.triply.app.feature.tripbuilder

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.ArrowDownward
import androidx.compose.material.icons.outlined.ArrowUpward
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.triply.app.core.common.TripDurationCalculator
import com.triply.app.core.data.TriplyRepository
import com.triply.app.core.database.ActivityCategory
import com.triply.app.core.database.DestinationEntity
import com.triply.app.core.database.HikingGearReadiness
import com.triply.app.core.database.TripBlockEntity
import com.triply.app.core.database.TripEntity
import com.triply.app.core.designsystem.SectionHeader
import com.triply.app.core.designsystem.TriplyCard
import com.triply.app.core.designsystem.TriplyColors
import com.triply.app.core.designsystem.TriplySpacing
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.time.LocalDate
import java.util.UUID

@Serializable
data class ActivityDynamicMetadata(
    val hikingGearReadiness: String? = null,
    val basecampName: String = "",
    val trailTicketsNote: String = "",
    val foodAndLogisticsNote: String = "",
    val tideAndSafetyNote: String = "",
    val waterActivityGear: String = "",
    val routeOrVehicleNote: String = "",
    val campsiteOrPermitNote: String = "",
    val familyAccessibilityNote: String = ""
)

data class EditableBlockDraft(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "",
    val destinationName: String = "",
    val category: ActivityCategory = ActivityCategory.GENERAL,
    val durationDays: Int = 1,
    val transferDaysBefore: Int = 0,
    val transferNotes: String = "",
    val estimatedCostMinor: Long = 0L,
    val notes: String = "",
    val metadata: ActivityDynamicMetadata = ActivityDynamicMetadata()
)

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun TripBuilderScreen(
    repository: TriplyRepository,
    tripIdOrNew: String,
    onBack: () -> Unit,
    onSaved: (String) -> Unit
) {
    val isEditing = tripIdOrNew != "new"
    val scope = rememberCoroutineScope()
    val json = remember { Json { ignoreUnknownKeys = true } }

    var name by rememberSaveable { mutableStateOf("") }
    var description by rememberSaveable { mutableStateOf("") }
    var startDateIso by rememberSaveable { mutableStateOf(LocalDate.now().plusDays(7).toString()) }
    var plannedBudgetText by rememberSaveable { mutableStateOf("0") }
    var validationError by remember { mutableStateOf<String?>(null) }

    val blocks = remember { mutableStateListOf<EditableBlockDraft>() }

    LaunchedEffect(tripIdOrNew) {
        if (isEditing) {
            val existingTrip = repository.observeTrip(tripIdOrNew).first()
            if (existingTrip != null) {
                name = existingTrip.name
                description = existingTrip.description
                startDateIso = existingTrip.startDateIso
                plannedBudgetText = existingTrip.plannedBudgetMinor.toString()
            }
            val existingBlocks = repository.observeBlocks(tripIdOrNew).first()
            blocks.clear()
            existingBlocks.forEach { b ->
                val cat = runCatching { ActivityCategory.valueOf(b.category) }.getOrDefault(ActivityCategory.GENERAL)
                val meta = runCatching { json.decodeFromString<ActivityDynamicMetadata>(b.activityMetadataJson) }
                    .getOrDefault(ActivityDynamicMetadata())
                blocks.add(
                    EditableBlockDraft(
                        id = b.id,
                        title = b.title,
                        destinationName = b.destinationName,
                        category = cat,
                        durationDays = b.durationDays,
                        transferDaysBefore = b.transferDaysBefore,
                        transferNotes = b.transferNotes,
                        estimatedCostMinor = b.estimatedCostMinor,
                        notes = b.notes,
                        metadata = meta
                    )
                )
            }
        }
    }

    val parsedStart = runCatching { LocalDate.parse(startDateIso) }.getOrNull()
    val durationSummary = TripDurationCalculator.calculate(
        parsedStart,
        blocks.map { TripDurationCalculator.BlockSpan(it.durationDays, it.transferDaysBefore) }
    )

    Scaffold(
        containerColor = TriplyColors.Background,
        topBar = {
            TopAppBar(
                title = { Text(if (isEditing) "Edit Trip" else "Create Trip") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = TriplyColors.Surface)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(TriplySpacing.Lg),
            verticalArrangement = Arrangement.spacedBy(TriplySpacing.Md)
        ) {
            if (!isEditing) {
                SectionHeader(title = "Editable Starting Templates", subtitle = "Optional starting points — every block remains fully editable.")
                Row(horizontalArrangement = Arrangement.spacedBy(TriplySpacing.Sm)) {
                    OutlinedButton(onClick = {
                        blocks.clear()
                        blocks += listOf(
                            EditableBlockDraft(title = "Mountain Trek", destinationName = "Basecamp & Summit", category = ActivityCategory.HIKING, durationDays = 3),
                            EditableBlockDraft(title = "Coastal Relax", destinationName = "Beach Coast", category = ActivityCategory.BEACH, durationDays = 3, transferDaysBefore = 0),
                            EditableBlockDraft(title = "City Highlights", destinationName = "City Center", category = ActivityCategory.CITY, durationDays = 1),
                            EditableBlockDraft(title = "Return Journey", destinationName = "Homebound", category = ActivityCategory.ROAD_TRIP, durationDays = 1)
                        )
                    }) {
                        Text("8-Day Multi-Activity")
                    }
                    OutlinedButton(onClick = {
                        blocks.clear()
                        blocks += listOf(
                            EditableBlockDraft(title = "Weekend Hike", destinationName = "Trailhead", category = ActivityCategory.HIKING, durationDays = 2)
                        )
                    }) {
                        Text("Weekend Hike")
                    }
                }
            }

            TriplyCard {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Trip Name *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(TriplySpacing.Sm))
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description (optional)") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(TriplySpacing.Sm))
                OutlinedTextField(
                    value = startDateIso,
                    onValueChange = { startDateIso = it },
                    label = { Text("Start Date (YYYY-MM-DD) *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(TriplySpacing.Sm))
                OutlinedTextField(
                    value = plannedBudgetText,
                    onValueChange = { plannedBudgetText = it.filter { ch -> ch.isDigit() } },
                    label = { Text("Planned Total Budget (IDR)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(TriplySpacing.Sm))
                Text(
                    text = "Calculated duration: ${durationSummary.totalTripDays} day(s) " +
                        "(${durationSummary.totalActivityDays} activity + ${durationSummary.totalTransferDays} transfer). " +
                        "End date: ${durationSummary.computedEndDate ?: startDateIso}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TriplyColors.Accent
                )
            }

            SectionHeader(
                title = "Itinerary Blocks (${blocks.size})",
                subtitle = "Add, edit, duplicate, reorder, and include transfer days.",
                actionLabel = "Add Block",
                onActionClick = {
                    blocks.add(EditableBlockDraft(title = "New Activity Block", destinationName = ""))
                }
            )

            blocks.forEachIndexed { index, draft ->
                TriplyCard {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Block ${index + 1}", style = MaterialTheme.typography.titleMedium)
                        Row {
                            IconButton(
                                enabled = index > 0,
                                onClick = {
                                    val moved = blocks.removeAt(index)
                                    blocks.add(index - 1, moved)
                                }
                            ) { Icon(Icons.Outlined.ArrowUpward, contentDescription = "Move up") }
                            IconButton(
                                enabled = index < blocks.lastIndex,
                                onClick = {
                                    val moved = blocks.removeAt(index)
                                    blocks.add(index + 1, moved)
                                }
                            ) { Icon(Icons.Outlined.ArrowDownward, contentDescription = "Move down") }
                            IconButton(
                                onClick = {
                                    blocks.add(index + 1, draft.copy(id = UUID.randomUUID().toString(), title = "${draft.title} (Copy)"))
                                }
                            ) { Icon(Icons.Outlined.ContentCopy, contentDescription = "Duplicate block") }
                            IconButton(
                                onClick = { blocks.removeAt(index) }
                            ) { Icon(Icons.Outlined.Delete, contentDescription = "Remove block", tint = TriplyColors.Danger) }
                        }
                    }

                    OutlinedTextField(
                        value = draft.title,
                        onValueChange = { blocks[index] = draft.copy(title = it) },
                        label = { Text("Block Title") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(TriplySpacing.Xs))
                    OutlinedTextField(
                        value = draft.destinationName,
                        onValueChange = { blocks[index] = draft.copy(destinationName = it) },
                        label = { Text("Destination / Location") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(TriplySpacing.Xs))

                    Text("Activity Category", style = MaterialTheme.typography.labelMedium)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(TriplySpacing.Xs)) {
                        ActivityCategory.entries.forEach { cat ->
                            FilterChip(
                                selected = draft.category == cat,
                                onClick = { blocks[index] = draft.copy(category = cat) },
                                label = { Text(cat.label) }
                            )
                        }
                    }

                    Spacer(Modifier.height(TriplySpacing.Xs))
                    Row(horizontalArrangement = Arrangement.spacedBy(TriplySpacing.Sm)) {
                        OutlinedTextField(
                            value = draft.durationDays.toString(),
                            onValueChange = { v ->
                                val parsed = v.filter { it.isDigit() }.toIntOrNull()?.coerceAtLeast(1) ?: 1
                                blocks[index] = draft.copy(durationDays = parsed)
                            },
                            label = { Text("Activity Days") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = draft.transferDaysBefore.toString(),
                            onValueChange = { v ->
                                val parsed = v.filter { it.isDigit() }.toIntOrNull()?.coerceAtLeast(0) ?: 0
                                blocks[index] = draft.copy(transferDaysBefore = parsed)
                            },
                            label = { Text("Transfer Days") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Spacer(Modifier.height(TriplySpacing.Xs))
                    OutlinedTextField(
                        value = draft.estimatedCostMinor.toString(),
                        onValueChange = { v ->
                            val parsed = v.filter { it.isDigit() }.toLongOrNull() ?: 0L
                            blocks[index] = draft.copy(estimatedCostMinor = parsed)
                        },
                        label = { Text("Estimated Block Cost (IDR)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(TriplySpacing.Xs))
                    OutlinedTextField(
                        value = draft.notes,
                        onValueChange = { blocks[index] = draft.copy(notes = it) },
                        label = { Text("Notes") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(Modifier.height(TriplySpacing.Sm))
                    when (draft.category) {
                        ActivityCategory.HIKING -> {
                            Text("Hiking Gear Readiness", style = MaterialTheme.typography.titleMedium, color = TriplyColors.Accent)
                            HikingGearReadiness.entries.forEach { choice ->
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    RadioButton(
                                        selected = draft.metadata.hikingGearReadiness == choice.name,
                                        onClick = {
                                            blocks[index] = draft.copy(
                                                metadata = draft.metadata.copy(hikingGearReadiness = choice.name)
                                            )
                                        }
                                    )
                                    Text(choice.label, style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                            OutlinedTextField(
                                value = draft.metadata.basecampName,
                                onValueChange = { blocks[index] = draft.copy(metadata = draft.metadata.copy(basecampName = it)) },
                                label = { Text("Basecamp / Trailhead") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(Modifier.height(TriplySpacing.Xs))
                            OutlinedTextField(
                                value = draft.metadata.trailTicketsNote,
                                onValueChange = { blocks[index] = draft.copy(metadata = draft.metadata.copy(trailTicketsNote = it)) },
                                label = { Text("Permits / Tickets & Group Logistics") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(Modifier.height(TriplySpacing.Xs))
                            OutlinedTextField(
                                value = draft.metadata.foodAndLogisticsNote,
                                onValueChange = { blocks[index] = draft.copy(metadata = draft.metadata.copy(foodAndLogisticsNote = it)) },
                                label = { Text("Trail Food & Water Plan") },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        ActivityCategory.BEACH -> {
                            Text("Beach Details", style = MaterialTheme.typography.titleMedium, color = TriplyColors.Accent)
                            OutlinedTextField(
                                value = draft.metadata.tideAndSafetyNote,
                                onValueChange = { blocks[index] = draft.copy(metadata = draft.metadata.copy(tideAndSafetyNote = it)) },
                                label = { Text("Tide / Swimming Safety Notes") },
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(Modifier.height(TriplySpacing.Xs))
                            OutlinedTextField(
                                value = draft.metadata.waterActivityGear,
                                onValueChange = { blocks[index] = draft.copy(metadata = draft.metadata.copy(waterActivityGear = it)) },
                                label = { Text("Water Activity Gear (snorkel, dry bag, etc.)") },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        ActivityCategory.CAMPING -> {
                            Text("Camping Logistics", style = MaterialTheme.typography.titleMedium, color = TriplyColors.Accent)
                            OutlinedTextField(
                                value = draft.metadata.campsiteOrPermitNote,
                                onValueChange = { blocks[index] = draft.copy(metadata = draft.metadata.copy(campsiteOrPermitNote = it)) },
                                label = { Text("Campsite Ground / Permit Notes") },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        ActivityCategory.ROAD_TRIP -> {
                            Text("Road Trip Details", style = MaterialTheme.typography.titleMedium, color = TriplyColors.Accent)
                            OutlinedTextField(
                                value = draft.metadata.routeOrVehicleNote,
                                onValueChange = { blocks[index] = draft.copy(metadata = draft.metadata.copy(routeOrVehicleNote = it)) },
                                label = { Text("Vehicle Check / Rest Stops / Fuel Notes") },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        ActivityCategory.FAMILY -> {
                            Text("Family Comfort & Pace", style = MaterialTheme.typography.titleMedium, color = TriplyColors.Accent)
                            OutlinedTextField(
                                value = draft.metadata.familyAccessibilityNote,
                                onValueChange = { blocks[index] = draft.copy(metadata = draft.metadata.copy(familyAccessibilityNote = it)) },
                                label = { Text("Child/Senior Pace & Accessibility Notes") },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        else -> Unit
                    }
                }
            }

            if (validationError != null) {
                Text(validationError!!, color = TriplyColors.Danger, style = MaterialTheme.typography.bodyMedium)
            }

            Button(
                onClick = {
                    if (name.isBlank()) {
                        validationError = "Please enter a trip name."
                        return@Button
                    }
                    if (parsedStart == null) {
                        validationError = "Please enter a valid start date in YYYY-MM-DD format."
                        return@Button
                    }
                    validationError = null
                    scope.launch {
                        val now = System.currentTimeMillis()
                        val tripId = if (isEditing) tripIdOrNew else UUID.randomUUID().toString()
                        val endIso = durationSummary.computedEndDate?.toString() ?: startDateIso
                        val trip = TripEntity(
                            id = tripId,
                            name = name.trim(),
                            description = description.trim(),
                            startDateIso = startDateIso.trim(),
                            endDateIso = endIso,
                            plannedBudgetMinor = plannedBudgetText.toLongOrNull() ?: 0L,
                            isTemplate = false,
                            createdAtEpochMillis = now,
                            updatedAtEpochMillis = now
                        )
                        repository.saveTrip(trip)
                        val entities = blocks.mapIndexed { idx, b ->
                            TripBlockEntity(
                                id = b.id,
                                tripId = tripId,
                                title = b.title.ifBlank { "Activity ${idx + 1}" },
                                destinationName = b.destinationName.trim(),
                                category = b.category.name,
                                orderIndex = idx,
                                durationDays = b.durationDays.coerceAtLeast(1),
                                transferDaysBefore = b.transferDaysBefore.coerceAtLeast(0),
                                transferNotes = b.transferNotes,
                                estimatedCostMinor = b.estimatedCostMinor,
                                notes = b.notes,
                                activityMetadataJson = json.encodeToString(b.metadata)
                            )
                        }
                        repository.reorderBlocks(tripId, entities)

                        val existingDests = repository.observeDestinations(tripId).first()
                        if (existingDests.isEmpty()) {
                            entities.filter { it.destinationName.isNotBlank() }.forEachIndexed { idx, b ->
                                repository.saveDestination(
                                    DestinationEntity(
                                        id = UUID.randomUUID().toString(),
                                        tripId = tripId,
                                        name = b.destinationName,
                                        orderIndex = idx
                                    )
                                )
                            }
                        }

                        if (blocks.any { it.category == ActivityCategory.HIKING }) {
                            repository.mergeSuggestedPackingItems(tripId)
                        }

                        onSaved(tripId)
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (isEditing) "Save Trip Changes" else "Save Trip")
            }
        }
    }
}
