package com.triply.app.core.database

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Serializable
@Entity(tableName = "trips")
data class TripEntity(
    @PrimaryKey val id: String,
    val name: String,
    val description: String = "",
    val startDateIso: String, // YYYY-MM-DD
    val endDateIso: String,   // YYYY-MM-DD
    val timeZoneId: String = "Asia/Jakarta",
    val currencyCode: String = "IDR",
    val plannedBudgetMinor: Long = 0L,
    val isTemplate: Boolean = false,
    val createdAtEpochMillis: Long,
    val updatedAtEpochMillis: Long
)

@Serializable
@Entity(
    tableName = "destinations",
    foreignKeys = [ForeignKey(
        entity = TripEntity::class,
        parentColumns = ["id"],
        childColumns = ["tripId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("tripId"), Index("tripId", "orderIndex")]
)
data class DestinationEntity(
    @PrimaryKey val id: String,
    val tripId: String,
    val name: String,
    val address: String = "",
    val latitude: Double? = null,
    val longitude: Double? = null,
    val orderIndex: Int = 0,
    val notes: String = ""
)

@Serializable
@Entity(
    tableName = "trip_blocks",
    foreignKeys = [ForeignKey(
        entity = TripEntity::class,
        parentColumns = ["id"],
        childColumns = ["tripId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("tripId"), Index("tripId", "orderIndex")]
)
data class TripBlockEntity(
    @PrimaryKey val id: String,
    val tripId: String,
    val title: String,
    val destinationName: String,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val category: String = ActivityCategory.GENERAL.name,
    val orderIndex: Int = 0,
    val durationDays: Int = 1,
    val transferDaysBefore: Int = 0,
    val transferNotes: String = "",
    val estimatedCostMinor: Long = 0L,
    val notes: String = "",
    // Activity-specific dynamic metadata stored cleanly as JSON string
    val activityMetadataJson: String = "{}"
)

@Serializable
@Entity(
    tableName = "saved_routes",
    foreignKeys = [ForeignKey(
        entity = TripEntity::class,
        parentColumns = ["id"],
        childColumns = ["tripId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("tripId")]
)
data class SavedRouteEntity(
    @PrimaryKey val id: String,
    val tripId: String,
    val providerName: String,
    val profileName: String,
    val isApproximateAlternative: Boolean = false,
    val approximationNote: String = "",
    val totalDistanceMeters: Double,
    val totalDurationSeconds: Double,
    val includesLiveTraffic: Boolean = false,
    val polylineJson: String, // List of [lat, lon] pairs
    val waypointOrderHash: String,
    val restStopNotes: String = "",
    val fetchedAtEpochMillis: Long
)

@Serializable
@Entity(
    tableName = "participants",
    foreignKeys = [ForeignKey(
        entity = TripEntity::class,
        parentColumns = ["id"],
        childColumns = ["tripId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("tripId")]
)
data class ParticipantEntity(
    @PrimaryKey val id: String,
    val tripId: String,
    val name: String,
    val phone: String = "",
    val roleNote: String = ""
)

@Serializable
@Entity(
    tableName = "expenses",
    foreignKeys = [ForeignKey(
        entity = TripEntity::class,
        parentColumns = ["id"],
        childColumns = ["tripId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("tripId"), Index("category")]
)
data class ExpenseEntity(
    @PrimaryKey val id: String,
    val tripId: String,
    val dateIso: String,
    val timeText: String = "",
    val category: String = ExpenseCategory.OTHER.name,
    val amountMinor: Long,
    val currencyCode: String = "IDR",
    val description: String = "",
    val paidByParticipantId: String? = null,
    val splitRule: String = "EQUAL", // EQUAL or CUSTOM
    val receiptPath: String? = null,
    val createdAtEpochMillis: Long
)

@Serializable
@Entity(
    tableName = "expense_shares",
    foreignKeys = [
        ForeignKey(
            entity = ExpenseEntity::class,
            parentColumns = ["id"],
            childColumns = ["expenseId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = ParticipantEntity::class,
            parentColumns = ["id"],
            childColumns = ["participantId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("expenseId"), Index("participantId")]
)
data class ExpenseShareEntity(
    @PrimaryKey val id: String,
    val expenseId: String,
    val participantId: String,
    val shareMinor: Long,
    val includesRemainderUnit: Boolean = false
)

@Serializable
@Entity(
    tableName = "settlements",
    foreignKeys = [ForeignKey(
        entity = TripEntity::class,
        parentColumns = ["id"],
        childColumns = ["tripId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("tripId")]
)
data class SettlementEntity(
    @PrimaryKey val id: String,
    val tripId: String,
    val fromParticipantId: String,
    val toParticipantId: String,
    val amountMinor: Long,
    val dateIso: String,
    val note: String = ""
)

@Serializable
@Entity(
    tableName = "packing_items",
    foreignKeys = [ForeignKey(
        entity = TripEntity::class,
        parentColumns = ["id"],
        childColumns = ["tripId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("tripId")]
)
data class PackingItemEntity(
    @PrimaryKey val id: String,
    val tripId: String,
    val name: String,
    val categoryName: String = "General",
    val isGroupGear: Boolean = false,
    val ownershipStatus: String = GearOwnershipStatus.OWNED.name,
    val quantity: Int = 1,
    val rentalPriceMinor: Long = 0L,
    val rentalDays: Int = 0,
    val ownerName: String = "",
    val notes: String = "",
    val isPacked: Boolean = false
)

@Serializable
@Entity(
    tableName = "accommodations",
    foreignKeys = [ForeignKey(
        entity = TripEntity::class,
        parentColumns = ["id"],
        childColumns = ["tripId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("tripId")]
)
data class AccommodationEntity(
    @PrimaryKey val id: String,
    val tripId: String,
    val name: String,
    val address: String = "",
    val latitude: Double? = null,
    val longitude: Double? = null,
    val checkInIso: String,
    val checkOutIso: String,
    val nights: Int = 1,
    val rooms: Int = 1,
    val pricePerNightMinor: Long = 0L,
    val reservationStatus: String = ReservationStatus.NOT_BOOKED.name,
    val paymentStatus: String = PaymentStatus.UNPAID.name,
    val depositMinor: Long = 0L,
    val notes: String = "",
    val bookingProofPath: String? = null
)

@Serializable
@Entity(
    tableName = "transport_plans",
    foreignKeys = [ForeignKey(
        entity = TripEntity::class,
        parentColumns = ["id"],
        childColumns = ["tripId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("tripId")]
)
data class TransportPlanEntity(
    @PrimaryKey val id: String,
    val tripId: String,
    val mode: String = TransportMode.PRIVATE_CAR.name,
    val providerName: String = "",
    val rentalDays: Int = 0,
    val pricePerDayMinor: Long = 0L,
    val depositMinor: Long = 0L,
    val fuelEfficiencyKmPerLiter: Double? = null,
    val fuelPricePerLiterMinor: Long? = null,
    val estimatedDistanceKm: Double? = null,
    val parkingAndTollsMinor: Long = 0L,
    val ticketCostMinor: Long = 0L,
    val scheduleNotes: String = ""
)

@Serializable
@Entity(
    tableName = "reminders",
    foreignKeys = [ForeignKey(
        entity = TripEntity::class,
        parentColumns = ["id"],
        childColumns = ["tripId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("tripId"), Index("triggerAtEpochMillis")]
)
data class ReminderEntity(
    @PrimaryKey val id: String,
    val tripId: String,
    val title: String,
    val message: String = "",
    val type: String = ReminderType.CUSTOM.name,
    val triggerAtEpochMillis: Long,
    val useExactAlarm: Boolean = false,
    val isCompleted: Boolean = false,
    val isCancelled: Boolean = false
)

@Serializable
@Entity(
    tableName = "weather_cache",
    foreignKeys = [ForeignKey(
        entity = TripEntity::class,
        parentColumns = ["id"],
        childColumns = ["tripId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("tripId")]
)
data class WeatherCacheEntity(
    @PrimaryKey val id: String,
    val tripId: String,
    val destinationName: String,
    val latitude: Double,
    val longitude: Double,
    val providerName: String,
    val forecastJson: String,
    val severeNotice: String? = null,
    val fetchedAtEpochMillis: Long
)

@Serializable
@Entity(
    tableName = "emergency_contacts",
    foreignKeys = [ForeignKey(
        entity = TripEntity::class,
        parentColumns = ["id"],
        childColumns = ["tripId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("tripId")]
)
data class EmergencyContactEntity(
    @PrimaryKey val id: String,
    val tripId: String,
    val name: String,
    val relationOrCategory: String, // Emergency, Family, Participant, Basecamp, Hospital, Official
    val phoneNumber: String,
    val address: String = "",
    val latitude: Double? = null,
    val longitude: Double? = null,
    val notes: String = ""
)

@Serializable
@Entity(
    tableName = "journal_entries",
    foreignKeys = [ForeignKey(
        entity = TripEntity::class,
        parentColumns = ["id"],
        childColumns = ["tripId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("tripId"), Index("dateIso")]
)
data class JournalEntryEntity(
    @PrimaryKey val id: String,
    val tripId: String,
    val blockId: String? = null,
    val dayNumber: Int = 1,
    val dateIso: String,
    val title: String,
    val body: String,
    val locationLabel: String = "",
    val latitude: Double? = null,
    val longitude: Double? = null,
    val mediaPathsJson: String = "[]",
    val createdAtEpochMillis: Long
)

@Serializable
@Entity(tableName = "offline_map_regions")
data class OfflineMapRegionEntity(
    @PrimaryKey val id: String,
    val name: String,
    val providerId: String,
    val styleUrl: String,
    val attribution: String,
    val northLat: Double,
    val southLat: Double,
    val eastLon: Double,
    val westLon: Double,
    val minZoom: Double,
    val maxZoom: Double,
    val mapLibreRegionId: Long? = null,
    val status: String = OfflineRegionStatus.QUEUED.name,
    val progressPercent: Int = 0,
    val downloadedBytes: Long = 0L,
    val errorMessage: String? = null,
    val updatedAtEpochMillis: Long
)

@Serializable
@Entity(
    tableName = "what_if_scenarios",
    foreignKeys = [ForeignKey(
        entity = TripEntity::class,
        parentColumns = ["id"],
        childColumns = ["tripId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("tripId")]
)
data class WhatIfScenarioEntity(
    @PrimaryKey val id: String,
    val tripId: String,
    val name: String,
    val snapshotJson: String, // Isolated simulated blocks, budget, transport, accommodation delta
    val createdAtEpochMillis: Long,
    val updatedAtEpochMillis: Long
)
