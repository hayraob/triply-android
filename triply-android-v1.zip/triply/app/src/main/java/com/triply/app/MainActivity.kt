package com.triply.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.triply.app.core.designsystem.TriplyTheme
import com.triply.app.core.navigation.TriplyRootApp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val container = (application as TriplyApplication).container
        setContent {
            TriplyTheme {
                TriplyRootApp(container = container)
            }
        }
    }
}
