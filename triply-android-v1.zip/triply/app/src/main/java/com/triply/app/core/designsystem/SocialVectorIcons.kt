package com.triply.app.core.designsystem

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

/**
 * Vector platform icons for Developer Credits (Section 5).
 * Uses real vector paths rather than text abbreviations (IG, DC, TT, WA).
 */
object SocialVectorIcons {

    val Instagram: ImageVector by lazy {
        ImageVector.Builder(
            name = "Instagram",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).apply {
            path(fill = SolidColor(Color.White)) {
                moveTo(7.8f, 2f)
                horizontalLineTo(16.2f)
                curveTo(19.4f, 2f, 22f, 4.6f, 22f, 7.8f)
                verticalLineTo(16.2f)
                curveTo(22f, 19.4f, 19.4f, 22f, 16.2f, 22f)
                horizontalLineTo(7.8f)
                curveTo(4.6f, 22f, 2f, 19.4f, 2f, 16.2f)
                verticalLineTo(7.8f)
                curveTo(2f, 4.6f, 4.6f, 2f, 7.8f, 2f)
                close()
                moveTo(7.6f, 4f)
                curveTo(5.6f, 4f, 4f, 5.6f, 4f, 7.6f)
                verticalLineTo(16.4f)
                curveTo(4f, 18.4f, 5.6f, 20f, 7.6f, 20f)
                horizontalLineTo(16.4f)
                curveTo(18.4f, 20f, 20f, 18.4f, 20f, 16.4f)
                verticalLineTo(7.6f)
                curveTo(20f, 5.6f, 18.4f, 4f, 16.4f, 4f)
                horizontalLineTo(7.6f)
                close()
                moveTo(12f, 7f)
                curveTo(14.76f, 7f, 17f, 9.24f, 17f, 12f)
                curveTo(17f, 14.76f, 14.76f, 17f, 12f, 17f)
                curveTo(9.24f, 17f, 7f, 14.76f, 7f, 12f)
                curveTo(7f, 9.24f, 9.24f, 7f, 12f, 7f)
                close()
                moveTo(12f, 9f)
                curveTo(10.34f, 9f, 9f, 10.34f, 9f, 12f)
                curveTo(9f, 13.66f, 10.34f, 15f, 12f, 15f)
                curveTo(13.66f, 15f, 15f, 13.66f, 15f, 12f)
                curveTo(15f, 10.34f, 13.66f, 9f, 12f, 9f)
                close()
                moveTo(17.5f, 5.5f)
                curveTo(18.33f, 5.5f, 19f, 6.17f, 19f, 7f)
                curveTo(19f, 7.83f, 18.33f, 8.5f, 17.5f, 8.5f)
                curveTo(16.67f, 8.5f, 16f, 7.83f, 16f, 7f)
                curveTo(16f, 6.17f, 16.67f, 5.5f, 17.5f, 5.5f)
                close()
            }
        }.build()
    }

    val Discord: ImageVector by lazy {
        ImageVector.Builder(
            name = "Discord",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).apply {
            path(fill = SolidColor(Color.White)) {
                moveTo(19.27f, 5.33f)
                curveTo(17.94f, 4.71f, 16.5f, 4.26f, 15f, 4f)
                curveTo(14.82f, 4.32f, 14.61f, 4.75f, 14.47f, 5.09f)
                curveTo(12.87f, 4.85f, 11.29f, 4.85f, 9.72f, 5.09f)
                curveTo(9.58f, 4.75f, 9.36f, 4.32f, 9.18f, 4f)
                curveTo(7.68f, 4.26f, 6.24f, 4.71f, 4.91f, 5.33f)
                curveTo(2.21f, 9.37f, 1.48f, 13.31f, 1.85f, 17.19f)
                curveTo(3.63f, 18.51f, 5.35f, 19.31f, 7.04f, 19.83f)
                curveTo(7.46f, 19.26f, 7.83f, 18.65f, 8.15f, 18.01f)
                curveTo(7.54f, 17.78f, 6.96f, 17.5f, 6.41f, 17.17f)
                curveTo(6.55f, 17.07f, 6.69f, 16.96f, 6.82f, 16.85f)
                curveTo(10.17f, 18.4f, 13.82f, 18.4f, 17.13f, 16.85f)
                curveTo(17.27f, 16.96f, 17.4f, 17.07f, 17.54f, 17.17f)
                curveTo(16.99f, 17.5f, 16.41f, 17.78f, 15.8f, 18.01f)
                curveTo(16.12f, 18.65f, 16.49f, 19.26f, 16.91f, 19.83f)
                curveTo(18.6f, 19.31f, 20.32f, 18.51f, 22.1f, 17.19f)
                curveTo(22.53f, 12.69f, 21.37f, 8.79f, 19.27f, 5.33f)
                close()
                moveTo(8.68f, 14.81f)
                curveTo(7.66f, 14.81f, 6.83f, 13.87f, 6.83f, 12.72f)
                curveTo(6.83f, 11.57f, 7.64f, 10.63f, 8.68f, 10.63f)
                curveTo(9.72f, 10.63f, 10.55f, 11.57f, 10.53f, 12.72f)
                curveTo(10.53f, 13.87f, 9.72f, 14.81f, 8.68f, 14.81f)
                close()
                moveTo(15.32f, 14.81f)
                curveTo(14.3f, 14.81f, 13.47f, 13.87f, 13.47f, 12.72f)
                curveTo(13.47f, 11.57f, 14.28f, 10.63f, 15.32f, 10.63f)
                curveTo(16.36f, 10.63f, 17.19f, 11.57f, 17.17f, 12.72f)
                curveTo(17.17f, 13.87f, 16.36f, 14.81f, 15.32f, 14.81f)
                close()
            }
        }.build()
    }

    val TikTok: ImageVector by lazy {
        ImageVector.Builder(
            name = "TikTok",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).apply {
            path(fill = SolidColor(Color.White)) {
                moveTo(19.59f, 6.69f)
                curveTo(18.08f, 6.38f, 16.86f, 5.2f, 16.51f, 3.7f)
                verticalLineTo(3f)
                horizontalLineTo(13.15f)
                verticalLineTo(15.33f)
                curveTo(13.15f, 16.87f, 11.9f, 18.12f, 10.36f, 18.12f)
                curveTo(8.82f, 18.12f, 7.57f, 16.87f, 7.57f, 15.33f)
                curveTo(7.57f, 13.79f, 8.82f, 12.54f, 10.36f, 12.54f)
                curveTo(10.66f, 12.54f, 10.95f, 12.59f, 11.22f, 12.68f)
                verticalLineTo(9.26f)
                curveTo(10.94f, 9.22f, 10.65f, 9.19f, 10.36f, 9.19f)
                curveTo(6.97f, 9.19f, 4.22f, 11.94f, 4.22f, 15.33f)
                curveTo(4.22f, 18.72f, 6.97f, 21.47f, 10.36f, 21.47f)
                curveTo(13.75f, 21.47f, 16.5f, 18.72f, 16.5f, 15.33f)
                verticalLineTo(9.12f)
                curveTo(17.78f, 10.04f, 19.35f, 10.58f, 21.05f, 10.58f)
                verticalLineTo(7.24f)
                curveTo(20.55f, 7.24f, 20.06f, 7.05f, 19.59f, 6.69f)
                close()
            }
        }.build()
    }

    val WhatsApp: ImageVector by lazy {
        ImageVector.Builder(
            name = "WhatsApp",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).apply {
            path(fill = SolidColor(Color.White)) {
                moveTo(12.04f, 2f)
                curveTo(6.58f, 2f, 2.13f, 6.45f, 2.13f, 11.91f)
                curveTo(2.13f, 13.66f, 2.59f, 15.36f, 3.45f, 16.86f)
                lineTo(2.05f, 22f)
                lineTo(7.3f, 20.62f)
                curveTo(8.75f, 21.41f, 10.38f, 21.83f, 12.04f, 21.83f)
                curveTo(17.5f, 21.83f, 21.95f, 17.38f, 21.95f, 11.92f)
                curveTo(21.95f, 6.46f, 17.5f, 2f, 12.04f, 2f)
                close()
                moveTo(12.05f, 20.15f)
                curveTo(10.56f, 20.15f, 9.11f, 19.75f, 7.84f, 19f)
                lineTo(7.54f, 18.82f)
                lineTo(4.42f, 19.64f)
                lineTo(5.25f, 16.6f)
                lineTo(5.05f, 16.29f)
                curveTo(4.23f, 14.98f, 3.8f, 13.47f, 3.8f, 11.91f)
                curveTo(3.8f, 7.37f, 7.5f, 3.67f, 12.05f, 3.67f)
                curveTo(16.6f, 3.67f, 20.29f, 7.37f, 20.29f, 11.92f)
                curveTo(20.29f, 16.47f, 16.6f, 20.15f, 12.05f, 20.15f)
                close()
                moveTo(16.56f, 14.01f)
                curveTo(16.31f, 13.88f, 15.09f, 13.28f, 14.87f, 13.2f)
                curveTo(14.64f, 13.12f, 14.48f, 13.08f, 14.31f, 13.33f)
                curveTo(14.15f, 13.58f, 13.67f, 14.14f, 13.53f, 14.3f)
                curveTo(13.38f, 14.47f, 13.24f, 14.49f, 12.99f, 14.36f)
                curveTo(11.63f, 13.68f, 10.74f, 13.15f, 9.84f, 11.61f)
                curveTo(9.6f, 11.2f, 10.08f, 11.23f, 10.52f, 10.34f)
                curveTo(10.6f, 10.17f, 10.56f, 10.03f, 10.5f, 9.9f)
                curveTo(10.44f, 9.78f, 9.94f, 8.56f, 9.73f, 8.07f)
                curveTo(9.53f, 7.59f, 9.32f, 7.65f, 9.17f, 7.64f)
                horizontalLineTo(8.69f)
                curveTo(8.53f, 7.64f, 8.26f, 7.7f, 8.03f, 7.95f)
                curveTo(7.81f, 8.2f, 7.17f, 8.8f, 7.17f, 10.02f)
                curveTo(7.17f, 11.24f, 8.05f, 12.42f, 8.18f, 12.59f)
                curveTo(8.3f, 12.75f, 9.92f, 15.25f, 12.4f, 16.32f)
                curveTo(13.97f, 17f, 14.59f, 17.06f, 15.38f, 16.94f)
                curveTo(15.86f, 16.87f, 16.84f, 16.34f, 17.05f, 15.76f)
                curveTo(17.25f, 15.18f, 17.25f, 14.69f, 17.19f, 14.58f)
                curveTo(17.13f, 14.48f, 16.81f, 14.13f, 16.56f, 14.01f)
                close()
            }
        }.build()
    }
}
