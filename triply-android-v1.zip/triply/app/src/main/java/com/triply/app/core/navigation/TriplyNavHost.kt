package com.triply.app.core.navigation

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Luggage
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.triply.app.AppContainer
import com.triply.app.core.designsystem.OfflineBanner
import com.triply.app.core.designsystem.TriplyColors
import com.triply.app.feature.budget.GlobalBudgetScreen
import com.triply.app.feature.emergency.EmergencyCenterScreen
import com.triply.app.feature.explore.ExploreScreen
import com.triply.app.feature.home.HomeScreen
import com.triply.app.feature.itinerary.TripDetailScreen
import com.triply.app.feature.map.OfflineRegionsScreen
import com.triply.app.feature.profile.ProfileScreen
import com.triply.app.feature.tripbuilder.TripBuilderScreen
import com.triply.app.feature.trips.MyTripsScreen
import com.triply.app.feature.whatif.WhatIfPlannerScreen

enum class BottomNavItem(val route: String, val label: String, val icon: ImageVector) {
    HOME("home", "Home", Icons.Outlined.Home),
    MY_TRIPS("my_trips", "My Trips", Icons.Outlined.Luggage),
    EXPLORE("explore", "Explore", Icons.Outlined.Explore),
    BUDGET("budget", "Budget", Icons.Outlined.AccountBalanceWallet),
    PROFILE("profile", "Profile", Icons.Outlined.Person)
}

@Composable
fun TriplyRootApp(container: AppContainer) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: BottomNavItem.HOME.route
    val isOnline by container.connectivityMonitor.isOnlineFlow.collectAsState(
        initial = container.connectivityMonitor.isCurrentlyOnline()
    )

    val showBottomBar = BottomNavItem.entries.any { it.route == currentRoute }

    Scaffold(
        containerColor = TriplyColors.Background,
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(containerColor = TriplyColors.Surface) {
                    BottomNavItem.entries.forEach { item ->
                        val selected = currentRoute == item.route
                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                navController.navigate(item.route) {
                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(item.icon, contentDescription = item.label) },
                            label = { Text(item.label) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = TriplyColors.Accent,
                                selectedTextColor = TriplyColors.Accent,
                                unselectedIconColor = TriplyColors.TextSecondary,
                                unselectedTextColor = TriplyColors.TextSecondary,
                                indicatorColor = TriplyColors.SurfaceSecondary
                            )
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            OfflineBanner(isOnline = isOnline)
            NavHost(
                navController = navController,
                startDestination = BottomNavItem.HOME.route,
                modifier = Modifier.weight(1f)
            ) {
                composable(BottomNavItem.HOME.route) {
                    HomeScreen(
                        repository = container.repository,
                        onCreateTrip = { navController.navigate("trip_builder/new") },
                        onOpenTrip = { tripId, initialTab ->
                            navController.navigate("trip_detail/$tripId?tab=$initialTab")
                        },
                        onOpenBudget = { navController.navigate(BottomNavItem.BUDGET.route) },
                        onOpenExplore = { navController.navigate(BottomNavItem.EXPLORE.route) }
                    )
                }
                composable(BottomNavItem.MY_TRIPS.route) {
                    MyTripsScreen(
                        repository = container.repository,
                        onCreateTrip = { navController.navigate("trip_builder/new") },
                        onOpenTrip = { tripId -> navController.navigate("trip_detail/$tripId?tab=0") },
                        onEditTrip = { tripId -> navController.navigate("trip_builder/$tripId") }
                    )
                }
                composable(BottomNavItem.EXPLORE.route) {
                    ExploreScreen(
                        repository = container.repository,
                        isOnline = isOnline,
                        onOpenOfflineMaps = { navController.navigate("offline_maps") }
                    )
                }
                composable(BottomNavItem.BUDGET.route) {
                    GlobalBudgetScreen(
                        repository = container.repository,
                        onOpenTripBudget = { tripId -> navController.navigate("trip_detail/$tripId?tab=3") }
                    )
                }
                composable(BottomNavItem.PROFILE.route) {
                    ProfileScreen(
                        repository = container.repository,
                        onOpenOfflineMaps = { navController.navigate("offline_maps") }
                    )
                }
                composable(
                    route = "trip_builder/{tripId}",
                    arguments = listOf(navArgument("tripId") { type = NavType.StringType })
                ) { entry ->
                    val tripIdArg = entry.arguments?.getString("tripId") ?: "new"
                    TripBuilderScreen(
                        repository = container.repository,
                        tripIdOrNew = tripIdArg,
                        onBack = { navController.popBackStack() },
                        onSaved = { savedTripId ->
                            navController.popBackStack()
                            navController.navigate("trip_detail/$savedTripId?tab=0")
                        }
                    )
                }
                composable(
                    route = "trip_detail/{tripId}?tab={tab}",
                    arguments = listOf(
                        navArgument("tripId") { type = NavType.StringType },
                        navArgument("tab") { type = NavType.IntType; defaultValue = 0 }
                    )
                ) { entry ->
                    val tripId = entry.arguments?.getString("tripId") ?: return@composable
                    val initialTab = entry.arguments?.getInt("tab") ?: 0
                    TripDetailScreen(
                        repository = container.repository,
                        tripId = tripId,
                        initialTab = initialTab,
                        isOnline = isOnline,
                        onBack = { navController.popBackStack() },
                        onEditTrip = { navController.navigate("trip_builder/$tripId") },
                        onOpenWhatIf = { navController.navigate("what_if/$tripId") },
                        onOpenEmergency = { navController.navigate("emergency/$tripId") },
                        onOpenOfflineMaps = { navController.navigate("offline_maps") }
                    )
                }
                composable(
                    route = "what_if/{tripId}",
                    arguments = listOf(navArgument("tripId") { type = NavType.StringType })
                ) { entry ->
                    val tripId = entry.arguments?.getString("tripId") ?: return@composable
                    WhatIfPlannerScreen(
                        repository = container.repository,
                        tripId = tripId,
                        onBack = { navController.popBackStack() }
                    )
                }
                composable(
                    route = "emergency/{tripId}",
                    arguments = listOf(navArgument("tripId") { type = NavType.StringType })
                ) { entry ->
                    val tripId = entry.arguments?.getString("tripId") ?: return@composable
                    EmergencyCenterScreen(
                        repository = container.repository,
                        tripId = tripId,
                        onBack = { navController.popBackStack() }
                    )
                }
                composable("offline_maps") {
                    OfflineRegionsScreen(
                        repository = container.repository,
                        isOnline = isOnline,
                        onBack = { navController.popBackStack() }
                    )
                }
            }
        }
    }
}
