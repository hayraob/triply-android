package com.triply.app.feature.journal

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.triply.app.core.data.TriplyRepository
import com.triply.app.core.database.JournalEntryEntity
import com.triply.app.core.database.TripBlockEntity
import com.triply.app.core.database.TripEntity
import com.triply.app.core.designsystem.EmptyStateView
import com.triply.app.core.designsystem.SectionHeader
import com.triply.app.core.designsystem.TriplyCard
import com.triply.app.core.designsystem.TriplyColors
import com.triply.app.core.designsystem.TriplySpacing
import kotlinx.coroutines.launch
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.time.LocalDate
import java.util.UUID

@Composable
fun TripJournalTab(
    repository: TriplyRepository,
    tripId: String,
    trip: TripEntity?,
    blocks: List<TripBlockEntity>
) {
    val context = LocalContext.current
    val entries by repository.observeJournal(tripId).collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    val json = remember { Json { ignoreUnknownKeys = true } }

    var showAddEntry by remember { mutableStateOf(false) }
    var exportNotice by remember { mutableStateOf<String?>(null) }

    val exportReportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/markdown")
    ) { uri ->
        if (uri != null) {
            runCatching {
                val md = buildString {
                    appendLine("# ${trip?.name ?: "Trip"} — Journal Report")
                    appendLine("Dates: ${trip?.startDateIso} to ${trip?.endDateIso}")
                    appendLine()
                    entries.forEach { e ->
                        appendLine("## Day ${e.dayNumber}: ${e.title} (${e.dateIso})")
                        if (e.locationLabel.isNotBlank()) appendLine("Location: ${e.locationLabel}")
                        appendLine(e.body)
                        appendLine()
                    }
                }
                context.contentResolver.openOutputStream(uri)?.use { it.write(md.toByteArray(Charsets.UTF_8)) }
                exportNotice = "Trip journal summary exported."
            }.onFailure {
                exportNotice = "Export failed: ${it.localizedMessage}"
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(TriplySpacing.Lg),
        verticalArrangement = Arrangement.spacedBy(TriplySpacing.Md)
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(TriplySpacing.Sm), modifier = Modifier.fillMaxWidth()) {
            Button(onClick = { showAddEntry = true }, modifier = Modifier.weight(1f)) {
                Icon(Icons.Outlined.Add, contentDescription = null)
                Text(" New Entry")
            }
            OutlinedButton(
                enabled = entries.isNotEmpty(),
                onClick = { exportReportLauncher.launch("triply_journal_${trip?.name ?: "report"}.md") },
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Outlined.Description, contentDescription = null)
                Text(" Export Report")
            }
        }

        exportNotice?.let { Text(it, color = TriplyColors.Success, style = MaterialTheme.typography.labelMedium) }

        if (entries.isEmpty()) {
            EmptyStateView(
                title = "No journal memories yet",
                message = "Record daily notes and attach photos/videos locally. Media stays stable across restarts and backups."
            )
        } else {
            entries.forEach { entry ->
                val mediaPaths = runCatching { json.decodeFromString<List<String>>(entry.mediaPathsJson) }.getOrDefault(emptyList())
                TriplyCard {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Day ${entry.dayNumber} • ${entry.title}", style = MaterialTheme.typography.titleMedium)
                            Text("${entry.dateIso}${if (entry.locationLabel.isNotBlank()) " • ${entry.locationLabel}" else ""}", style = MaterialTheme.typography.labelMedium)
                        }
                        IconButton(onClick = { scope.launch { repository.deleteJournalEntry(entry.id) } }) {
                            Icon(Icons.Outlined.Delete, contentDescription = "Delete entry", tint = TriplyColors.Danger)
                        }
                    }
                    Spacer(Modifier.height(TriplySpacing.Xs))
                    Text(entry.body, style = MaterialTheme.typography.bodyLarge)
                    mediaPaths.forEach { path ->
                        Spacer(Modifier.height(TriplySpacing.Sm))
                        val file = File(path)
                        if (file.exists()) {
                            AsyncImage(
                                model = file,
                                contentDescription = "Journal attachment",
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(180.dp)
                            )
                        } else {
                            Text("Media file unavailable on device.", style = MaterialTheme.typography.labelMedium, color = TriplyColors.Warning)
                        }
                    }
                }
            }
        }
    }

    if (showAddEntry) {
        var title by remember { mutableStateOf("") }
        var body by remember { mutableStateOf("") }
        var dayNum by remember { mutableStateOf("1") }
        var location by remember { mutableStateOf("") }
        var attachedPaths by remember { mutableStateOf<List<String>>(emptyList()) }

        val mediaPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
            if (uri != null) {
                repository.copyMediaToAppStorage(uri, "journal")?.let { savedPath ->
                    attachedPaths = attachedPaths + savedPath
                }
            }
        }

        AlertDialog(
            onDismissRequest = { showAddEntry = false },
            containerColor = TriplyColors.Surface,
            title = { Text("New Journal Entry") },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(TriplySpacing.Xs)) {
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Title *") }, singleLine = true)
                    OutlinedTextField(value = dayNum, onValueChange = { dayNum = it.filter { c -> c.isDigit() } }, label = { Text("Trip Day #") }, singleLine = true)
                    OutlinedTextField(value = location, onValueChange = { location = it }, label = { Text("Location Label (optional)") }, singleLine = true)
                    OutlinedTextField(value = body, onValueChange = { body = it }, label = { Text("Notes / Story *") }, minLines = 3)
                    OutlinedButton(onClick = {
                        mediaPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
                    }) {
                        Text("Attach Photo/Video (${attachedPaths.size} attached)")
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (title.isNotBlank() && body.isNotBlank()) {
                        scope.launch {
                            repository.saveJournalEntry(
                                JournalEntryEntity(
                                    id = UUID.randomUUID().toString(),
                                    tripId = tripId,
                                    blockId = blocks.firstOrNull()?.id,
                                    dayNumber = dayNum.toIntOrNull()?.coerceAtLeast(1) ?: 1,
                                    dateIso = LocalDate.now().toString(),
                                    title = title.trim(),
                                    body = body.trim(),
                                    locationLabel = location.trim(),
                                    mediaPathsJson = json.encodeToString(attachedPaths),
                                    createdAtEpochMillis = System.currentTimeMillis()
                                )
                            )
                            showAddEntry = false
                        }
                    }
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showAddEntry = false }) { Text("Cancel") } }
        )
    }
}
