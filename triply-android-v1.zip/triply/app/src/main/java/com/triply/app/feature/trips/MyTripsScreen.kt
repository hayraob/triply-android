package com.triply.app.feature.trips

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.triply.app.core.common.MoneyMath
import com.triply.app.core.common.TripDurationCalculator
import com.triply.app.core.data.TriplyRepository
import com.triply.app.core.database.TripEntity
import com.triply.app.core.designsystem.ConfirmDestructiveDialog
import com.triply.app.core.designsystem.EmptyStateView
import com.triply.app.core.designsystem.StatusPill
import com.triply.app.core.designsystem.TriplyCard
import com.triply.app.core.designsystem.TriplyColors
import com.triply.app.core.designsystem.TriplySpacing
import kotlinx.coroutines.launch
import java.time.LocalDate

private enum class TripFilter(val label: String) {
    ALL("All"), UPCOMING("Upcoming"), ONGOING("Ongoing"), COMPLETED("Completed")
}

@Composable
fun MyTripsScreen(
    repository: TriplyRepository,
    onCreateTrip: () -> Unit,
    onOpenTrip: (String) -> Unit,
    onEditTrip: (String) -> Unit
) {
    val trips by repository.observeTrips().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var filter by rememberSaveable { mutableStateOf(TripFilter.ALL) }
    var search by rememberSaveable { mutableStateOf("") }
    var sortNewest by rememberSaveable { mutableStateOf(false) }
    var pendingDelete by remember { mutableStateOf<TripEntity?>(null) }

    val today = LocalDate.now()

    fun statusOf(trip: TripEntity): TripFilter {
        val start = runCatching { LocalDate.parse(trip.startDateIso) }.getOrNull() ?: return TripFilter.UPCOMING
        val end = runCatching { LocalDate.parse(trip.endDateIso) }.getOrNull() ?: start
        return when {
            today.isBefore(start) -> TripFilter.UPCOMING
            today.isAfter(end) -> TripFilter.COMPLETED
            else -> TripFilter.ONGOING
        }
    }

    val filtered = trips
        .filter { filter == TripFilter.ALL || statusOf(it) == filter }
        .filter { search.isBlank() || it.name.contains(search, ignoreCase = true) || it.description.contains(search, ignoreCase = true) }
        .let { list -> if (sortNewest) list.sortedByDescending { it.startDateIso } else list.sortedBy { it.startDateIso } }

    Scaffold(
        containerColor = TriplyColors.Background,
        floatingActionButton = {
            FloatingActionButton(
                onClick = onCreateTrip,
                containerColor = TriplyColors.Accent,
                contentColor = TriplyColors.Background
            ) {
                Icon(Icons.Outlined.Add, contentDescription = "Create trip")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(TriplySpacing.Lg),
            verticalArrangement = Arrangement.spacedBy(TriplySpacing.Sm)
        ) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("My Trips", style = MaterialTheme.typography.headlineMedium)
                FilterChip(
                    selected = sortNewest,
                    onClick = { sortNewest = !sortNewest },
                    label = { Text(if (sortNewest) "Newest First" else "Soonest First") }
                )
            }

            OutlinedTextField(
                value = search,
                onValueChange = { search = it },
                label = { Text("Search trips") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Row(horizontalArrangement = Arrangement.spacedBy(TriplySpacing.Sm)) {
                TripFilter.entries.forEach { item ->
                    FilterChip(
                        selected = filter == item,
                        onClick = { filter = item },
                        label = { Text(item.label) }
                    )
                }
            }

            if (filtered.isEmpty()) {
                EmptyStateView(
                    title = "No matching trips",
                    message = "Create a new trip or adjust your filter.",
                    actionLabel = "Create Trip",
                    onAction = onCreateTrip
                )
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(TriplySpacing.Md)) {
                    items(filtered, key = { it.id }) { trip ->
                        val st = statusOf(trip)
                        val start = runCatching { LocalDate.parse(trip.startDateIso) }.getOrNull()
                        val end = runCatching { LocalDate.parse(trip.endDateIso) }.getOrNull()
                        val days = if (start != null && end != null) TripDurationCalculator.daysInclusive(start, end) else 1
                        val pillColor = when (st) {
                            TripFilter.ONGOING -> TriplyColors.Success
                            TripFilter.UPCOMING -> TriplyColors.Accent
                            else -> TriplyColors.TextSecondary
                        }
                        TriplyCard(modifier = Modifier.clickable { onOpenTrip(trip.id) }) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(trip.name, style = MaterialTheme.typography.titleMedium)
                                    Text("${trip.startDateIso} -> ${trip.endDateIso} ($days days)", style = MaterialTheme.typography.bodyMedium)
                                    Text("Planned budget: ${MoneyMath.format(trip.plannedBudgetMinor, trip.currencyCode)}", style = MaterialTheme.typography.labelMedium)
                                }
                                StatusPill(st.label, pillColor)
                            }
                            Spacer(Modifier.height(TriplySpacing.Xs))
                            Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                                IconButton(onClick = { onEditTrip(trip.id) }) {
                                    Icon(Icons.Outlined.Edit, contentDescription = "Edit trip", tint = TriplyColors.TextSecondary)
                                }
                                IconButton(onClick = { pendingDelete = trip }) {
                                    Icon(Icons.Outlined.Delete, contentDescription = "Delete trip", tint = TriplyColors.Danger)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    pendingDelete?.let { trip ->
        ConfirmDestructiveDialog(
            title = "Delete '${trip.name}'?",
            message = "This permanently removes the trip, itinerary blocks, expenses, checklist, and journal entries on this device.",
            onConfirm = {
                scope.launch { repository.deleteTrip(trip.id) }
                pendingDelete = null
            },
            onDismiss = { pendingDelete = null }
        )
    }
}
