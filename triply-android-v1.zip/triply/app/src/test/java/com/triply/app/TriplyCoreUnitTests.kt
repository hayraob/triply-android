package com.triply.app

import com.triply.app.core.common.MoneyMath
import com.triply.app.core.common.TileSourcePolicyGuard
import com.triply.app.core.common.TripDurationCalculator
import com.triply.app.core.common.WeatherFreshness
import com.triply.app.core.data.ChecklistSuggestionEngine
import com.triply.app.core.data.WhatIfSimulationEngine
import com.triply.app.core.data.WhatIfSnapshot
import com.triply.app.core.data.backup.TriplyArchiveManager
import com.triply.app.core.database.ActivityCategory
import com.triply.app.core.database.PackingItemEntity
import com.triply.app.core.database.TripBlockEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class TriplyCoreUnitTests {

    @Test
    fun moneySplitPreservesRemainderWithoutLoss() {
        val result = MoneyMath.splitEqually(100_000L, listOf("p1", "p2", "p3"))
        assertEquals(33_333L, result.baseShare)
        assertEquals(1L, result.remainder)
        assertEquals(listOf("p1"), result.remainderRecipients)
        assertEquals(100_000L, result.shares.values.sum())
    }

    @Test
    fun settlementTransfersResolveExactBalances() {
        val balances = listOf(
            MoneyMath.ParticipantBalance("a", "Alice", totalPaid = 300_000L, totalShare = 100_000L, 0L, 0L),
            MoneyMath.ParticipantBalance("b", "Bob", totalPaid = 0L, totalShare = 100_000L, 0L, 0L),
            MoneyMath.ParticipantBalance("c", "Cara", totalPaid = 0L, totalShare = 100_000L, 0L, 0L)
        )
        val transfers = MoneyMath.computeSettlementTransfers(balances)
        assertEquals(2, transfers.size)
        assertEquals(200_000L, transfers.sumOf { it.amount })
    }

    @Test
    fun durationCalculatorIncludesTransferDaysExplicitly() {
        val start = LocalDate.of(2026, 8, 1)
        val summary = TripDurationCalculator.calculate(
            start,
            listOf(
                TripDurationCalculator.BlockSpan(durationDays = 3, transferDaysBefore = 0),
                TripDurationCalculator.BlockSpan(durationDays = 3, transferDaysBefore = 1),
                TripDurationCalculator.BlockSpan(durationDays = 1, transferDaysBefore = 0)
            )
        )
        assertEquals(7, summary.totalActivityDays)
        assertEquals(1, summary.totalTransferDays)
        assertEquals(8, summary.totalTripDays)
        assertEquals(LocalDate.of(2026, 8, 8), summary.computedEndDate)
    }

    @Test
    fun fuelEstimateReturnsNullWhenInputsMissing() {
        assertNull(TripDurationCalculator.estimateFuelCostIdr(null, 12.0, 13_000L))
        assertEquals(130_000L, TripDurationCalculator.estimateFuelCostIdr(120.0, 12.0, 13_000L))
    }

    @Test
    fun tileSourcePolicyBlocksPublicOsmEndpoints() {
        val blocked = TileSourcePolicyGuard.validateForOfflineDownload(
            "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
            "self_hosted"
        )
        assertTrue(blocked is TileSourcePolicyGuard.PolicyCheckResult.Blocked)

        val allowed = TileSourcePolicyGuard.validateForOfflineDownload(
            "https://tiles.stadiamaps.com/styles/alidade_smooth_dark.json?api_key=test",
            "stadia_maps"
        )
        assertTrue(allowed is TileSourcePolicyGuard.PolicyCheckResult.Permitted)
        assertEquals(100, (allowed as TileSourcePolicyGuard.PolicyCheckResult.Permitted).maxCacheMb)
    }

    @Test
    fun weatherFreshnessLabelsOfflineAndStaleAccurately() {
        val now = 10_000_000_000L
        assertEquals(WeatherFreshness.FreshnessState.OFFLINE_CACHED, WeatherFreshness.evaluate(now - 1_000L, now, isOnline = false))
        assertEquals(WeatherFreshness.FreshnessState.FRESH, WeatherFreshness.evaluate(now - 60_000L, now, isOnline = true))
        assertEquals(WeatherFreshness.FreshnessState.STALE, WeatherFreshness.evaluate(now - WeatherFreshness.STALE_THRESHOLD_MILLIS - 1L, now, isOnline = true))
    }

    @Test
    fun checklistSuggestionsAreNonDestructive() {
        val existing = listOf(
            PackingItemEntity(id = "1", tripId = "t1", name = "Headlamp + Spare Batteries")
        )
        val additions = ChecklistSuggestionEngine.buildNonDestructiveAdditions("t1", existing, setOf(ActivityCategory.HIKING))
        assertTrue(additions.none { it.name.equals("Headlamp + Spare Batteries", ignoreCase = true) })
        assertTrue(additions.any { it.isGroupGear })
    }

    @Test
    fun whatIfSimulationCalculatesDeltasWithoutMutatingBaseline() {
        val baseline = listOf(
            TripBlockEntity(id = "b1", tripId = "t1", title = "Hike", destinationName = "Mt", durationDays = 3, estimatedCostMinor = 500_000L)
        )
        val simulated = baseline + TripBlockEntity(id = "b2", tripId = "t1", title = "Beach", destinationName = "Coast", durationDays = 2, estimatedCostMinor = 400_000L)
        val report = WhatIfSimulationEngine.evaluateImpact(
            startDate = LocalDate.of(2026, 9, 1),
            baselineBlocks = baseline,
            baselinePlannedBudgetMinor = 1_000_000L,
            participantCount = 2,
            snapshot = WhatIfSnapshot(blocks = simulated, transportCostDeltaMinor = 200_000L)
        )
        assertEquals(3, report.baselineDays)
        assertEquals(5, report.simulatedDays)
        assertEquals(2, report.dayDelta)
        assertEquals(1_600_000L, report.simulatedCostMinor)
        assertEquals(800_000L, report.simulatedPerPersonMinor)
    }

    @Test
    fun archiveSha256IsDeterministic() {
        val h1 = TriplyArchiveManager.sha256Hex("triply-test".toByteArray())
        val h2 = TriplyArchiveManager.sha256Hex("triply-test".toByteArray())
        assertEquals(h1, h2)
        assertEquals(64, h1.length)
    }
}
