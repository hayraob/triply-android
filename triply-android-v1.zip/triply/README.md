# Triply — Your Journey, Fully Planned.

**Triply** is an offline-first, dark-mode-only native Android travel-planning and trip-management application built with Kotlin, Jetpack Compose, Room, WorkManager/AlarmManager, and MapLibre Native Android.

- **Application ID / Namespace**: `com.triply.app` (stable; do not change after storing real user data)
- **Min SDK**: API 26 (Android 8.0) — native `java.time`, notification channels, adaptive icons
- **Target / Compile SDK**: API 35 (Android 15)
- **Theme**: Dark Mode only for V1 (`#0B0D12` background, `#151922` surface, `#8B7CFF` accent)
- **Group Sharing & Backup**: Local ZIP export/import and local full backup/restore (no cloud sync in V1)

## Included V1 Modules (All 12 Mandatory Modules)

1. **Trip Builder & Multi-Destination** — Editable templates, itinerary blocks (add/edit/delete/duplicate/reorder), automatic duration + transfer day calculations, and dynamic activity forms (Hiking gear readiness A/B/C, Beach, Camping, Road Trip, Family, City, Backpacking, General).
2. **Interactive Map & Route Estimates** — MapLibre Native Android map with numbered pins in user order, ordered polyline, OpenRouteService routing (with honest no-motorcycle notice and optional labelled car approximation), saved offline routes, external navigation intent, and Offline Map Region Download Manager with OSM tile policy guard.
3. **Budget & Expense Tracker** — Separate planned vs. actual spending in exact integer minor units (default IDR), 10 categories, Compose Canvas category chart, receipt photo picker, and equal/custom group splits with transparent remainder handling.
4. **Alarm & Timeline** — Day-by-day timeline, H-7/H-3/H-1 preparation reminders, AlarmManager (exact alarms with rationale) + WorkManager (deferrable reminders), and `BOOT_COMPLETED` rescheduling.
5. **Dynamic Packing Checklist** — Activity-based non-destructive suggestions, personal vs. group equipment, ownership status (`owned`/`buy`/`rent`/`borrow`), quantity, owner, and persistent progress.
6. **Accommodation & Transport Management** — User-entered lodging/campsite records and transport plans with clearly labelled fuel estimates, tolls/parking, and public ticket notes.
7. **Weather Alert** — Open-Meteo 7-day & 24-hour forecasts cached locally with clear `Fresh` / `Stale Cache` / `Offline Cache` labels.
8. **Emergency Center** — Offline-ready emergency/family/participant/basecamp/hospital contacts with tap-to-call, tap-to-navigate, and copy coordinates (honest non-SOS notice).
9. **Trip Journal** — Daily notes, Photo Picker media stored stably in app-private storage, graceful missing-media fallback, and Markdown summary report export.
10. **Group Management** — Participants, expense payer tracking, exact integer balances, minimal "who owes whom" settlement transfers, and versioned ZIP trip export/import with preview & collision-safe import-as-new.
11. **Offline Mode** — Global offline banner and full offline usability for all local trip features, plus honest offline states for online-only actions.
12. **What-If Planner** — Isolated simulation sandbox to test itinerary and cost changes without touching the main trip until explicitly confirmed.

## Building an APK from Your Android Phone (No Laptop or Android Studio Required)

This repository includes a reproducible GitHub Actions workflow at `.github/workflows/android-build.yml`.

1. Create a new GitHub repository (public or private) in your phone's browser at [github.com/new](https://github.com/new).
2. Upload or push the contents of this archive into the repository's `main` branch.
3. Open the **Actions** tab in your repository on GitHub.
4. Select **Build Triply Android APK** -> tap **Run workflow** -> **Run workflow**.
5. Wait ~3–5 minutes for the workflow to run unit tests (`gradle testDebugUnitTest`) and build the APK (`gradle assembleDebug`).
6. Open the completed workflow run, scroll to **Artifacts**, and tap **triply-debug-apk** to download the ZIP containing `app-debug.apk`.
7. Extract and install `app-debug.apk` on your Android phone (enable "Install unknown apps" for your browser/file manager if prompted).

### Optional: Signed Release APK via GitHub Secrets

Never commit `.jks` keystores or passwords to Git. To enable automatic signed release builds in GitHub Actions, add these four repository secrets under **Settings -> Secrets and variables -> Actions**:
- `SIGNING_KEYSTORE_BASE64`: Base64-encoded `.jks` keystore file
- `SIGNING_KEYSTORE_PASSWORD`: Keystore password
- `SIGNING_KEY_ALIAS`: Key alias
- `SIGNING_KEY_PASSWORD`: Key password

## Configuring Optional Online APIs

Triply works offline out of the box with zero API keys bundled in the APK. Inside the app, open **Profile -> Map & API Settings** to configure:
- **Map Tile Provider**: `OpenFreeMap` (default), `Stadia Maps` (requires API key; 100 MB offline cache cap), `MapTiler` (requires API key), or `Self-Hosted` MapLibre style URL.
- **OpenRouteService API Key**: Optional key for live route distance/duration calculations.
- **Open-Meteo Commercial Key**: Leave blank for non-commercial personal use (<10,000 calls/day); add a paid customer key for commercial deployment.

## Developer Credits

- **Haydar**
- **silent.dt**
