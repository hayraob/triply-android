# Triply Test Plan & Acceptance Matrix

## Automated Unit Tests (`app/src/test/java/com/triply/app/TriplyCoreUnitTests.kt`)
Executed automatically by GitHub Actions (`gradle testDebugUnitTest`):
- `moneySplitPreservesRemainderWithoutLoss` — Verifies exact IDR integer split and explicit `+1` remainder tracking.
- `settlementTransfersResolveExactBalances` — Verifies minimal "who owes whom" settlement calculations.
- `durationCalculatorIncludesTransferDaysExplicitly` — Verifies activity + transfer day total and end date.
- `fuelEstimateReturnsNullWhenInputsMissing` — Verifies fuel estimates never fabricate numbers.
- `tileSourcePolicyBlocksPublicOsmEndpoints` — Verifies `tile.openstreetmap.org` is blocked and Stadia Maps 100 MB cap is enforced.
- `weatherFreshnessLabelsOfflineAndStaleAccurately` — Verifies `FRESH`, `STALE`, and `OFFLINE_CACHED` labeling.
- `checklistSuggestionsAreNonDestructive` — Verifies activity suggestions merge without overwriting existing items.
- `whatIfSimulationCalculatesDeltasWithoutMutatingBaseline` — Verifies What-If isolation and cost/day deltas.
- `archiveSha256IsDeterministic` — Verifies backup/export integrity hashing.

## Device Acceptance Checklist (Run on Android Device After Downloading CI APK)
1. Fresh install opens with clean empty state and zero sample trip data mixed into user records.
2. Create, edit, and delete a trip; verify persistence across app restart.
3. Add multiple destinations and itinerary blocks; reorder blocks and verify map pins/lines match saved order.
4. Change durations and transfer days; verify overall trip duration and end date recalculate accurately.
5. Select Hiking category; verify A/B/C gear readiness and basecamp/permit fields appear; switch to Beach/City and verify hiking-only fields disappear.
6. Add planned budget, actual expenses, receipt photo, and participants; verify remaining/over-budget, category chart, and settlement transfers.
7. Add accommodation and transport records; verify fuel estimate is clearly labelled as an estimate.
8. Add H-7/H-3/H-1 and custom reminders; verify notification permission rationale, exact-alarm rationale, and reboot rescheduling.
9. Use checklist; toggle packed items, merge suggestions, and verify persistence after restart.
10. Refresh weather online, enable airplane mode, and verify `Offline Cache` badge and last-updated timestamp.
11. Download a compliant offline map region, switch to airplane mode, force-close/reopen app, and verify tiles still render.
12. Attempt to configure `tile.openstreetmap.org` as self-hosted URL and verify offline download is blocked.
13. Open Emergency Center in airplane mode; verify tap-to-call, map intent, and copy coordinates.
14. Add journal entries with Photo Picker media; force-close/reopen app and verify persistence.
15. Export a single trip `.zip`, import it via Profile, and verify it imports as a new trip without overwriting the original.
16. Create a full local backup `.zip`, delete a trip, restore backup, and verify full data recovery.
17. Edit a What-If scenario, discard it, and verify main trip is untouched; edit another and confirm Apply.
18. Tap all 4 developer social icons (Instagram, Discord invite, TikTok, WhatsApp) and verify app/browser opening.

> **Environment Execution Note**: Because the build sandbox has no local Android SDK or outbound internet access, automated unit tests and APK compilation are configured to run in GitHub Actions (`.github/workflows/android-build.yml`), and device/airplane-mode acceptance checks must be executed on an Android device using the resulting CI artifact.
