# Triply V2 — Native Android Travel Companion

Triply V2 is a greenfield native Android travel-planning application built with **Kotlin**, **Jetpack Compose**, **Material 3**, **Room**, and **MapLibre Native Android**, following a **Modern Travel Editorial** design direction.

## Highlights & Locked Product Decisions
- **Greenfield Implementation**: Clean package structure (`com.triply.app`), custom editorial design system (`ObsidianCanvas #0F141B`, `SlateSurface #171E28`, `OchreAccent #D99B43`, `IvoryInk #F4F1EA`), and separated data/provider layers.
- **Bilingual First-Class Support**: Complete English (`values/strings.xml`) and Bahasa Indonesia (`values-in/strings.xml`) localization with runtime switching in **Profile > Language**.
- **Online Maps by Default (Zero API Keys Required)**: Uses [MapLibre Native Android](https://github.com/maplibre/maplibre-native) (`11.11.0`) with [OpenFreeMap](https://openfreemap.org/quick_start/) vector tile styles (`Liberty`, `Dark`, `Positron`, `Bright`) and optional offline region management.
- **Local-First Persistence**: All 13 Room tables stay on-device without requiring user accounts or a custom backend.
- **Automatic IDR Formatting**: Pure `Long` numeric storage with automatic Indonesian thousands separators (`Rp150.000`, `Rp1.500.000`) while typing.
- **All 12 Mandatory Travel Modules**:
  1. Guided 7-Step Trip Builder & Multi-Destination (with visual calendar range picker, optional-step skipping, and drafts)
  2. Online Maps, Hybrid POI Discovery (Photon + Overpass + Nominatim fallback), Route Estimates (OSRM), and Offline Region Manager
  3. Budget & Expense Tracker (cross-trip overview + per-trip ledger + gentle threshold warnings)
  4. Alarm & Timeline (day-grouped itinerary with verified exact-alarm scheduling status)
  5. Packing Checklist (General, Hiking, and Beach templates + animated progress)
  6. Accommodation & Transportation (clearly labeled Manual vs. Provider records + non-double-counting Budget sync)
  7. Weather Alert ([Open-Meteo](https://open-meteo.com/en/docs) forecasts, last-updated timestamp, >16-day horizon notice, WMO severe advisories)
  8. Emergency Center (verified Indonesia official numbers separated from personal contacts + on-demand nearby hospitals/pharmacies)
  9. Trip Journal (photo-led offline entries using Android Photo Picker)
  10. Group Management & Portable ZIP Export/Import (security-hardened against Zip-Slip & oversized archives, preview before import)
  11. Offline Mode (live connectivity awareness, Room persistence, Coil image cache, local backup/restore)
  12. What If Planner (non-destructive side-by-side scenario comparison with explicit Apply confirmation)

## Prerequisites & Building the Debug APK

### Option A — Android Studio (Recommended)
1. Install **Android Studio Ladybug (2024.2+)** or newer with **JDK 17** and **Android SDK Platform 35**.
2. Extract `triply-v2-android-source.zip` and open the `triply-v2` folder in Android Studio.
3. Let Gradle sync download dependencies (Kotlin `2.0.21`, AGP `8.7.3`, Compose BOM `2024.12.01`, MapLibre `11.11.0`).
4. Run unit tests: `./gradlew testDebugUnitTest` (or `gradle testDebugUnitTest`).
5. Build the debug APK: `./gradlew assembleDebug` (output: `app/build/outputs/apk/debug/app-debug.apk`).

### Option B — Reproducible CI Build (GitHub Actions)
Push this directory to a GitHub repository (e.g., on branch `triply-v2` or `main`). The included `.github/workflows/android-ci.yml` automatically runs `gradle testDebugUnitTest` and `gradle assembleDebug` on `ubuntu-latest` and publishes `triply-v2-debug-apk` as a downloadable artifact.

### Installing the Debug APK on an Android Device
1. Transfer `app-debug.apk` to an Android 8.0+ (API 26+) device or connect via USB with Developer Options enabled.
2. Install via ADB: `adb install -r app/build/outputs/apk/debug/app-debug.apk` (or tap the APK on the device and allow installation from your file manager).

## Documentation
- [Architecture Guide](docs/ARCHITECTURE.md)
- [Provider Configuration Guide](docs/PROVIDER_CONFIGURATION.md)
- [Privacy & Third-Party Services](docs/PRIVACY_AND_THIRD_PARTY_SERVICES.md)
- [Test Report](docs/TEST_REPORT.md)
- [Known Issues](docs/KNOWN_ISSUES.md)

## Developer Credits
- **Haydar**
- **silent.dt**
  - Instagram: https://www.instagram.com/sailent.dt?dmpr=djVpOWFoZW42bWpj
  - TikTok: https://www.tiktok.com/@sailent.dt?_r=1&_t=ZS-9BfFb7apCx4
  - Discord: https://discord.gg/sfTRrgQq
  - WhatsApp: https://wa.me/6287790421211
