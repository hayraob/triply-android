package com.triply.app.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.triply.app.AppContainer
import com.triply.app.core.alarm.ReminderScheduleResult
import com.triply.app.core.util.LocaleManager
import com.triply.app.data.exchange.ImportPreviewSummary
import com.triply.app.data.exchange.TripPackageManager
import com.triply.app.data.exchange.TripPackagePayload
import com.triply.app.data.local.BookingEntity
import com.triply.app.data.local.BudgetCategoryEntity
import com.triply.app.data.local.EmergencyContactEntity
import com.triply.app.data.local.ExpenseEntity
import com.triply.app.data.local.GroupMemberEntity
import com.triply.app.data.local.ItineraryItemEntity
import com.triply.app.data.local.JournalEntryEntity
import com.triply.app.data.local.OfflineMapRegionEntity
import com.triply.app.data.local.PackingItemEntity
import com.triply.app.data.local.TripDestinationEntity
import com.triply.app.data.local.TripEntity
import com.triply.app.data.local.UserPreferences
import com.triply.app.data.local.WhatIfScenarioEntity
import com.triply.app.domain.PackingTemplates
import com.triply.app.domain.PlaceResult
import com.triply.app.domain.PoiCategory
import com.triply.app.domain.RouteEstimate
import com.triply.app.domain.WeatherForecastResult
import com.triply.app.domain.WhatIfEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.InputStream
import java.io.OutputStream
import java.time.LocalDate
import java.time.ZoneId
import java.util.UUID

data class FeaturedDestination(
    val name: String,
    val region: String,
    val latitude: Double,
    val longitude: Double,
    val imageUrl: String? = null
)

class TriplyViewModel(private val container: AppContainer) : ViewModel() {

    private val tripDao = container.database.tripDao()
    private val utilityDao = container.database.utilityDao()

    val isOnline: StateFlow<Boolean> = container.networkMonitor.isOnlineFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    val preferences: StateFlow<UserPreferences> = container.preferences.preferencesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserPreferences())

    val allTrips: StateFlow<List<TripEntity>> = tripDao.observeAllTrips()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allExpenses: StateFlow<List<ExpenseEntity>> = tripDao.observeAllExpenses()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val emergencyContacts: StateFlow<List<EmergencyContactEntity>> = utilityDao.observeEmergencyContacts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val offlineRegions: StateFlow<List<OfflineMapRegionEntity>> = utilityDao.observeOfflineMapRegions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Explore featured destinations populated with real Wikimedia images
    private val _featuredDestinations = MutableStateFlow(
        listOf(
            FeaturedDestination("Yogyakarta", "DI Yogyakarta, Indonesia", -7.7956, 110.3695),
            FeaturedDestination("Mount Bromo", "East Java, Indonesia", -7.9425, 112.9530),
            FeaturedDestination("Ubud", "Bali, Indonesia", -8.5069, 115.2625),
            FeaturedDestination("Labuan Bajo", "East Nusa Tenggara, Indonesia", -8.4964, 119.8877),
            FeaturedDestination("Dieng Plateau", "Central Java, Indonesia", -7.2067, 109.9145)
        )
    )
    val featuredDestinations: StateFlow<List<FeaturedDestination>> = _featuredDestinations.asStateFlow()

    // Live Map & POI Search state
    private val _searchResults = MutableStateFlow<List<PlaceResult>>(emptyList())
    val searchResults: StateFlow<List<PlaceResult>> = _searchResults.asStateFlow()

    private val _isSearchingPlaces = MutableStateFlow(false)
    val isSearchingPlaces: StateFlow<Boolean> = _isSearchingPlaces.asStateFlow()

    private val _placeSearchError = MutableStateFlow<String?>(null)
    val placeSearchError: StateFlow<String?> = _placeSearchError.asStateFlow()

    private val _routeEstimate = MutableStateFlow<RouteEstimate?>(null)
    val routeEstimate: StateFlow<RouteEstimate?> = _routeEstimate.asStateFlow()

    // Weather state
    private val _weatherForecast = MutableStateFlow<WeatherForecastResult?>(null)
    val weatherForecast: StateFlow<WeatherForecastResult?> = _weatherForecast.asStateFlow()

    private val _weatherError = MutableStateFlow<String?>(null)
    val weatherError: StateFlow<String?> = _weatherError.asStateFlow()

    private val _isLoadingWeather = MutableStateFlow(false)
    val isLoadingWeather: StateFlow<Boolean> = _isLoadingWeather.asStateFlow()

    // Nearby emergency POIs
    private val _nearbyEmergencyPlaces = MutableStateFlow<List<PlaceResult>>(emptyList())
    val nearbyEmergencyPlaces: StateFlow<List<PlaceResult>> = _nearbyEmergencyPlaces.asStateFlow()

    // ZIP Import preview state
    private val _importPreview = MutableStateFlow<ImportPreviewSummary?>(null)
    val importPreview: StateFlow<ImportPreviewSummary?> = _importPreview.asStateFlow()

    private val _providerTestStatus = MutableStateFlow<String?>(null)
    val providerTestStatus: StateFlow<String?> = _providerTestStatus.asStateFlow()

    private var searchDebounceJob: Job? = null

    init {
        loadFeaturedImages()
    }

    private fun loadFeaturedImages() {
        viewModelScope.launch {
            val updated = _featuredDestinations.value.map { dest ->
                val url = container.imageProvider.fetchImageForPlace(dest.name).getOrNull()
                dest.copy(imageUrl = url)
            }
            _featuredDestinations.value = updated
        }
    }

    fun mapStyleUrl(): String {
        val prefs = preferences.value
        return container.mapTileProvider.styleUrlFor(prefs.mapStyleId, prefs.customMapStyleUrl)
    }

    fun searchPlacesDebounced(query: String) {
        searchDebounceJob?.cancel()
        if (query.trim().length < 2) {
            _searchResults.value = emptyList()
            _placeSearchError.value = null
            return
        }
        searchDebounceJob = viewModelScope.launch {
            delay(450L)
            _isSearchingPlaces.value = true
            _placeSearchError.value = null
            container.placeRepository.searchText(query)
                .onSuccess { _searchResults.value = it }
                .onFailure { _placeSearchError.value = it.message ?: "Search unavailable" }
            _isSearchingPlaces.value = false
        }
    }

    fun searchPoisByCategory(category: PoiCategory, lat: Double, lon: Double) {
        viewModelScope.launch {
            _isSearchingPlaces.value = true
            _placeSearchError.value = null
            container.placeRepository.searchCategory(category, lat, lon)
                .onSuccess { _searchResults.value = it }
                .onFailure { _placeSearchError.value = it.message ?: "POI search unavailable" }
            _isSearchingPlaces.value = false
        }
    }

    fun estimateRoute(fromLat: Double, fromLon: Double, toLat: Double, toLon: Double, mode: String) {
        viewModelScope.launch {
            container.routingProvider.estimateRoute(fromLat, fromLon, toLat, toLon, mode)
                .onSuccess { _routeEstimate.value = it }
        }
    }

    // --- Trip CRUD & Module 1 Builder ---
    fun saveNewTrip(
        title: String,
        startEpochDay: Long,
        endEpochDay: Long,
        travelStyle: String,
        transportMode: String,
        totalBudgetIdr: Long,
        destinations: List<TripDestinationEntity>,
        accommodationNote: String,
        isDraft: Boolean,
        onSaved: (String) -> Unit
    ) {
        viewModelScope.launch {
            val tripId = UUID.randomUUID().toString()
            val firstDestName = destinations.firstOrNull()?.name ?: title
            val coverUrl = destinations.firstOrNull()?.imageUrl
                ?: container.imageProvider.fetchImageForPlace(firstDestName).getOrNull()

            val trip = TripEntity(
                id = tripId,
                title = title.ifBlank { firstDestName },
                startDateEpochDay = startEpochDay,
                endDateEpochDay = endEpochDay,
                travelStyle = travelStyle,
                transportMode = transportMode,
                totalBudgetIdr = totalBudgetIdr,
                coverImageUrl = coverUrl,
                isDraft = isDraft
            )
            tripDao.upsertTrip(trip)
            val ordered = destinations.mapIndexed { idx, d -> d.copy(tripId = tripId, orderIndex = idx) }
            tripDao.upsertDestinations(ordered)

            // Seed balanced budget categories if budget set
            if (totalBudgetIdr > 0L) {
                val cats = listOf(
                    BudgetCategoryEntity(UUID.randomUUID().toString(), tripId, "Transport", (totalBudgetIdr * 0.30).toLong()),
                    BudgetCategoryEntity(UUID.randomUUID().toString(), tripId, "Accommodation", (totalBudgetIdr * 0.35).toLong()),
                    BudgetCategoryEntity(UUID.randomUUID().toString(), tripId, "Food & Dining", (totalBudgetIdr * 0.20).toLong()),
                    BudgetCategoryEntity(UUID.randomUUID().toString(), tripId, "Activities", (totalBudgetIdr * 0.15).toLong())
                )
                tripDao.upsertBudgetCategories(cats)
            }

            if (accommodationNote.isNotBlank()) {
                tripDao.upsertBooking(
                    BookingEntity(
                        id = UUID.randomUUID().toString(),
                        tripId = tripId,
                        type = "ACCOMMODATION",
                        name = accommodationNote.trim(),
                        sourceType = "MANUAL_RECORD"
                    )
                )
            }
            onSaved(tripId)
        }
    }

    fun deleteTrip(trip: TripEntity) {
        viewModelScope.launch { tripDao.deleteTrip(trip) }
    }

    // Per-trip Flows
    fun observeTrip(tripId: String) = tripDao.observeTrip(tripId)
    fun observeDestinations(tripId: String) = tripDao.observeDestinations(tripId)
    fun observeItinerary(tripId: String) = tripDao.observeItinerary(tripId)
    fun observeBudgetCategories(tripId: String) = tripDao.observeBudgetCategories(tripId)
    fun observeExpenses(tripId: String) = tripDao.observeExpenses(tripId)
    fun observePackingItems(tripId: String) = tripDao.observePackingItems(tripId)
    fun observeBookings(tripId: String) = tripDao.observeBookings(tripId)
    fun observeJournalEntries(tripId: String) = tripDao.observeJournalEntries(tripId)
    fun observeGroupMembers(tripId: String) = tripDao.observeGroupMembers(tripId)
    fun observeWhatIfScenarios(tripId: String) = tripDao.observeWhatIfScenarios(tripId)

    // Module 3: Budget & Expenses
    fun addExpense(tripId: String, category: String, title: String, amountIdr: Long, payer: String, notes: String) {
        viewModelScope.launch {
            tripDao.upsertExpense(
                ExpenseEntity(
                    id = UUID.randomUUID().toString(),
                    tripId = tripId,
                    categoryName = category.ifBlank { "General" },
                    title = title.trim(),
                    amountIdr = amountIdr,
                    dateEpochDay = LocalDate.now().toEpochDay(),
                    payerName = payer.trim(),
                    notes = notes.trim()
                )
            )
        }
    }

    fun deleteExpense(expense: ExpenseEntity) {
        viewModelScope.launch { tripDao.deleteExpense(expense) }
    }

    // Module 4: Timeline & Alarms
    fun addItineraryItem(
        trip: TripEntity,
        dayIndex: Int,
        title: String,
        startTimeMinutes: Int,
        locationName: String,
        notes: String,
        enableReminder: Boolean
    ) {
        viewModelScope.launch {
            val reqCode = (System.currentTimeMillis() % Int.MAX_VALUE).toInt()
            var confirmed = false
            if (enableReminder) {
                val targetDate = LocalDate.ofEpochDay(trip.startDateEpochDay + dayIndex)
                val triggerMillis = targetDate
                    .atTime(startTimeMinutes / 60, startTimeMinutes % 60)
                    .atZone(ZoneId.systemDefault())
                    .toInstant()
                    .toEpochMilli()
                val res = container.reminderScheduler.scheduleReminder(
                    requestCode = reqCode,
                    triggerAtMillis = triggerMillis,
                    title = trip.title,
                    body = title
                )
                confirmed = (res == ReminderScheduleResult.SCHEDULED_EXACT)
            }
            tripDao.upsertItineraryItem(
                ItineraryItemEntity(
                    id = UUID.randomUUID().toString(),
                    tripId = trip.id,
                    dayIndex = dayIndex,
                    title = title.trim(),
                    startTimeMinutes = startTimeMinutes,
                    locationName = locationName.trim(),
                    notes = notes.trim(),
                    reminderEnabled = enableReminder,
                    reminderScheduledConfirmed = confirmed,
                    reminderRequestCode = reqCode
                )
            )
        }
    }

    fun deleteItineraryItem(item: ItineraryItemEntity) {
        viewModelScope.launch {
            if (item.reminderRequestCode != 0) {
                container.reminderScheduler.cancelReminder(item.reminderRequestCode)
            }
            tripDao.deleteItineraryItem(item)
        }
    }

    // Module 5: Packing Checklist
    fun applyPackingTemplate(tripId: String, templateId: String) {
        viewModelScope.launch {
            val items = PackingTemplates.itemsForTemplate(tripId, templateId) { UUID.randomUUID().toString() }
            tripDao.upsertPackingItems(items)
        }
    }

    fun addPackingItem(tripId: String, category: String, name: String, quantity: Int, assignedTo: String = "") {
        viewModelScope.launch {
            tripDao.upsertPackingItem(
                PackingItemEntity(
                    id = UUID.randomUUID().toString(),
                    tripId = tripId,
                    category = category.ifBlank { "General" },
                    name = name.trim(),
                    quantity = maxOf(1, quantity),
                    assignedTo = assignedTo.trim()
                )
            )
        }
    }

    fun togglePackingItem(item: PackingItemEntity) {
        viewModelScope.launch { tripDao.upsertPackingItem(item.copy(isPacked = !item.isPacked)) }
    }

    fun deletePackingItem(item: PackingItemEntity) {
        viewModelScope.launch { tripDao.deletePackingItem(item) }
    }

    // Module 6: Accommodation & Transportation (with non-double-counting budget sync)
    fun addBooking(
        tripId: String,
        type: String,
        name: String,
        address: String,
        contactInfo: String,
        startDateTimeIso: String,
        priceIdr: Long,
        bookingUrl: String,
        notes: String,
        sourceType: String = "MANUAL_RECORD",
        providerName: String = ""
    ) {
        viewModelScope.launch {
            tripDao.upsertBooking(
                BookingEntity(
                    id = UUID.randomUUID().toString(),
                    tripId = tripId,
                    type = type,
                    name = name.trim(),
                    address = address.trim(),
                    contactInfo = contactInfo.trim(),
                    startDateTimeIso = startDateTimeIso.trim(),
                    priceIdr = priceIdr,
                    bookingUrl = bookingUrl.trim(),
                    notes = notes.trim(),
                    sourceType = sourceType,
                    providerName = providerName
                )
            )
        }
    }

    fun syncBookingToBudget(booking: BookingEntity) {
        viewModelScope.launch {
            if (booking.syncedToBudget || booking.priceIdr <= 0L) return@launch
            val existing = tripDao.getExpenseByBookingId(booking.id)
            if (existing == null) {
                val category = if (booking.type == "ACCOMMODATION") "Accommodation" else "Transport"
                tripDao.upsertExpense(
                    ExpenseEntity(
                        id = UUID.randomUUID().toString(),
                        tripId = booking.tripId,
                        categoryName = category,
                        title = booking.name,
                        amountIdr = booking.priceIdr,
                        dateEpochDay = LocalDate.now().toEpochDay(),
                        notes = "Synced from ${booking.type.lowercase()}",
                        sourceBookingId = booking.id
                    )
                )
            }
            tripDao.updateBooking(booking.copy(syncedToBudget = true))
        }
    }

    fun deleteBooking(booking: BookingEntity) {
        viewModelScope.launch { tripDao.deleteBooking(booking) }
    }

    // Module 7: Weather Alert
    fun loadWeatherForTrip(trip: TripEntity, destinations: List<TripDestinationEntity>) {
        val target = destinations.firstOrNull() ?: return
        viewModelScope.launch {
            _isLoadingWeather.value = true
            _weatherError.value = null
            container.weatherProvider.fetchForecast(
                destinationName = target.name,
                latitude = target.latitude,
                longitude = target.longitude,
                tripStartEpochDay = trip.startDateEpochDay,
                tripEndEpochDay = trip.endDateEpochDay
            ).onSuccess { _weatherForecast.value = it }
                .onFailure { _weatherError.value = it.message ?: "Weather unavailable" }
            _isLoadingWeather.value = false
        }
    }

    // Module 8: Emergency Center
    fun addPersonalEmergencyContact(name: String, phone: String, notes: String) {
        viewModelScope.launch {
            utilityDao.upsertEmergencyContact(
                EmergencyContactEntity(
                    id = UUID.randomUUID().toString(),
                    name = name.trim(),
                    phoneNumber = phone.trim(),
                    category = "PERSONAL",
                    notes = notes.trim()
                )
            )
        }
    }

    fun deleteEmergencyContact(contact: EmergencyContactEntity) {
        viewModelScope.launch { utilityDao.deleteEmergencyContact(contact) }
    }

    fun searchNearbyEmergencyFacilities(lat: Double, lon: Double) {
        viewModelScope.launch {
            val hospitals = container.placeRepository.searchCategory(PoiCategory.HOSPITAL, lat, lon).getOrDefault(emptyList())
            val pharmacies = container.placeRepository.searchCategory(PoiCategory.PHARMACY, lat, lon).getOrDefault(emptyList())
            _nearbyEmergencyPlaces.value = (hospitals.take(5) + pharmacies.take(5))
        }
    }

    // Module 9: Trip Journal
    fun addJournalEntry(tripId: String, dayIndex: Int, title: String, body: String, locationName: String, photoUri: String?) {
        viewModelScope.launch {
            tripDao.upsertJournalEntry(
                JournalEntryEntity(
                    id = UUID.randomUUID().toString(),
                    tripId = tripId,
                    dayIndex = dayIndex,
                    dateEpochDay = LocalDate.now().toEpochDay(),
                    title = title.trim(),
                    body = body.trim(),
                    locationName = locationName.trim(),
                    photoUri = photoUri
                )
            )
        }
    }

    fun deleteJournalEntry(entry: JournalEntryEntity) {
        viewModelScope.launch { tripDao.deleteJournalEntry(entry) }
    }

    // Module 10: Group Management & ZIP Export/Import
    fun addGroupMember(tripId: String, name: String, roleLabel: String) {
        viewModelScope.launch {
            tripDao.upsertGroupMember(
                GroupMemberEntity(
                    id = UUID.randomUUID().toString(),
                    tripId = tripId,
                    name = name.trim(),
                    roleLabel = roleLabel.trim()
                )
            )
        }
    }

    fun deleteGroupMember(member: GroupMemberEntity) {
        viewModelScope.launch { tripDao.deleteGroupMember(member) }
    }

    fun exportTripZip(tripId: String, output: OutputStream, onDone: (Result<Unit>) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val result = runCatching {
                val trip = tripDao.getTripById(tripId) ?: error("Trip not found")
                val payload = TripPackagePayload(
                    trip = trip,
                    destinations = tripDao.getDestinationsOnce(tripId),
                    itinerary = tripDao.getItineraryOnce(tripId),
                    budgetCategories = tripDao.getBudgetCategoriesOnce(tripId),
                    expenses = tripDao.getExpensesOnce(tripId),
                    packingItems = tripDao.getPackingItemsOnce(tripId),
                    bookings = tripDao.getBookingsOnce(tripId),
                    journalEntries = tripDao.getJournalEntriesOnce(tripId),
                    groupMembers = tripDao.getGroupMembersOnce(tripId),
                    whatIfScenarios = tripDao.getWhatIfScenariosOnce(tripId)
                )
                TripPackageManager.exportToZip(payload, emptyMap(), output)
            }
            onDone(result)
        }
    }

    fun inspectImportZip(input: InputStream, onError: (String) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val existingIds = tripDao.getAllTripsOnce().map { it.id }.toSet()
            TripPackageManager.inspectAndValidateZip(input, existingIds)
                .onSuccess { _importPreview.value = it }
                .onFailure { onError(it.message ?: "Invalid ZIP package") }
        }
    }

    fun confirmImportPreview() {
        val preview = _importPreview.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val payload = preview.payload
            val newTripId = if (preview.hasTripIdConflict) UUID.randomUUID().toString() else payload.trip.id
            tripDao.upsertTrip(payload.trip.copy(id = newTripId))
            tripDao.upsertDestinations(payload.destinations.map { it.copy(id = UUID.randomUUID().toString(), tripId = newTripId) })
            payload.itinerary.forEach { tripDao.upsertItineraryItem(it.copy(id = UUID.randomUUID().toString(), tripId = newTripId)) }
            tripDao.upsertBudgetCategories(payload.budgetCategories.map { it.copy(id = UUID.randomUUID().toString(), tripId = newTripId) })
            payload.expenses.forEach { tripDao.upsertExpense(it.copy(id = UUID.randomUUID().toString(), tripId = newTripId)) }
            tripDao.upsertPackingItems(payload.packingItems.map { it.copy(id = UUID.randomUUID().toString(), tripId = newTripId) })
            payload.bookings.forEach { tripDao.upsertBooking(it.copy(id = UUID.randomUUID().toString(), tripId = newTripId)) }
            payload.journalEntries.forEach { tripDao.upsertJournalEntry(it.copy(id = UUID.randomUUID().toString(), tripId = newTripId)) }
            payload.groupMembers.forEach { tripDao.upsertGroupMember(it.copy(id = UUID.randomUUID().toString(), tripId = newTripId)) }
            payload.whatIfScenarios.forEach { tripDao.upsertWhatIfScenario(it.copy(id = UUID.randomUUID().toString(), tripId = newTripId)) }
            _importPreview.value = null
        }
    }

    fun dismissImportPreview() {
        _importPreview.value = null
    }

    // Module 11: Offline Map Regions metadata
    fun saveOfflineRegionRecord(name: String, minLat: Double, maxLat: Double, minLon: Double, maxLon: Double, estMb: Int) {
        viewModelScope.launch {
            utilityDao.upsertOfflineMapRegion(
                OfflineMapRegionEntity(
                    id = UUID.randomUUID().toString(),
                    name = name,
                    minLat = minLat,
                    maxLat = maxLat,
                    minLon = minLon,
                    maxLon = maxLon,
                    minZoom = 8.0,
                    maxZoom = 14.0,
                    estimatedSizeMb = estMb,
                    status = "READY"
                )
            )
        }
    }

    fun deleteOfflineRegion(region: OfflineMapRegionEntity) {
        viewModelScope.launch { utilityDao.deleteOfflineMapRegion(region) }
    }

    // Module 12: What If Planner
    fun addWhatIfScenario(
        tripId: String,
        title: String,
        altStartEpochDay: Long,
        altEndEpochDay: Long,
        altTransportMode: String,
        altBudgetIdr: Long,
        altDestinationSummary: String,
        notes: String
    ) {
        viewModelScope.launch {
            tripDao.upsertWhatIfScenario(
                WhatIfScenarioEntity(
                    id = UUID.randomUUID().toString(),
                    tripId = tripId,
                    title = title.trim(),
                    altStartDateEpochDay = altStartEpochDay,
                    altEndDateEpochDay = altEndEpochDay,
                    altTransportMode = altTransportMode,
                    altBudgetIdr = altBudgetIdr,
                    altDestinationSummary = altDestinationSummary.trim(),
                    estimateSource = "User estimate",
                    notes = notes.trim()
                )
            )
        }
    }

    fun applyWhatIfScenario(trip: TripEntity, scenario: WhatIfScenarioEntity) {
        viewModelScope.launch {
            val updated = WhatIfEngine.applyScenarioToTrip(trip, scenario, System.currentTimeMillis())
            tripDao.upsertTrip(updated)
        }
    }

    fun deleteWhatIfScenario(scenario: WhatIfScenarioEntity) {
        viewModelScope.launch { tripDao.deleteWhatIfScenario(scenario) }
    }

    // Settings & Preferences
    fun setLanguage(tag: String) {
        viewModelScope.launch {
            container.preferences.setLanguage(tag)
            LocaleManager.applyLanguage(tag)
        }
    }

    fun setMapStyle(styleId: String) {
        viewModelScope.launch { container.preferences.setMapStyle(styleId) }
    }

    fun setOnlineMapsDefault(enabled: Boolean) {
        viewModelScope.launch { container.preferences.setOnlineMapsDefault(enabled) }
    }

    fun setAllowMobileData(enabled: Boolean) {
        viewModelScope.launch { container.preferences.setAllowMobileDataDownloads(enabled) }
    }

    fun saveDeveloperOverrides(mapStyleUrl: String, routingUrl: String) {
        viewModelScope.launch { container.preferences.setDeveloperOverrides(mapStyleUrl, routingUrl) }
    }

    fun testProviderConnectivity() {
        viewModelScope.launch {
            _providerTestStatus.value = "Testing Photon & Open-Meteo…"
            val geoOk = container.photonProvider.searchPlaces("Jakarta", limit = 1).isSuccess
            val weatherOk = container.weatherProvider.fetchForecast(
                "Jakarta", -6.2088, 106.8456, LocalDate.now().toEpochDay(), LocalDate.now().plusDays(1).toEpochDay()
            ).isSuccess
            _providerTestStatus.value = "Photon: ${if (geoOk) "OK" else "Unavailable"} · Open-Meteo: ${if (weatherOk) "OK" else "Unavailable"}"
        }
    }

    class Factory(private val container: AppContainer) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return TriplyViewModel(container) as T
        }
    }
}
