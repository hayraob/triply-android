package com.triply.app.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Call
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Map
import androidx.compose.material.icons.outlined.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.triply.app.R
import com.triply.app.core.designsystem.EditorialBadge
import com.triply.app.core.designsystem.EditorialDestinationImage
import com.triply.app.core.designsystem.EditorialKeyValueRow
import com.triply.app.core.designsystem.EditorialProgressBar
import com.triply.app.core.designsystem.EditorialSecondaryButton
import com.triply.app.core.designsystem.IdrAmountTextField
import com.triply.app.core.designsystem.OfflineStatusBanner
import com.triply.app.core.designsystem.TriplyColors
import com.triply.app.core.util.DateUtils
import com.triply.app.core.util.IdrFormatter
import com.triply.app.data.local.TripEntity
import com.triply.app.domain.BudgetCalculator
import com.triply.app.domain.BudgetThresholdStatus
import com.triply.app.domain.PackingTemplates
import com.triply.app.domain.WhatIfEngine
import com.triply.app.ui.TriplyViewModel

@Composable
fun TripDetailScreen(
    tripId: String,
    viewModel: TriplyViewModel,
    onBack: () -> Unit,
    onOpenMap: () -> Unit
) {
    val trip by viewModel.observeTrip(tripId).collectAsState(initial = null)
    val destinations by viewModel.observeDestinations(tripId).collectAsState(initial = emptyList())
    val isOnline by viewModel.isOnline.collectAsState()
    var activeTab by remember { mutableIntStateOf(0) }

    val moduleTabs = listOf(
        R.string.tab_timeline,
        R.string.tab_budget,
        R.string.tab_packing,
        R.string.tab_bookings,
        R.string.tab_weather,
        R.string.tab_emergency,
        R.string.tab_journal,
        R.string.tab_group,
        R.string.tab_whatif
    )

    val currentTrip = trip ?: return

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(TriplyColors.ObsidianCanvas)
    ) {
        // Editorial header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = null, tint = TriplyColors.IvoryInk)
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(currentTrip.title, style = MaterialTheme.typography.titleLarge, color = TriplyColors.IvoryInk)
                Text(
                    DateUtils.formatDateRange(currentTrip.startDateEpochDay, currentTrip.endDateEpochDay),
                    style = MaterialTheme.typography.labelSmall,
                    color = TriplyColors.OchreAccent
                )
            }
            IconButton(onClick = onOpenMap) {
                Icon(Icons.Outlined.Map, contentDescription = stringResource(R.string.action_open_map), tint = TriplyColors.OchreAccent)
            }
        }

        OfflineStatusBanner(isOnline = isOnline, modifier = Modifier.padding(horizontal = 16.dp))

        // Horizontal Module Rail
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(moduleTabs.indices.toList()) { idx ->
                FilterChip(
                    selected = activeTab == idx,
                    onClick = { activeTab = idx },
                    label = { Text(stringResource(moduleTabs[idx])) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = TriplyColors.OchreAccent,
                        selectedLabelColor = TriplyColors.ObsidianCanvas,
                        containerColor = TriplyColors.SlateSurface,
                        labelColor = TriplyColors.IvoryInk
                    )
                )
            }
        }

        when (activeTab) {
            0 -> TimelineTab(currentTrip, viewModel)
            1 -> TripBudgetTab(currentTrip, viewModel)
            2 -> PackingTab(currentTrip.id, viewModel)
            3 -> BookingsTab(currentTrip.id, viewModel)
            4 -> WeatherTab(currentTrip, destinations, viewModel)
            5 -> EmergencyTab(destinations, viewModel)
            6 -> JournalTab(currentTrip.id, viewModel)
            7 -> GroupTab(currentTrip.id, viewModel)
            8 -> WhatIfTab(currentTrip, viewModel)
        }
    }
}

@Composable
private fun TimelineTab(trip: TripEntity, viewModel: TriplyViewModel) {
    val items by viewModel.observeItinerary(trip.id).collectAsState(initial = emptyList())
    var title by remember { mutableStateOf("") }
    var timeText by remember { mutableStateOf("08:30") }
    var location by remember { mutableStateOf("") }
    var dayIdx by remember { mutableIntStateOf(0) }
    var reminder by remember { mutableStateOf(false) }

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Surface(color = TriplyColors.SlateSurface, shape = RoundedCornerShape(10.dp), border = BorderStroke(1.dp, TriplyColors.HairlineBorder)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(stringResource(R.string.timeline_add_activity), style = MaterialTheme.typography.titleMedium, color = TriplyColors.IvoryInk)
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text(stringResource(R.string.timeline_activity_title)) }, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = timeText, onValueChange = { timeText = it }, label = { Text(stringResource(R.string.timeline_activity_time)) }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = location, onValueChange = { location = it }, label = { Text(stringResource(R.string.timeline_activity_location)) }, modifier = Modifier.weight(1.4f))
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text(stringResource(R.string.timeline_reminder_toggle), color = TriplyColors.WarmStone, style = MaterialTheme.typography.bodyMedium)
                        Switch(checked = reminder, onCheckedChange = { reminder = it })
                    }
                    Text(stringResource(R.string.timeline_permission_rationale), style = MaterialTheme.typography.labelSmall, color = TriplyColors.MutedAsh)
                    Button(
                        onClick = {
                            if (title.isBlank()) return@Button
                            val parts = timeText.split(":")
                            val mins = (parts.getOrNull(0)?.toIntOrNull() ?: 8) * 60 + (parts.getOrNull(1)?.toIntOrNull() ?: 0)
                            viewModel.addItineraryItem(trip, dayIdx, title, mins, location, "", reminder)
                            title = ""
                            location = ""
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = TriplyColors.OchreAccent, contentColor = TriplyColors.ObsidianCanvas)
                    ) { Text(stringResource(R.string.action_add)) }
                }
            }
        }
        items(items, key = { it.id }) { item ->
            val hh = item.startTimeMinutes / 60
            val mm = item.startTimeMinutes % 60
            Surface(color = TriplyColors.SlateSurface, shape = RoundedCornerShape(10.dp), border = BorderStroke(1.dp, TriplyColors.HairlineBorder)) {
                Row(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("${stringResource(R.string.timeline_day_label, item.dayIndex + 1)} · %02d:%02d".format(hh, mm), style = MaterialTheme.typography.labelSmall, color = TriplyColors.OchreAccent)
                        Text(item.title, style = MaterialTheme.typography.titleMedium, color = TriplyColors.IvoryInk)
                        if (item.locationName.isNotBlank()) Text(item.locationName, style = MaterialTheme.typography.bodyMedium, color = TriplyColors.WarmStone)
                        if (item.reminderEnabled) {
                            EditorialBadge(
                                text = stringResource(if (item.reminderScheduledConfirmed) R.string.timeline_reminder_confirmed else R.string.timeline_reminder_unconfirmed),
                                tint = if (item.reminderScheduledConfirmed) TriplyColors.SageSuccess else TriplyColors.AmberWarning
                            )
                        }
                    }
                    IconButton(onClick = { viewModel.deleteItineraryItem(item) }) {
                        Icon(Icons.Outlined.DeleteOutline, contentDescription = null, tint = TriplyColors.CrimsonAlert)
                    }
                }
            }
        }
    }
}

@Composable
private fun TripBudgetTab(trip: TripEntity, viewModel: TriplyViewModel) {
    val categories by viewModel.observeBudgetCategories(trip.id).collectAsState(initial = emptyList())
    val expenses by viewModel.observeExpenses(trip.id).collectAsState(initial = emptyList())
    val summary = remember(trip.totalBudgetIdr, categories, expenses) {
        BudgetCalculator.summarize(trip.totalBudgetIdr, categories, expenses)
    }

    var expTitle by remember { mutableStateOf("") }
    var expDigits by remember { mutableStateOf("") }
    var expCategory by remember { mutableStateOf("Food & Dining") }
    var expPayer by remember { mutableStateOf("") }

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Surface(color = TriplyColors.SlateSurface, shape = RoundedCornerShape(10.dp), border = BorderStroke(1.dp, TriplyColors.HairlineBorder)) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    EditorialKeyValueRow(stringResource(R.string.budget_total_planned), IdrFormatter.format(summary.totalPlannedIdr))
                    EditorialKeyValueRow(stringResource(R.string.budget_total_spent), IdrFormatter.format(summary.totalSpentIdr), TriplyColors.OchreAccent)
                    EditorialKeyValueRow(
                        stringResource(R.string.budget_remaining),
                        IdrFormatter.format(summary.remainingIdr),
                        if (summary.remainingIdr < 0L) TriplyColors.CrimsonAlert else TriplyColors.SageSuccess
                    )
                    EditorialProgressBar(
                        progress = summary.utilizationPercent / 100f,
                        color = when (summary.status) {
                            BudgetThresholdStatus.EXCEEDED -> TriplyColors.CrimsonAlert
                            BudgetThresholdStatus.APPROACHING -> TriplyColors.AmberWarning
                            BudgetThresholdStatus.HEALTHY -> TriplyColors.SageSuccess
                        }
                    )
                    if (summary.status == BudgetThresholdStatus.APPROACHING) {
                        Text(stringResource(R.string.budget_warning_approaching, summary.utilizationPercent), color = TriplyColors.AmberWarning, style = MaterialTheme.typography.bodyMedium)
                    } else if (summary.status == BudgetThresholdStatus.EXCEEDED) {
                        Text(stringResource(R.string.budget_warning_exceeded, IdrFormatter.format(-summary.remainingIdr)), color = TriplyColors.CrimsonAlert, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
        item {
            Surface(color = TriplyColors.SlateSurface, shape = RoundedCornerShape(10.dp), border = BorderStroke(1.dp, TriplyColors.HairlineBorder)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(stringResource(R.string.budget_add_expense), style = MaterialTheme.typography.titleMedium, color = TriplyColors.IvoryInk)
                    OutlinedTextField(value = expTitle, onValueChange = { expTitle = it }, label = { Text(stringResource(R.string.budget_expense_title)) }, modifier = Modifier.fillMaxWidth())
                    IdrAmountTextField(rawDigits = expDigits, onRawDigitsChange = { expDigits = it }, label = stringResource(R.string.budget_expense_amount))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = expCategory, onValueChange = { expCategory = it }, label = { Text(stringResource(R.string.budget_expense_category)) }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = expPayer, onValueChange = { expPayer = it }, label = { Text(stringResource(R.string.budget_expense_payer)) }, modifier = Modifier.weight(1f))
                    }
                    Button(
                        onClick = {
                            val amt = IdrFormatter.parseToLong(expDigits)
                            if (expTitle.isBlank() || amt <= 0L) return@Button
                            viewModel.addExpense(trip.id, expCategory, expTitle, amt, expPayer, "")
                            expTitle = ""
                            expDigits = ""
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = TriplyColors.OchreAccent, contentColor = TriplyColors.ObsidianCanvas)
                    ) { Text(stringResource(R.string.action_save)) }
                }
            }
        }
        items(expenses, key = { it.id }) { exp ->
            Surface(color = TriplyColors.ElevatedSurface, shape = RoundedCornerShape(8.dp)) {
                Row(modifier = Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(exp.title, style = MaterialTheme.typography.titleMedium, color = TriplyColors.IvoryInk)
                        Text("${exp.categoryName}${if (exp.payerName.isNotBlank()) " · ${exp.payerName}" else ""}", style = MaterialTheme.typography.labelSmall, color = TriplyColors.WarmStone)
                    }
                    Text(IdrFormatter.format(exp.amountIdr), style = MaterialTheme.typography.titleMedium, color = TriplyColors.OchreAccent)
                    IconButton(onClick = { viewModel.deleteExpense(exp) }) {
                        Icon(Icons.Outlined.DeleteOutline, contentDescription = null, tint = TriplyColors.CrimsonAlert)
                    }
                }
            }
        }
    }
}

@Composable
private fun PackingTab(tripId: String, viewModel: TriplyViewModel) {
    val items by viewModel.observePackingItems(tripId).collectAsState(initial = emptyList())
    val packedCount = items.count { it.isPacked }
    val ratio = PackingTemplates.completionRatio(items)
    var newName by remember { mutableStateOf("") }
    var newCat by remember { mutableStateOf("Essentials") }

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(stringResource(R.string.packing_progress, packedCount, items.size), style = MaterialTheme.typography.titleMedium, color = TriplyColors.IvoryInk)
                EditorialProgressBar(progress = ratio, color = TriplyColors.SageSuccess)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    EditorialSecondaryButton(stringResource(R.string.packing_template_general), { viewModel.applyPackingTemplate(tripId, "general") })
                    EditorialSecondaryButton(stringResource(R.string.packing_template_hiking), { viewModel.applyPackingTemplate(tripId, "hiking") })
                    EditorialSecondaryButton(stringResource(R.string.packing_template_beach), { viewModel.applyPackingTemplate(tripId, "beach") })
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(value = newName, onValueChange = { newName = it }, label = { Text(stringResource(R.string.packing_item_name)) }, modifier = Modifier.weight(1f))
                Button(
                    onClick = {
                        if (newName.isBlank()) return@Button
                        viewModel.addPackingItem(tripId, newCat, newName, 1)
                        newName = ""
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TriplyColors.OchreAccent, contentColor = TriplyColors.ObsidianCanvas)
                ) { Text(stringResource(R.string.action_add)) }
            }
        }
        items(items, key = { it.id }) { item ->
            Surface(color = TriplyColors.SlateSurface, shape = RoundedCornerShape(8.dp), border = BorderStroke(1.dp, TriplyColors.HairlineBorder)) {
                Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = item.isPacked, onCheckedChange = { viewModel.togglePackingItem(item) })
                    Column(modifier = Modifier.weight(1f)) {
                        Text(item.name, style = MaterialTheme.typography.bodyLarge, color = TriplyColors.IvoryInk)
                        Text("${item.category} · x${item.quantity}", style = MaterialTheme.typography.labelSmall, color = TriplyColors.MutedAsh)
                    }
                    IconButton(onClick = { viewModel.deletePackingItem(item) }) {
                        Icon(Icons.Outlined.DeleteOutline, contentDescription = null, tint = TriplyColors.CrimsonAlert)
                    }
                }
            }
        }
    }
}

@Composable
private fun BookingsTab(tripId: String, viewModel: TriplyViewModel) {
    val bookings by viewModel.observeBookings(tripId).collectAsState(initial = emptyList())
    var type by remember { mutableStateOf("ACCOMMODATION") }
    var name by remember { mutableStateOf("") }
    var priceDigits by remember { mutableStateOf("") }
    var bookingUrl by remember { mutableStateOf("") }

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text(stringResource(R.string.bookings_disclaimer), style = MaterialTheme.typography.labelSmall, color = TriplyColors.WarmStone)
        }
        item {
            Surface(color = TriplyColors.SlateSurface, shape = RoundedCornerShape(10.dp), border = BorderStroke(1.dp, TriplyColors.HairlineBorder)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = type == "ACCOMMODATION", onClick = { type = "ACCOMMODATION" }, label = { Text(stringResource(R.string.bookings_type_accommodation)) })
                        FilterChip(selected = type == "TRANSPORTATION", onClick = { type = "TRANSPORTATION" }, label = { Text(stringResource(R.string.bookings_type_transport)) })
                    }
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name / Carrier") }, modifier = Modifier.fillMaxWidth())
                    IdrAmountTextField(rawDigits = priceDigits, onRawDigitsChange = { priceDigits = it }, label = stringResource(R.string.budget_expense_amount))
                    OutlinedTextField(value = bookingUrl, onValueChange = { bookingUrl = it }, label = { Text("External Link (optional)") }, modifier = Modifier.fillMaxWidth())
                    Button(
                        onClick = {
                            if (name.isBlank()) return@Button
                            viewModel.addBooking(tripId, type, name, "", "", "", IdrFormatter.parseToLong(priceDigits), bookingUrl, "")
                            name = ""
                            priceDigits = ""
                            bookingUrl = ""
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = TriplyColors.OchreAccent, contentColor = TriplyColors.ObsidianCanvas)
                    ) { Text(stringResource(R.string.bookings_add)) }
                }
            }
        }
        items(bookings, key = { it.id }) { b ->
            Surface(color = TriplyColors.ElevatedSurface, shape = RoundedCornerShape(10.dp)) {
                Column(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(b.name, style = MaterialTheme.typography.titleMedium, color = TriplyColors.IvoryInk)
                        EditorialBadge(
                            text = stringResource(if (b.sourceType == "PROVIDER_RESULT") R.string.bookings_badge_provider else R.string.bookings_badge_manual)
                        )
                    }
                    if (b.priceIdr > 0L) {
                        Text(IdrFormatter.format(b.priceIdr), style = MaterialTheme.typography.labelLarge, color = TriplyColors.OchreAccent)
                        if (!b.syncedToBudget) {
                            EditorialSecondaryButton(stringResource(R.string.bookings_sync_budget), { viewModel.syncBookingToBudget(b) })
                        } else {
                            EditorialBadge(stringResource(R.string.bookings_synced_budget), tint = TriplyColors.SageSuccess)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun WeatherTab(
    trip: TripEntity,
    destinations: List<com.triply.app.data.local.TripDestinationEntity>,
    viewModel: TriplyViewModel
) {
    val forecast by viewModel.weatherForecast.collectAsState()
    val error by viewModel.weatherError.collectAsState()
    val loading by viewModel.isLoadingWeather.collectAsState()

    LaunchedEffect(trip.id, destinations.size) {
        viewModel.loadWeatherForTrip(trip, destinations)
    }

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        if (loading) {
            item { Text(stringResource(R.string.status_loading), color = TriplyColors.WarmStone) }
        }
        if (error != null) {
            item { Text(stringResource(R.string.weather_unavailable), color = TriplyColors.CrimsonAlert) }
        }
        forecast?.let { f ->
            item {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("${stringResource(R.string.weather_title)}: ${f.destinationName}", style = MaterialTheme.typography.titleLarge, color = TriplyColors.IvoryInk)
                    Text("${stringResource(R.string.weather_last_updated, f.updatedAtIso)} · ${f.sourceAttribution}", style = MaterialTheme.typography.labelSmall, color = TriplyColors.MutedAsh)
                }
            }
            if (f.outOfRangeNotice) {
                item {
                    Surface(color = TriplyColors.OchreSoft, shape = RoundedCornerShape(10.dp)) {
                        Text(stringResource(R.string.weather_out_of_range), color = TriplyColors.IvoryInk, modifier = Modifier.padding(14.dp))
                    }
                }
            }
            items(f.days) { day ->
                Surface(color = TriplyColors.SlateSurface, shape = RoundedCornerShape(10.dp), border = BorderStroke(1.dp, TriplyColors.HairlineBorder)) {
                    Column(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(day.dateIso, style = MaterialTheme.typography.titleMedium, color = TriplyColors.IvoryInk)
                            Text("${day.tempMinC.toInt()}° / ${day.tempMaxC.toInt()}°C", style = MaterialTheme.typography.titleMedium, color = TriplyColors.OchreAccent)
                        }
                        Text("${day.conditionLabel} · ${stringResource(R.string.weather_precip, day.precipitationProbPercent)} (${day.precipitationMm} mm)", style = MaterialTheme.typography.bodyMedium, color = TriplyColors.WarmStone)
                        day.severeAdvisory?.let { adv ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Outlined.WarningAmber, contentDescription = null, tint = TriplyColors.CrimsonAlert)
                                Spacer(Modifier.width(6.dp))
                                Text(adv, style = MaterialTheme.typography.bodyMedium, color = TriplyColors.CrimsonAlert)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EmergencyTab(
    destinations: List<com.triply.app.data.local.TripDestinationEntity>,
    viewModel: TriplyViewModel
) {
    val context = LocalContext.current
    val contacts by viewModel.emergencyContacts.collectAsState()
    val nearby by viewModel.nearbyEmergencyPlaces.collectAsState()
    val official = contacts.filter { it.category == "OFFICIAL" }
    val personal = contacts.filter { it.category == "PERSONAL" }
    var pName by remember { mutableStateOf("") }
    var pPhone by remember { mutableStateOf("") }

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text(stringResource(R.string.emergency_call_disclaimer), style = MaterialTheme.typography.labelSmall, color = TriplyColors.WarmStone) }
        item { Text(stringResource(R.string.emergency_official_title), style = MaterialTheme.typography.titleMedium, color = TriplyColors.CrimsonAlert) }
        items(official, key = { it.id }) { c ->
            Surface(
                color = TriplyColors.SlateSurface,
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, TriplyColors.CrimsonAlert.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth().clickable {
                    context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${c.phoneNumber}")))
                }
            ) {
                Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(c.name, style = MaterialTheme.typography.titleMedium, color = TriplyColors.IvoryInk)
                        Text(c.notes, style = MaterialTheme.typography.labelSmall, color = TriplyColors.WarmStone)
                    }
                    Text(c.phoneNumber, style = MaterialTheme.typography.titleLarge, color = TriplyColors.CrimsonAlert)
                    Spacer(Modifier.width(8.dp))
                    Icon(Icons.Outlined.Call, contentDescription = null, tint = TriplyColors.CrimsonAlert)
                }
            }
        }
        item { Text(stringResource(R.string.emergency_personal_title), style = MaterialTheme.typography.titleMedium, color = TriplyColors.IvoryInk) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = pName, onValueChange = { pName = it }, label = { Text("Name") }, modifier = Modifier.weight(1f))
                OutlinedTextField(value = pPhone, onValueChange = { pPhone = it }, label = { Text("Phone") }, modifier = Modifier.weight(1f))
                Button(onClick = {
                    if (pName.isNotBlank() && pPhone.isNotBlank()) {
                        viewModel.addPersonalEmergencyContact(pName, pPhone, "")
                        pName = ""; pPhone = ""
                    }
                }) { Text(stringResource(R.string.action_add)) }
            }
        }
        items(personal, key = { it.id }) { c ->
            Surface(color = TriplyColors.ElevatedSurface, shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth().clickable {
                context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${c.phoneNumber}")))
            }) {
                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("${c.name} · ${c.phoneNumber}", modifier = Modifier.weight(1f), color = TriplyColors.IvoryInk)
                    IconButton(onClick = { viewModel.deleteEmergencyContact(c) }) {
                        Icon(Icons.Outlined.DeleteOutline, contentDescription = null, tint = TriplyColors.CrimsonAlert)
                    }
                }
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(stringResource(R.string.emergency_nearby_title), style = MaterialTheme.typography.titleMedium, color = TriplyColors.IvoryInk)
                Text(stringResource(R.string.emergency_location_rationale), style = MaterialTheme.typography.labelSmall, color = TriplyColors.MutedAsh)
                EditorialSecondaryButton(stringResource(R.string.emergency_find_nearby), {
                    val dest = destinations.firstOrNull()
                    viewModel.searchNearbyEmergencyFacilities(dest?.latitude ?: -7.7956, dest?.longitude ?: 110.3695)
                })
            }
        }
        items(nearby, key = { it.id }) { place ->
            Surface(color = TriplyColors.SlateSurface, shape = RoundedCornerShape(8.dp)) {
                Column(modifier = Modifier.fillMaxWidth().padding(12.dp)) {
                    Text(place.name, style = MaterialTheme.typography.titleMedium, color = TriplyColors.IvoryInk)
                    Text("${place.category} · ${place.address}", style = MaterialTheme.typography.labelSmall, color = TriplyColors.WarmStone)
                }
            }
        }
    }
}

@Composable
private fun JournalTab(tripId: String, viewModel: TriplyViewModel) {
    val entries by viewModel.observeJournalEntries(tripId).collectAsState(initial = emptyList())
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    var photoUri by remember { mutableStateOf<String?>(null) }

    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        photoUri = uri?.toString()
    }

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Surface(color = TriplyColors.SlateSurface, shape = RoundedCornerShape(10.dp), border = BorderStroke(1.dp, TriplyColors.HairlineBorder)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(stringResource(R.string.journal_add_entry), style = MaterialTheme.typography.titleMedium, color = TriplyColors.IvoryInk)
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text(stringResource(R.string.journal_entry_title)) }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = body, onValueChange = { body = it }, label = { Text(stringResource(R.string.journal_entry_body)) }, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        EditorialSecondaryButton(stringResource(R.string.journal_attach_photo), {
                            photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        })
                        Button(
                            onClick = {
                                if (title.isBlank()) return@Button
                                viewModel.addJournalEntry(tripId, 0, title, body, "", photoUri)
                                title = ""; body = ""; photoUri = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = TriplyColors.OchreAccent, contentColor = TriplyColors.ObsidianCanvas)
                        ) { Text(stringResource(R.string.action_save)) }
                    }
                }
            }
        }
        items(entries, key = { it.id }) { entry ->
            Surface(color = TriplyColors.SlateSurface, shape = RoundedCornerShape(10.dp), border = BorderStroke(1.dp, TriplyColors.HairlineBorder)) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    if (!entry.photoUri.isNullOrBlank()) {
                        EditorialDestinationImage(imageUrl = entry.photoUri, contentDescription = entry.title, height = 160.dp)
                    }
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(entry.title, style = MaterialTheme.typography.titleMedium, color = TriplyColors.IvoryInk)
                        Text(entry.body, style = MaterialTheme.typography.bodyMedium, color = TriplyColors.WarmStone)
                    }
                }
            }
        }
    }
}

@Composable
private fun GroupTab(tripId: String, viewModel: TriplyViewModel) {
    val context = LocalContext.current
    val members by viewModel.observeGroupMembers(tripId).collectAsState(initial = emptyList())
    val importPreview by viewModel.importPreview.collectAsState()
    var memberName by remember { mutableStateOf("") }
    var memberRole by remember { mutableStateOf("") }
    var statusMessage by remember { mutableStateOf<String?>(null) }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) {
            context.contentResolver.openOutputStream(uri)?.let { os ->
                viewModel.exportTripZip(tripId, os) { res ->
                    statusMessage = if (res.isSuccess) "Trip ZIP exported successfully." else res.exceptionOrNull()?.message
                }
            }
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            context.contentResolver.openInputStream(uri)?.let { ins ->
                viewModel.inspectImportZip(ins) { err -> statusMessage = err }
            }
        }
    }

    importPreview?.let { preview ->
        AlertDialog(
            onDismissRequest = { viewModel.dismissImportPreview() },
            title = { Text(stringResource(R.string.group_import_preview_title)) },
            text = {
                Text(
                    "Trip: ${preview.payload.trip.title}
" +
                        "Destinations: ${preview.payload.destinations.size}
" +
                        "Expenses: ${preview.payload.expenses.size}
" +
                        "Photos: ${preview.photoEntryCount}
" +
                        if (preview.hasTripIdConflict) "Note: Existing trip ID detected; will import as a safe copy." else ""
                )
            },
            confirmButton = {
                Button(onClick = { viewModel.confirmImportPreview() }) {
                    Text(stringResource(R.string.group_import_confirm))
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.dismissImportPreview() }) {
                    Text(stringResource(R.string.action_cancel))
                }
            }
        )
    }

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Surface(color = TriplyColors.SlateSurface, shape = RoundedCornerShape(10.dp), border = BorderStroke(1.dp, TriplyColors.HairlineBorder)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(stringResource(R.string.group_share_title), style = MaterialTheme.typography.titleMedium, color = TriplyColors.IvoryInk)
                    Text(stringResource(R.string.group_share_desc), style = MaterialTheme.typography.bodyMedium, color = TriplyColors.WarmStone)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = { exportLauncher.launch("triply-trip-$tripId.zip") },
                            colors = ButtonDefaults.buttonColors(containerColor = TriplyColors.OchreAccent, contentColor = TriplyColors.ObsidianCanvas)
                        ) { Text(stringResource(R.string.group_export_zip)) }
                        EditorialSecondaryButton(stringResource(R.string.group_import_zip), { importLauncher.launch(arrayOf("application/zip")) })
                    }
                    statusMessage?.let { Text(it, style = MaterialTheme.typography.labelSmall, color = TriplyColors.OchreAccent) }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = memberName, onValueChange = { memberName = it }, label = { Text(stringResource(R.string.group_member_name)) }, modifier = Modifier.weight(1f))
                OutlinedTextField(value = memberRole, onValueChange = { memberRole = it }, label = { Text(stringResource(R.string.group_member_role)) }, modifier = Modifier.weight(1f))
                Button(onClick = {
                    if (memberName.isNotBlank()) {
                        viewModel.addGroupMember(tripId, memberName, memberRole)
                        memberName = ""; memberRole = ""
                    }
                }) { Text(stringResource(R.string.action_add)) }
            }
        }
        items(members, key = { it.id }) { m ->
            Surface(color = TriplyColors.ElevatedSurface, shape = RoundedCornerShape(8.dp)) {
                Row(modifier = Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(m.name, style = MaterialTheme.typography.titleMedium, color = TriplyColors.IvoryInk)
                        if (m.roleLabel.isNotBlank()) Text(m.roleLabel, style = MaterialTheme.typography.labelSmall, color = TriplyColors.WarmStone)
                    }
                    IconButton(onClick = { viewModel.deleteGroupMember(m) }) {
                        Icon(Icons.Outlined.DeleteOutline, contentDescription = null, tint = TriplyColors.CrimsonAlert)
                    }
                }
            }
        }
    }
}

@Composable
private fun WhatIfTab(trip: TripEntity, viewModel: TriplyViewModel) {
    val scenarios by viewModel.observeWhatIfScenarios(trip.id).collectAsState(initial = emptyList())
    var scTitle by remember { mutableStateOf("") }
    var scTransport by remember { mutableStateOf("Train") }
    var scBudgetDigits by remember { mutableStateOf(trip.totalBudgetIdr.toString()) }

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text(stringResource(R.string.whatif_subtitle), style = MaterialTheme.typography.bodyMedium, color = TriplyColors.WarmStone) }
        item {
            Surface(color = TriplyColors.SlateSurface, shape = RoundedCornerShape(10.dp), border = BorderStroke(1.dp, TriplyColors.HairlineBorder)) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(value = scTitle, onValueChange = { scTitle = it }, label = { Text("Scenario Name") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = scTransport, onValueChange = { scTransport = it }, label = { Text(stringResource(R.string.builder_step_transport)) }, modifier = Modifier.fillMaxWidth())
                    IdrAmountTextField(rawDigits = scBudgetDigits, onRawDigitsChange = { scBudgetDigits = it }, label = stringResource(R.string.builder_budget_total_label))
                    Button(
                        onClick = {
                            if (scTitle.isBlank()) return@Button
                            viewModel.addWhatIfScenario(
                                tripId = trip.id,
                                title = scTitle,
                                altStartEpochDay = trip.startDateEpochDay,
                                altEndEpochDay = trip.endDateEpochDay,
                                altTransportMode = scTransport,
                                altBudgetIdr = IdrFormatter.parseToLong(scBudgetDigits),
                                altDestinationSummary = trip.title,
                                notes = ""
                            )
                            scTitle = ""
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = TriplyColors.OchreAccent, contentColor = TriplyColors.ObsidianCanvas)
                    ) { Text(stringResource(R.string.whatif_new_scenario)) }
                }
            }
        }
        items(scenarios, key = { it.id }) { sc ->
            val delta = WhatIfEngine.compare(trip, sc)
            Surface(color = TriplyColors.ElevatedSurface, shape = RoundedCornerShape(10.dp), border = BorderStroke(1.dp, TriplyColors.HairlineBorder)) {
                Column(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(sc.title, style = MaterialTheme.typography.titleMedium, color = TriplyColors.IvoryInk)
                        EditorialBadge("Estimate · ${sc.estimateSource}")
                    }
                    EditorialKeyValueRow(stringResource(R.string.whatif_original_label), "${trip.transportMode} · ${IdrFormatter.format(trip.totalBudgetIdr)}")
                    EditorialKeyValueRow(stringResource(R.string.whatif_alternative_label), "${sc.altTransportMode} · ${IdrFormatter.format(sc.altBudgetIdr)}", TriplyColors.OchreAccent)
                    Text(
                        text = "Budget delta: ${if (delta.budgetDeltaIdr >= 0) "+" else ""}${IdrFormatter.format(delta.budgetDeltaIdr)}",
                        style = MaterialTheme.typography.labelLarge,
                        color = if (delta.budgetDeltaIdr <= 0) TriplyColors.SageSuccess else TriplyColors.AmberWarning
                    )
                    Button(
                        onClick = { viewModel.applyWhatIfScenario(trip, sc) },
                        colors = ButtonDefaults.buttonColors(containerColor = TriplyColors.OchreAccent, contentColor = TriplyColors.ObsidianCanvas)
                    ) { Text(stringResource(R.string.whatif_apply_confirm)) }
                }
            }
        }
    }
}
