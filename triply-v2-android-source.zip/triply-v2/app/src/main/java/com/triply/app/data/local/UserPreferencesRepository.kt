package com.triply.app.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "triply_v2_prefs")

data class UserPreferences(
    val languageTag: String = "en",
    val currencyCode: String = "IDR",
    val mapStyleId: String = "liberty",
    val onlineMapsDefault: Boolean = true,
    val allowMobileDataDownloads: Boolean = false,
    // Developer-only optional custom endpoint overrides (no raw secrets stored here)
    val customMapStyleUrl: String = "",
    val customRoutingBaseUrl: String = ""
)

class UserPreferencesRepository(private val context: Context) {

    private object Keys {
        val LANGUAGE = stringPreferencesKey("language_tag")
        val CURRENCY = stringPreferencesKey("currency_code")
        val MAP_STYLE = stringPreferencesKey("map_style_id")
        val ONLINE_MAPS = booleanPreferencesKey("online_maps_default")
        val MOBILE_DATA = booleanPreferencesKey("allow_mobile_data_downloads")
        val CUSTOM_MAP_STYLE_URL = stringPreferencesKey("dev_custom_map_style_url")
        val CUSTOM_ROUTING_URL = stringPreferencesKey("dev_custom_routing_url")
    }

    val preferencesFlow: Flow<UserPreferences> = context.dataStore.data.map { prefs ->
        UserPreferences(
            languageTag = prefs[Keys.LANGUAGE] ?: "en",
            currencyCode = prefs[Keys.CURRENCY] ?: "IDR",
            mapStyleId = prefs[Keys.MAP_STYLE] ?: "liberty",
            onlineMapsDefault = prefs[Keys.ONLINE_MAPS] ?: true,
            allowMobileDataDownloads = prefs[Keys.MOBILE_DATA] ?: false,
            customMapStyleUrl = prefs[Keys.CUSTOM_MAP_STYLE_URL] ?: "",
            customRoutingBaseUrl = prefs[Keys.CUSTOM_ROUTING_URL] ?: ""
        )
    }

    suspend fun setLanguage(tag: String) {
        context.dataStore.edit { it[Keys.LANGUAGE] = tag }
    }

    suspend fun setCurrency(code: String) {
        context.dataStore.edit { it[Keys.CURRENCY] = code }
    }

    suspend fun setMapStyle(styleId: String) {
        context.dataStore.edit { it[Keys.MAP_STYLE] = styleId }
    }

    suspend fun setOnlineMapsDefault(enabled: Boolean) {
        context.dataStore.edit { it[Keys.ONLINE_MAPS] = enabled }
    }

    suspend fun setAllowMobileDataDownloads(enabled: Boolean) {
        context.dataStore.edit { it[Keys.MOBILE_DATA] = enabled }
    }

    suspend fun setDeveloperOverrides(mapStyleUrl: String, routingBaseUrl: String) {
        context.dataStore.edit {
            it[Keys.CUSTOM_MAP_STYLE_URL] = mapStyleUrl.trim()
            it[Keys.CUSTOM_ROUTING_URL] = routingBaseUrl.trim()
        }
    }
}
