package com.triply.app

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.viewmodel.compose.viewModel
import com.triply.app.core.designsystem.TriplyTheme
import com.triply.app.ui.TriplyViewModel
import com.triply.app.ui.navigation.TriplyRootApp

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val appContainer = (application as TriplyApplication).container
        setContent {
            TriplyTheme {
                val vm: TriplyViewModel = viewModel(factory = TriplyViewModel.Factory(appContainer))
                TriplyRootApp(viewModel = vm)
            }
        }
    }
}
