package com.triply.app.core.designsystem

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CloudOff
import androidx.compose.material.icons.outlined.Landscape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.SubcomposeAsyncImage
import com.triply.app.R
import com.triply.app.core.util.IdrVisualTransformation

@Composable
fun EditorialSectionHeader(
    kicker: String? = null,
    title: String,
    subtitle: String? = null,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        if (!kicker.isNullOrBlank()) {
            Text(
                text = kicker.uppercase(),
                style = MaterialTheme.typography.labelSmall,
                color = TriplyColors.OchreAccent
            )
            Spacer(modifier = Modifier.height(4.dp))
        }
        Text(
            text = title,
            style = MaterialTheme.typography.headlineMedium,
            color = TriplyColors.IvoryInk
        )
        if (!subtitle.isNullOrBlank()) {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = TriplyColors.WarmStone
            )
        }
    }
}

@Composable
fun OfflineStatusBanner(
    isOnline: Boolean,
    modifier: Modifier = Modifier
) {
    if (isOnline) return
    Surface(
        color = TriplyColors.OchreSoft,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, TriplyColors.OchreAccent.copy(alpha = 0.45f)),
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Outlined.CloudOff,
                contentDescription = null,
                tint = TriplyColors.OchreAccent,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = stringResource(R.string.status_offline_banner),
                style = MaterialTheme.typography.bodyMedium,
                color = TriplyColors.IvoryInk
            )
        }
    }
}

@Composable
fun EditorialDestinationImage(
    imageUrl: String?,
    contentDescription: String,
    modifier: Modifier = Modifier,
    height: Dp = 180.dp
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(height)
            .clip(RoundedCornerShape(12.dp))
            .background(TriplyColors.ElevatedSurface)
    ) {
        if (!imageUrl.isNullOrBlank()) {
            SubcomposeAsyncImage(
                model = imageUrl,
                contentDescription = contentDescription,
                contentScale = ContentScale.Crop,
                modifier = Modifier.matchParentSize(),
                loading = { EditorialImagePlaceholder() },
                error = { EditorialImagePlaceholder() }
            )
        } else {
            EditorialImagePlaceholder()
        }
        Box(
            modifier = Modifier
                .matchParentSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color.Transparent, TriplyColors.ObsidianCanvas.copy(alpha = 0.72f)),
                        startY = 120f
                    )
                )
        )
    }
}

@Composable
private fun EditorialImagePlaceholder() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(180.dp)
            .background(TriplyColors.ElevatedSurface),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Outlined.Landscape,
            contentDescription = null,
            tint = TriplyColors.MutedAsh,
            modifier = Modifier.size(36.dp)
        )
    }
}

@Composable
fun IdrAmountTextField(
    rawDigits: String,
    onRawDigitsChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    supportingText: String? = null
) {
    OutlinedTextField(
        value = rawDigits,
        onValueChange = { incoming ->
            val digitsOnly = incoming.filter { it.isDigit() }.take(13)
            onRawDigitsChange(digitsOnly)
        },
        label = { Text(label) },
        supportingText = supportingText?.let { { Text(it, color = TriplyColors.WarmStone) } },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        visualTransformation = IdrVisualTransformation(),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = TriplyColors.OchreAccent,
            unfocusedBorderColor = TriplyColors.HairlineBorder,
            focusedLabelColor = TriplyColors.OchreAccent,
            unfocusedLabelColor = TriplyColors.WarmStone,
            cursorColor = TriplyColors.OchreAccent,
            focusedTextColor = TriplyColors.IvoryInk,
            unfocusedTextColor = TriplyColors.IvoryInk
        ),
        modifier = modifier.fillMaxWidth()
    )
}

@Composable
fun EditorialProgressBar(
    progress: Float,
    color: Color = TriplyColors.OchreAccent,
    modifier: Modifier = Modifier
) {
    val animated by animateFloatAsState(
        targetValue = progress.coerceIn(0f, 1f),
        animationSpec = tween(durationMillis = 350),
        label = "editorial_progress"
    )
    LinearProgressIndicator(
        progress = { animated },
        color = color,
        trackColor = TriplyColors.HairlineBorder,
        modifier = modifier
            .fillMaxWidth()
            .height(6.dp)
            .clip(RoundedCornerShape(3.dp))
    )
}

@Composable
fun EditorialEmptyState(
    icon: ImageVector,
    title: String,
    body: String,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, TriplyColors.HairlineBorder, RoundedCornerShape(12.dp))
            .background(TriplyColors.SlateSurface, RoundedCornerShape(12.dp))
            .padding(24.dp),
        horizontalAlignment = Alignment.Start
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = TriplyColors.OchreAccent,
            modifier = Modifier.size(28.dp)
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge,
            color = TriplyColors.IvoryInk
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = body,
            style = MaterialTheme.typography.bodyMedium,
            color = TriplyColors.WarmStone
        )
        if (!actionLabel.isNullOrBlank() && onAction != null) {
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = onAction,
                colors = ButtonDefaults.buttonColors(
                    containerColor = TriplyColors.OchreAccent,
                    contentColor = TriplyColors.ObsidianCanvas
                ),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(actionLabel, style = MaterialTheme.typography.labelLarge)
            }
        }
    }
}

@Composable
fun EditorialBadge(
    text: String,
    tint: Color = TriplyColors.OchreAccent,
    modifier: Modifier = Modifier
) {
    Surface(
        color = tint.copy(alpha = 0.14f),
        shape = RoundedCornerShape(6.dp),
        border = BorderStroke(1.dp, tint.copy(alpha = 0.35f)),
        modifier = modifier
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = tint,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun EditorialKeyValueRow(
    label: String,
    value: String,
    valueColor: Color = TriplyColors.IvoryInk,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(label, style = MaterialTheme.typography.bodyMedium, color = TriplyColors.WarmStone)
            Spacer(modifier = Modifier.width(12.dp))
            Text(value, style = MaterialTheme.typography.titleMedium, color = valueColor)
        }
        HorizontalDivider(color = TriplyColors.HairlineBorder, thickness = 0.5.dp)
    }
}

@Composable
fun EditorialSecondaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    OutlinedButton(
        onClick = onClick,
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, TriplyColors.HairlineBorder),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = TriplyColors.IvoryInk),
        modifier = modifier
    ) {
        Text(text, style = MaterialTheme.typography.labelLarge)
    }
}
