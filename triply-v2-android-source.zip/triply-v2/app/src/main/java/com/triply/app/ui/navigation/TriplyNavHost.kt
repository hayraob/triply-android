package com.triply.app.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.AddCircleOutline
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.Luggage
import androidx.compose.material.icons.outlined.PersonOutline
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.triply.app.R
import com.triply.app.core.designsystem.TriplyColors
import com.triply.app.ui.TriplyViewModel
import com.triply.app.ui.screens.BudgetOverviewScreen
import com.triply.app.ui.screens.DeveloperSettingsScreen
import com.triply.app.ui.screens.ExploreScreen
import com.triply.app.ui.screens.MapDiscoveryScreen
import com.triply.app.ui.screens.MyTripsScreen
import com.triply.app.ui.screens.OfflineMapManagerScreen
import com.triply.app.ui.screens.ProfileScreen
import com.triply.app.ui.screens.TripBuilderScreen
import com.triply.app.ui.screens.TripDetailScreen

sealed class TopDestination(val route: String, val labelRes: Int, val icon: ImageVector) {
    data object Explore : TopDestination("explore", R.string.nav_explore, Icons.Outlined.Explore)
    data object MyTrips : TopDestination("my_trips", R.string.nav_my_trips, Icons.Outlined.Luggage)
    data object Create : TopDestination("create_trip", R.string.nav_create, Icons.Outlined.AddCircleOutline)
    data object Budget : TopDestination("budget", R.string.nav_budget, Icons.Outlined.AccountBalanceWallet)
    data object Profile : TopDestination("profile", R.string.nav_profile, Icons.Outlined.PersonOutline)
}

object Routes {
    const val MAP_DISCOVERY = "map_discovery"
    const val OFFLINE_MAPS = "offline_maps"
    const val DEVELOPER_SETTINGS = "developer_settings"
    const val TRIP_DETAIL = "trip_detail/{tripId}"
    fun tripDetail(tripId: String) = "trip_detail/$tripId"
}

@Composable
fun TriplyRootApp(viewModel: TriplyViewModel) {
    val navController = rememberNavController()
    val topItems = listOf(
        TopDestination.Explore,
        TopDestination.MyTrips,
        TopDestination.Create,
        TopDestination.Budget,
        TopDestination.Profile
    )
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route
    val showBottomBar = topItems.any { it.route == currentRoute }

    Scaffold(
        containerColor = TriplyColors.ObsidianCanvas,
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(
                    containerColor = TriplyColors.SlateSurface,
                    contentColor = TriplyColors.IvoryInk
                ) {
                    topItems.forEach { dest ->
                        val selected = currentRoute == dest.route
                        val isCreate = dest == TopDestination.Create
                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                navController.navigate(dest.route) {
                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(dest.icon, contentDescription = stringResource(dest.labelRes)) },
                            label = { Text(stringResource(dest.labelRes), maxLines = 1) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = TriplyColors.ObsidianCanvas,
                                selectedTextColor = TriplyColors.OchreAccent,
                                indicatorColor = TriplyColors.OchreAccent,
                                unselectedIconColor = if (isCreate) TriplyColors.OchreAccent else TriplyColors.WarmStone,
                                unselectedTextColor = if (isCreate) TriplyColors.OchreAccent else TriplyColors.WarmStone
                            )
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = TopDestination.Explore.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(TopDestination.Explore.route) {
                ExploreScreen(
                    viewModel = viewModel,
                    onOpenMap = { navController.navigate(Routes.MAP_DISCOVERY) },
                    onStartTrip = { navController.navigate(TopDestination.Create.route) },
                    onOpenTrip = { navController.navigate(Routes.tripDetail(it)) }
                )
            }
            composable(TopDestination.MyTrips.route) {
                MyTripsScreen(
                    viewModel = viewModel,
                    onCreateTrip = { navController.navigate(TopDestination.Create.route) },
                    onOpenTrip = { navController.navigate(Routes.tripDetail(it)) }
                )
            }
            composable(TopDestination.Create.route) {
                TripBuilderScreen(
                    viewModel = viewModel,
                    onTripCreated = { tripId ->
                        navController.navigate(Routes.tripDetail(tripId)) {
                            popUpTo(TopDestination.Explore.route)
                        }
                    },
                    onBack = { navController.popBackStack() }
                )
            }
            composable(TopDestination.Budget.route) {
                BudgetOverviewScreen(
                    viewModel = viewModel,
                    onOpenTrip = { navController.navigate(Routes.tripDetail(it)) }
                )
            }
            composable(TopDestination.Profile.route) {
                ProfileScreen(
                    viewModel = viewModel,
                    onOpenOfflineMaps = { navController.navigate(Routes.OFFLINE_MAPS) },
                    onOpenDeveloperSettings = { navController.navigate(Routes.DEVELOPER_SETTINGS) }
                )
            }
            composable(Routes.MAP_DISCOVERY) {
                MapDiscoveryScreen(
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() },
                    onOpenOfflineRegions = { navController.navigate(Routes.OFFLINE_MAPS) }
                )
            }
            composable(Routes.OFFLINE_MAPS) {
                OfflineMapManagerScreen(
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() }
                )
            }
            composable(Routes.DEVELOPER_SETTINGS) {
                DeveloperSettingsScreen(
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() }
                )
            }
            composable(
                route = Routes.TRIP_DETAIL,
                arguments = listOf(navArgument("tripId") { type = NavType.StringType })
            ) { backStackEntry ->
                val tripId = backStackEntry.arguments?.getString("tripId").orEmpty()
                TripDetailScreen(
                    tripId = tripId,
                    viewModel = viewModel,
                    onBack = { navController.popBackStack() },
                    onOpenMap = { navController.navigate(Routes.MAP_DISCOVERY) }
                )
            }
        }
    }
}
