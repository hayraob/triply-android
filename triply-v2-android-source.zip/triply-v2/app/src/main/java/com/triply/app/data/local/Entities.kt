package com.triply.app.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Serializable
@Entity(tableName = "trips")
data class TripEntity(
    @PrimaryKey val id: String,
    val title: String,
    val startDateEpochDay: Long,
    val endDateEpochDay: Long,
    val travelStyle: String,
    val transportMode: String,
    val totalBudgetIdr: Long,
    val currencyCode: String = "IDR",
    val coverImageUrl: String? = null,
    val notes: String = "",
    val isDraft: Boolean = false,
    val createdAtMillis: Long = System.currentTimeMillis(),
    val updatedAtMillis: Long = System.currentTimeMillis()
)

@Serializable
@Entity(
    tableName = "trip_destinations",
    foreignKeys = [ForeignKey(entity = TripEntity::class, parentColumns = ["id"], childColumns = ["tripId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("tripId")]
)
data class TripDestinationEntity(
    @PrimaryKey val id: String,
    val tripId: String,
    val orderIndex: Int,
    val name: String,
    val region: String = "",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val imageUrl: String? = null,
    val providerAttribution: String = "",
    val notes: String = ""
)

@Serializable
@Entity(
    tableName = "itinerary_items",
    foreignKeys = [ForeignKey(entity = TripEntity::class, parentColumns = ["id"], childColumns = ["tripId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("tripId")]
)
data class ItineraryItemEntity(
    @PrimaryKey val id: String,
    val tripId: String,
    val dayIndex: Int,
    val title: String,
    val startTimeMinutes: Int,
    val locationName: String = "",
    val latitude: Double? = null,
    val longitude: Double? = null,
    val notes: String = "",
    val reminderEnabled: Boolean = false,
    val reminderScheduledConfirmed: Boolean = false,
    val reminderRequestCode: Int = 0
)

@Serializable
@Entity(
    tableName = "budget_categories",
    foreignKeys = [ForeignKey(entity = TripEntity::class, parentColumns = ["id"], childColumns = ["tripId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("tripId")]
)
data class BudgetCategoryEntity(
    @PrimaryKey val id: String,
    val tripId: String,
    val name: String,
    val allocatedIdr: Long
)

@Serializable
@Entity(
    tableName = "expenses",
    foreignKeys = [ForeignKey(entity = TripEntity::class, parentColumns = ["id"], childColumns = ["tripId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("tripId")]
)
data class ExpenseEntity(
    @PrimaryKey val id: String,
    val tripId: String,
    val categoryName: String,
    val title: String,
    val amountIdr: Long,
    val dateEpochDay: Long,
    val payerName: String = "",
    val notes: String = "",
    val sourceBookingId: String? = null
)

@Serializable
@Entity(
    tableName = "packing_items",
    foreignKeys = [ForeignKey(entity = TripEntity::class, parentColumns = ["id"], childColumns = ["tripId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("tripId")]
)
data class PackingItemEntity(
    @PrimaryKey val id: String,
    val tripId: String,
    val category: String,
    val name: String,
    val quantity: Int = 1,
    val isPacked: Boolean = false,
    val assignedTo: String = "",
    val notes: String = ""
)

@Serializable
@Entity(
    tableName = "bookings",
    foreignKeys = [ForeignKey(entity = TripEntity::class, parentColumns = ["id"], childColumns = ["tripId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("tripId")]
)
data class BookingEntity(
    @PrimaryKey val id: String,
    val tripId: String,
    val type: String, // ACCOMMODATION | TRANSPORTATION
    val name: String,
    val address: String = "",
    val contactInfo: String = "",
    val startDateTimeIso: String = "",
    val endDateTimeIso: String = "",
    val priceIdr: Long = 0L,
    val bookingUrl: String = "",
    val notes: String = "",
    val sourceType: String = "MANUAL_RECORD", // MANUAL_RECORD | PROVIDER_RESULT
    val providerName: String = "",
    val syncedToBudget: Boolean = false
)

@Serializable
@Entity(
    tableName = "journal_entries",
    foreignKeys = [ForeignKey(entity = TripEntity::class, parentColumns = ["id"], childColumns = ["tripId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("tripId")]
)
data class JournalEntryEntity(
    @PrimaryKey val id: String,
    val tripId: String,
    val dayIndex: Int,
    val dateEpochDay: Long,
    val title: String,
    val body: String,
    val locationName: String = "",
    val photoUri: String? = null,
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Serializable
@Entity(
    tableName = "group_members",
    foreignKeys = [ForeignKey(entity = TripEntity::class, parentColumns = ["id"], childColumns = ["tripId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("tripId")]
)
data class GroupMemberEntity(
    @PrimaryKey val id: String,
    val tripId: String,
    val name: String,
    val roleLabel: String = "",
    val contactNote: String = ""
)

@Serializable
@Entity(tableName = "emergency_contacts")
data class EmergencyContactEntity(
    @PrimaryKey val id: String,
    val name: String,
    val phoneNumber: String,
    val category: String, // OFFICIAL | PERSONAL
    val countryCode: String = "ID",
    val notes: String = ""
)

@Serializable
@Entity(tableName = "offline_map_regions")
data class OfflineMapRegionEntity(
    @PrimaryKey val id: String,
    val name: String,
    val minLat: Double,
    val maxLat: Double,
    val minLon: Double,
    val maxLon: Double,
    val minZoom: Double,
    val maxZoom: Double,
    val estimatedSizeMb: Int,
    val status: String, // DOWNLOADING | READY | FAILED
    val downloadedAtMillis: Long = System.currentTimeMillis()
)

@Serializable
@Entity(
    tableName = "what_if_scenarios",
    foreignKeys = [ForeignKey(entity = TripEntity::class, parentColumns = ["id"], childColumns = ["tripId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("tripId")]
)
data class WhatIfScenarioEntity(
    @PrimaryKey val id: String,
    val tripId: String,
    val title: String,
    val altStartDateEpochDay: Long,
    val altEndDateEpochDay: Long,
    val altTransportMode: String,
    val altBudgetIdr: Long,
    val altDestinationSummary: String,
    val estimatedRouteKm: Double? = null,
    val estimatedDurationMin: Int? = null,
    val estimateSource: String = "User estimate",
    val notes: String = "",
    val createdAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "cached_places")
data class CachedPlaceEntity(
    @PrimaryKey val queryKey: String,
    val jsonPayload: String,
    val cachedAtMillis: Long
)
