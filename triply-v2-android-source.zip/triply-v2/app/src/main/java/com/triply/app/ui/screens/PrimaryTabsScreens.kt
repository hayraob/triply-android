package com.triply.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.Luggage
import androidx.compose.material.icons.outlined.Map
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.triply.app.R
import com.triply.app.core.designsystem.EditorialBadge
import com.triply.app.core.designsystem.EditorialDestinationImage
import com.triply.app.core.designsystem.EditorialEmptyState
import com.triply.app.core.designsystem.EditorialProgressBar
import com.triply.app.core.designsystem.EditorialSectionHeader
import com.triply.app.core.designsystem.OfflineStatusBanner
import com.triply.app.core.designsystem.TriplyColors
import com.triply.app.core.util.DateUtils
import com.triply.app.core.util.IdrFormatter
import com.triply.app.data.local.TripEntity
import com.triply.app.domain.PoiCategory
import com.triply.app.ui.TriplyViewModel
import java.time.LocalDate

@Composable
fun ExploreScreen(
    viewModel: TriplyViewModel,
    onOpenMap: () -> Unit,
    onStartTrip: () -> Unit,
    onOpenTrip: (String) -> Unit
) {
    val isOnline by viewModel.isOnline.collectAsState()
    val featured by viewModel.featuredDestinations.collectAsState()
    val trips by viewModel.allTrips.collectAsState()

    val quickCategories = listOf(
        PoiCategory.BEACH to R.string.cat_beach,
        PoiCategory.MOUNTAIN to R.string.cat_mountain,
        PoiCategory.ATTRACTION to R.string.cat_attraction,
        PoiCategory.HOTEL to R.string.cat_hotel,
        PoiCategory.RESTAURANT to R.string.cat_restaurant,
        PoiCategory.CAFE to R.string.cat_cafe
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(TriplyColors.ObsidianCanvas),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 20.dp),
        verticalArrangement = Arrangement.spacedBy(22.dp)
    ) {
        item { OfflineStatusBanner(isOnline = isOnline) }

        item {
            EditorialSectionHeader(
                kicker = stringResource(R.string.explore_kicker),
                title = stringResource(R.string.explore_headline)
            )
        }

        // Search entry point directly to live Map & POI discovery
        item {
            Surface(
                color = TriplyColors.SlateSurface,
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, TriplyColors.HairlineBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onOpenMap)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Outlined.Search, contentDescription = null, tint = TriplyColors.OchreAccent)
                    Spacer(Modifier.width(12.dp))
                    Text(
                        text = stringResource(R.string.explore_search_hint),
                        style = MaterialTheme.typography.bodyLarge,
                        color = TriplyColors.WarmStone
                    )
                }
            }
        }

        // Category rail
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = stringResource(R.string.explore_categories_title),
                    style = MaterialTheme.typography.titleMedium,
                    color = TriplyColors.IvoryInk
                )
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(quickCategories) { (_, labelRes) ->
                        FilterChip(
                            selected = false,
                            onClick = onOpenMap,
                            label = { Text(stringResource(labelRes)) },
                            colors = FilterChipDefaults.filterChipColors(
                                containerColor = TriplyColors.SlateSurface,
                                labelColor = TriplyColors.IvoryInk
                            ),
                            border = BorderStroke(1.dp, TriplyColors.HairlineBorder)
                        )
                    }
                }
            }
        }

        // Editorial Destination Rail with Wikimedia real photography
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = stringResource(R.string.explore_featured_title),
                    style = MaterialTheme.typography.titleLarge,
                    color = TriplyColors.IvoryInk
                )
                Text(
                    text = stringResource(R.string.explore_featured_subtitle),
                    style = MaterialTheme.typography.labelSmall,
                    color = TriplyColors.MutedAsh
                )
                LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    items(featured) { dest ->
                        Box(
                            modifier = Modifier
                                .width(248.dp)
                                .clickable(onClick = onOpenMap)
                        ) {
                            EditorialDestinationImage(
                                imageUrl = dest.imageUrl,
                                contentDescription = dest.name,
                                height = 168.dp
                            )
                            Column(
                                modifier = Modifier
                                    .align(Alignment.BottomStart)
                                    .padding(14.dp)
                            ) {
                                Text(
                                    text = dest.name,
                                    style = MaterialTheme.typography.titleLarge,
                                    color = TriplyColors.IvoryInk
                                )
                                Text(
                                    text = dest.region,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TriplyColors.WarmStone
                                )
                            }
                        }
                    }
                }
            }
        }

        // Online Map Banner CTA
        item {
            Surface(
                color = TriplyColors.SlateSurface,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, TriplyColors.HairlineBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Map, contentDescription = null, tint = TriplyColors.OchreAccent)
                        Spacer(Modifier.width(10.dp))
                        Text(
                            text = stringResource(R.string.explore_map_cta_title),
                            style = MaterialTheme.typography.titleMedium,
                            color = TriplyColors.IvoryInk
                        )
                    }
                    Text(
                        text = stringResource(R.string.explore_map_cta_subtitle),
                        style = MaterialTheme.typography.bodyMedium,
                        color = TriplyColors.WarmStone
                    )
                    Button(
                        onClick = onOpenMap,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = TriplyColors.OchreAccent,
                            contentColor = TriplyColors.ObsidianCanvas
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(stringResource(R.string.action_open_map))
                    }
                }
            }
        }

        // Tasteful first-time empty state or quick jump to active trip
        item {
            if (trips.isEmpty()) {
                EditorialEmptyState(
                    icon = Icons.Outlined.Luggage,
                    title = stringResource(R.string.explore_empty_trips_title),
                    body = stringResource(R.string.explore_empty_trips_body),
                    actionLabel = stringResource(R.string.explore_start_trip),
                    onAction = onStartTrip
                )
            } else {
                val upcoming = trips.first()
                TripRowCard(trip = upcoming, onClick = { onOpenTrip(upcoming.id) })
            }
        }
    }
}

@Composable
fun MyTripsScreen(
    viewModel: TriplyViewModel,
    onCreateTrip: () -> Unit,
    onOpenTrip: (String) -> Unit
) {
    val trips by viewModel.allTrips.collectAsState()
    val isOnline by viewModel.isOnline.collectAsState()
    val today = LocalDate.now().toEpochDay()

    val drafts = trips.filter { it.isDraft }
    val active = trips.filter { !it.isDraft && today in it.startDateEpochDay..it.endDateEpochDay }
    val upcoming = trips.filter { !it.isDraft && it.startDateEpochDay > today }
    val completed = trips.filter { !it.isDraft && it.endDateEpochDay < today }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(TriplyColors.ObsidianCanvas),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item { OfflineStatusBanner(isOnline = isOnline) }
        item { EditorialSectionHeader(title = stringResource(R.string.trips_title)) }

        if (trips.isEmpty()) {
            item {
                EditorialEmptyState(
                    icon = Icons.Outlined.Luggage,
                    title = stringResource(R.string.trips_empty_title),
                    body = stringResource(R.string.trips_empty_body),
                    actionLabel = stringResource(R.string.explore_start_trip),
                    onAction = onCreateTrip
                )
            }
        } else {
            if (active.isNotEmpty()) {
                item { Text(stringResource(R.string.trips_section_active), style = MaterialTheme.typography.titleMedium, color = TriplyColors.OchreAccent) }
                items(active, key = { it.id }) { trip -> TripRowCard(trip) { onOpenTrip(trip.id) } }
            }
            if (upcoming.isNotEmpty()) {
                item { Text(stringResource(R.string.trips_section_upcoming), style = MaterialTheme.typography.titleMedium, color = TriplyColors.IvoryInk) }
                items(upcoming, key = { it.id }) { trip -> TripRowCard(trip) { onOpenTrip(trip.id) } }
            }
            if (drafts.isNotEmpty()) {
                item { Text(stringResource(R.string.trips_section_drafts), style = MaterialTheme.typography.titleMedium, color = TriplyColors.WarmStone) }
                items(drafts, key = { it.id }) { trip -> TripRowCard(trip) { onOpenTrip(trip.id) } }
            }
            if (completed.isNotEmpty()) {
                item { Text(stringResource(R.string.trips_section_completed), style = MaterialTheme.typography.titleMedium, color = TriplyColors.MutedAsh) }
                items(completed, key = { it.id }) { trip -> TripRowCard(trip) { onOpenTrip(trip.id) } }
            }
        }
    }
}

@Composable
private fun TripRowCard(trip: TripEntity, onClick: () -> Unit) {
    Surface(
        color = TriplyColors.SlateSurface,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, TriplyColors.HairlineBorder),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Column {
            EditorialDestinationImage(
                imageUrl = trip.coverImageUrl,
                contentDescription = trip.title,
                height = 136.dp
            )
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(trip.title, style = MaterialTheme.typography.titleLarge, color = TriplyColors.IvoryInk)
                    EditorialBadge(text = trip.travelStyle)
                }
                Text(
                    text = DateUtils.formatDateRange(trip.startDateEpochDay, trip.endDateEpochDay),
                    style = MaterialTheme.typography.bodyMedium,
                    color = TriplyColors.WarmStone
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = stringResource(R.string.trips_days_count, DateUtils.tripDurationDays(trip.startDateEpochDay, trip.endDateEpochDay)),
                        style = MaterialTheme.typography.labelLarge,
                        color = TriplyColors.MutedAsh
                    )
                    Text(
                        text = IdrFormatter.format(trip.totalBudgetIdr),
                        style = MaterialTheme.typography.labelLarge,
                        color = TriplyColors.OchreAccent
                    )
                }
            }
        }
    }
}

@Composable
fun BudgetOverviewScreen(
    viewModel: TriplyViewModel,
    onOpenTrip: (String) -> Unit
) {
    val trips by viewModel.allTrips.collectAsState()
    val allExpenses by viewModel.allExpenses.collectAsState()

    val totalPlanned = trips.sumOf { it.totalBudgetIdr }
    val totalSpent = allExpenses.sumOf { it.amountIdr }
    val remaining = totalPlanned - totalSpent
    val ratio = if (totalPlanned > 0L) (totalSpent.toFloat() / totalPlanned.toFloat()).coerceIn(0f, 1f) else 0f

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(TriplyColors.ObsidianCanvas),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item { EditorialSectionHeader(title = stringResource(R.string.budget_title)) }

        item {
            Surface(
                color = TriplyColors.SlateSurface,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, TriplyColors.HairlineBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(stringResource(R.string.budget_total_planned), style = MaterialTheme.typography.labelSmall, color = TriplyColors.MutedAsh)
                    Text(IdrFormatter.format(totalPlanned), style = MaterialTheme.typography.displaySmall, color = TriplyColors.IvoryInk)
                    EditorialProgressBar(
                        progress = ratio,
                        color = if (totalSpent > totalPlanned && totalPlanned > 0L) TriplyColors.CrimsonAlert else TriplyColors.OchreAccent
                    )
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(stringResource(R.string.budget_total_spent), style = MaterialTheme.typography.labelSmall, color = TriplyColors.WarmStone)
                            Text(IdrFormatter.format(totalSpent), style = MaterialTheme.typography.titleMedium, color = TriplyColors.IvoryInk)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(stringResource(R.string.budget_remaining), style = MaterialTheme.typography.labelSmall, color = TriplyColors.WarmStone)
                            Text(
                                IdrFormatter.format(remaining),
                                style = MaterialTheme.typography.titleMedium,
                                color = if (remaining < 0L) TriplyColors.CrimsonAlert else TriplyColors.SageSuccess
                            )
                        }
                    }
                }
            }
        }

        if (trips.isEmpty()) {
            item {
                EditorialEmptyState(
                    icon = Icons.Outlined.AccountBalanceWallet,
                    title = stringResource(R.string.trips_empty_title),
                    body = stringResource(R.string.budget_empty)
                )
            }
        } else {
            items(trips, key = { it.id }) { trip ->
                val tripSpent = allExpenses.filter { it.tripId == trip.id }.sumOf { it.amountIdr }
                val progress = if (trip.totalBudgetIdr > 0L) (tripSpent.toFloat() / trip.totalBudgetIdr.toFloat()) else 0f
                Surface(
                    color = TriplyColors.SlateSurface,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, TriplyColors.HairlineBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onOpenTrip(trip.id) }
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(trip.title, style = MaterialTheme.typography.titleMedium, color = TriplyColors.IvoryInk)
                            Text(IdrFormatter.format(tripSpent), style = MaterialTheme.typography.labelLarge, color = TriplyColors.OchreAccent)
                        }
                        EditorialProgressBar(
                            progress = progress,
                            color = when {
                                trip.totalBudgetIdr > 0L && tripSpent > trip.totalBudgetIdr -> TriplyColors.CrimsonAlert
                                trip.totalBudgetIdr > 0L && progress >= 0.8f -> TriplyColors.AmberWarning
                                else -> TriplyColors.SageSuccess
                            }
                        )
                        Text(
                            text = "${IdrFormatter.format(tripSpent)} / ${IdrFormatter.format(trip.totalBudgetIdr)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = TriplyColors.WarmStone
                        )
                    }
                }
            }
        }
    }
}
