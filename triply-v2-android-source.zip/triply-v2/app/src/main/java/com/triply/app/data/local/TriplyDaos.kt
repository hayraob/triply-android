package com.triply.app.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface TripDao {
    @Query("SELECT * FROM trips ORDER BY startDateEpochDay ASC")
    fun observeAllTrips(): Flow<List<TripEntity>>

    @Query("SELECT * FROM trips WHERE id = :tripId LIMIT 1")
    fun observeTrip(tripId: String): Flow<TripEntity?>

    @Query("SELECT * FROM trips WHERE id = :tripId LIMIT 1")
    suspend fun getTripById(tripId: String): TripEntity?

    @Query("SELECT * FROM trips")
    suspend fun getAllTripsOnce(): List<TripEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTrip(trip: TripEntity)

    @Delete
    suspend fun deleteTrip(trip: TripEntity)

    // Destinations
    @Query("SELECT * FROM trip_destinations WHERE tripId = :tripId ORDER BY orderIndex ASC")
    fun observeDestinations(tripId: String): Flow<List<TripDestinationEntity>>

    @Query("SELECT * FROM trip_destinations WHERE tripId = :tripId ORDER BY orderIndex ASC")
    suspend fun getDestinationsOnce(tripId: String): List<TripDestinationEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertDestinations(items: List<TripDestinationEntity>)

    @Query("DELETE FROM trip_destinations WHERE tripId = :tripId")
    suspend fun clearDestinations(tripId: String)

    // Itinerary
    @Query("SELECT * FROM itinerary_items WHERE tripId = :tripId ORDER BY dayIndex ASC, startTimeMinutes ASC")
    fun observeItinerary(tripId: String): Flow<List<ItineraryItemEntity>>

    @Query("SELECT * FROM itinerary_items WHERE tripId = :tripId ORDER BY dayIndex ASC, startTimeMinutes ASC")
    suspend fun getItineraryOnce(tripId: String): List<ItineraryItemEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertItineraryItem(item: ItineraryItemEntity)

    @Delete
    suspend fun deleteItineraryItem(item: ItineraryItemEntity)

    // Budget & Expenses
    @Query("SELECT * FROM budget_categories WHERE tripId = :tripId")
    fun observeBudgetCategories(tripId: String): Flow<List<BudgetCategoryEntity>>

    @Query("SELECT * FROM budget_categories WHERE tripId = :tripId")
    suspend fun getBudgetCategoriesOnce(tripId: String): List<BudgetCategoryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertBudgetCategories(items: List<BudgetCategoryEntity>)

    @Query("SELECT * FROM expenses ORDER BY dateEpochDay DESC")
    fun observeAllExpenses(): Flow<List<ExpenseEntity>>

    @Query("SELECT * FROM expenses WHERE tripId = :tripId ORDER BY dateEpochDay DESC")
    fun observeExpenses(tripId: String): Flow<List<ExpenseEntity>>

    @Query("SELECT * FROM expenses WHERE tripId = :tripId")
    suspend fun getExpensesOnce(tripId: String): List<ExpenseEntity>

    @Query("SELECT * FROM expenses WHERE sourceBookingId = :bookingId LIMIT 1")
    suspend fun getExpenseByBookingId(bookingId: String): ExpenseEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertExpense(expense: ExpenseEntity)

    @Delete
    suspend fun deleteExpense(expense: ExpenseEntity)

    // Packing
    @Query("SELECT * FROM packing_items WHERE tripId = :tripId ORDER BY category ASC, name ASC")
    fun observePackingItems(tripId: String): Flow<List<PackingItemEntity>>

    @Query("SELECT * FROM packing_items WHERE tripId = :tripId")
    suspend fun getPackingItemsOnce(tripId: String): List<PackingItemEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPackingItem(item: PackingItemEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPackingItems(items: List<PackingItemEntity>)

    @Delete
    suspend fun deletePackingItem(item: PackingItemEntity)

    // Bookings
    @Query("SELECT * FROM bookings WHERE tripId = :tripId ORDER BY startDateTimeIso ASC")
    fun observeBookings(tripId: String): Flow<List<BookingEntity>>

    @Query("SELECT * FROM bookings WHERE tripId = :tripId")
    suspend fun getBookingsOnce(tripId: String): List<BookingEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertBooking(booking: BookingEntity)

    @Update
    suspend fun updateBooking(booking: BookingEntity)

    @Delete
    suspend fun deleteBooking(booking: BookingEntity)

    // Journal
    @Query("SELECT * FROM journal_entries WHERE tripId = :tripId ORDER BY dayIndex ASC, createdAtMillis DESC")
    fun observeJournalEntries(tripId: String): Flow<List<JournalEntryEntity>>

    @Query("SELECT * FROM journal_entries WHERE tripId = :tripId")
    suspend fun getJournalEntriesOnce(tripId: String): List<JournalEntryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertJournalEntry(entry: JournalEntryEntity)

    @Delete
    suspend fun deleteJournalEntry(entry: JournalEntryEntity)

    // Group Members
    @Query("SELECT * FROM group_members WHERE tripId = :tripId ORDER BY name ASC")
    fun observeGroupMembers(tripId: String): Flow<List<GroupMemberEntity>>

    @Query("SELECT * FROM group_members WHERE tripId = :tripId")
    suspend fun getGroupMembersOnce(tripId: String): List<GroupMemberEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertGroupMember(member: GroupMemberEntity)

    @Delete
    suspend fun deleteGroupMember(member: GroupMemberEntity)

    // What If Scenarios
    @Query("SELECT * FROM what_if_scenarios WHERE tripId = :tripId ORDER BY createdAtMillis DESC")
    fun observeWhatIfScenarios(tripId: String): Flow<List<WhatIfScenarioEntity>>

    @Query("SELECT * FROM what_if_scenarios WHERE tripId = :tripId")
    suspend fun getWhatIfScenariosOnce(tripId: String): List<WhatIfScenarioEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertWhatIfScenario(scenario: WhatIfScenarioEntity)

    @Delete
    suspend fun deleteWhatIfScenario(scenario: WhatIfScenarioEntity)
}

@Dao
interface UtilityDao {
    @Query("SELECT * FROM emergency_contacts ORDER BY category ASC, name ASC")
    fun observeEmergencyContacts(): Flow<List<EmergencyContactEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertEmergencyContact(contact: EmergencyContactEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertEmergencyContacts(contacts: List<EmergencyContactEntity>)

    @Delete
    suspend fun deleteEmergencyContact(contact: EmergencyContactEntity)

    @Query("SELECT * FROM offline_map_regions ORDER BY downloadedAtMillis DESC")
    fun observeOfflineMapRegions(): Flow<List<OfflineMapRegionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertOfflineMapRegion(region: OfflineMapRegionEntity)

    @Delete
    suspend fun deleteOfflineMapRegion(region: OfflineMapRegionEntity)

    @Query("SELECT * FROM cached_places WHERE queryKey = :key LIMIT 1")
    suspend fun getCachedPlace(key: String): CachedPlaceEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCachedPlace(entry: CachedPlaceEntity)

    @Query("DELETE FROM cached_places WHERE cachedAtMillis < :cutoffMillis")
    suspend fun purgeOldPlaceCache(cutoffMillis: Long)
}
