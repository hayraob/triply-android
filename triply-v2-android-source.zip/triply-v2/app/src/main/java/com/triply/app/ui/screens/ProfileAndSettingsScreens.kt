package com.triply.app.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.triply.app.BuildConfig
import com.triply.app.R
import com.triply.app.core.designsystem.EditorialKeyValueRow
import com.triply.app.core.designsystem.EditorialSecondaryButton
import com.triply.app.core.designsystem.EditorialSectionHeader
import com.triply.app.core.designsystem.TriplyColors
import com.triply.app.core.util.LocaleManager
import com.triply.app.ui.TriplyViewModel

object DeveloperCredits {
    const val AUTHOR_PRIMARY = "Haydar"
    const val AUTHOR_HANDLE = "silent.dt"
    const val URL_INSTAGRAM = "https://www.instagram.com/sailent.dt?dmpr=djVpOWFoZW42bWpj"
    const val URL_TIKTOK = "https://www.tiktok.com/@sailent.dt?_r=1&_t=ZS-9BfFb7apCx4"
    const val URL_DISCORD = "https://discord.gg/sfTRrgQq"
    const val URL_WHATSAPP = "https://wa.me/6287790421211"
}

@Composable
fun ProfileScreen(
    viewModel: TriplyViewModel,
    onOpenOfflineMaps: () -> Unit,
    onOpenDeveloperSettings: () -> Unit
) {
    val context = LocalContext.current
    val prefs by viewModel.preferences.collectAsState()

    fun openExternalUrl(url: String) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        context.startActivity(intent)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(TriplyColors.ObsidianCanvas),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item {
            EditorialSectionHeader(
                kicker = "TRIPLY V2 · ${BuildConfig.VERSION_NAME}",
                title = stringResource(R.string.profile_title)
            )
        }

        // Language selector (EN / ID)
        item {
            Surface(color = TriplyColors.SlateSurface, shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, TriplyColors.HairlineBorder)) {
                Column(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(stringResource(R.string.settings_language), style = MaterialTheme.typography.titleMedium, color = TriplyColors.IvoryInk)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        FilterChip(
                            selected = prefs.languageTag == LocaleManager.LANG_ENGLISH,
                            onClick = { viewModel.setLanguage(LocaleManager.LANG_ENGLISH) },
                            label = { Text("English") },
                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = TriplyColors.OchreAccent, selectedLabelColor = TriplyColors.ObsidianCanvas)
                        )
                        FilterChip(
                            selected = prefs.languageTag == LocaleManager.LANG_INDONESIAN,
                            onClick = { viewModel.setLanguage(LocaleManager.LANG_INDONESIAN) },
                            label = { Text("Bahasa Indonesia") },
                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = TriplyColors.OchreAccent, selectedLabelColor = TriplyColors.ObsidianCanvas)
                        )
                    }
                }
            }
        }

        // Map Appearance & Online Preferences
        item {
            Surface(color = TriplyColors.SlateSurface, shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, TriplyColors.HairlineBorder)) {
                Column(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(stringResource(R.string.settings_map_style), style = MaterialTheme.typography.titleMedium, color = TriplyColors.IvoryInk)
                    val styles = listOf(
                        "liberty" to R.string.map_style_liberty,
                        "dark" to R.string.map_style_dark,
                        "positron" to R.string.map_style_positron,
                        "bright" to R.string.map_style_bright
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        styles.take(2).forEach { (id, res) ->
                            FilterChip(
                                selected = prefs.mapStyleId == id,
                                onClick = { viewModel.setMapStyle(id) },
                                label = { Text(stringResource(res)) }
                            )
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        styles.drop(2).forEach { (id, res) ->
                            FilterChip(
                                selected = prefs.mapStyleId == id,
                                onClick = { viewModel.setMapStyle(id) },
                                label = { Text(stringResource(res)) }
                            )
                        }
                    }
                    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(stringResource(R.string.settings_online_maps), color = TriplyColors.IvoryInk)
                        Switch(checked = prefs.onlineMapsDefault, onCheckedChange = { viewModel.setOnlineMapsDefault(it) })
                    }
                    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(stringResource(R.string.settings_mobile_data), color = TriplyColors.IvoryInk)
                        Switch(checked = prefs.allowMobileDataDownloads, onCheckedChange = { viewModel.setAllowMobileData(it) })
                    }
                    EditorialSecondaryButton(stringResource(R.string.settings_offline_maps), onOpenOfflineMaps, modifier = Modifier.fillMaxWidth())
                }
            }
        }

        // Currency, Privacy & Developer area separation
        item {
            Surface(color = TriplyColors.SlateSurface, shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, TriplyColors.HairlineBorder)) {
                Column(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    EditorialKeyValueRow(stringResource(R.string.settings_currency), "${prefs.currencyCode} (Default)")
                    Text(
                        text = "Local-first storage: Your trips, expenses, packing lists, and journal stay on your device. No account or cloud tracking.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TriplyColors.WarmStone
                    )
                    EditorialSecondaryButton(
                        text = stringResource(R.string.settings_developer),
                        onClick = onOpenDeveloperSettings,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // Developer Credits (Preserved verbatim as required)
        item {
            Surface(color = TriplyColors.SlateSurface, shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, TriplyColors.OchreAccent.copy(alpha = 0.4f))) {
                Column(modifier = Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(stringResource(R.string.credits_title), style = MaterialTheme.typography.titleLarge, color = TriplyColors.OchreAccent)
                    Text("${DeveloperCredits.AUTHOR_PRIMARY} · ${DeveloperCredits.AUTHOR_HANDLE}", style = MaterialTheme.typography.titleMedium, color = TriplyColors.IvoryInk)
                    Text(stringResource(R.string.credits_subtitle), style = MaterialTheme.typography.bodyMedium, color = TriplyColors.WarmStone)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        EditorialSecondaryButton(stringResource(R.string.credits_social_instagram), { openExternalUrl(DeveloperCredits.URL_INSTAGRAM) }, modifier = Modifier.weight(1f))
                        EditorialSecondaryButton(stringResource(R.string.credits_social_tiktok), { openExternalUrl(DeveloperCredits.URL_TIKTOK) }, modifier = Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        EditorialSecondaryButton(stringResource(R.string.credits_social_discord), { openExternalUrl(DeveloperCredits.URL_DISCORD) }, modifier = Modifier.weight(1f))
                        EditorialSecondaryButton(stringResource(R.string.credits_social_whatsapp), { openExternalUrl(DeveloperCredits.URL_WHATSAPP) }, modifier = Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

@Composable
fun DeveloperSettingsScreen(
    viewModel: TriplyViewModel,
    onBack: () -> Unit
) {
    val prefs by viewModel.preferences.collectAsState()
    val testStatus by viewModel.providerTestStatus.collectAsState()
    var styleOverride by remember(prefs.customMapStyleUrl) { mutableStateOf(prefs.customMapStyleUrl) }
    var routingOverride by remember(prefs.customRoutingBaseUrl) { mutableStateOf(prefs.customRoutingBaseUrl) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(TriplyColors.ObsidianCanvas)
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = null, tint = TriplyColors.IvoryInk)
            }
            Text(stringResource(R.string.settings_developer), style = MaterialTheme.typography.titleLarge, color = TriplyColors.IvoryInk)
        }
        Text(stringResource(R.string.dev_settings_warning), style = MaterialTheme.typography.bodyMedium, color = TriplyColors.AmberWarning)
        OutlinedTextField(
            value = styleOverride,
            onValueChange = { styleOverride = it },
            label = { Text("Custom MapLibre Style JSON URL (optional)") },
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = routingOverride,
            onValueChange = { routingOverride = it },
            label = { Text("Custom OSRM Routing Base URL (optional)") },
            modifier = Modifier.fillMaxWidth()
        )
        Button(
            onClick = { viewModel.saveDeveloperOverrides(styleOverride, routingOverride) },
            colors = ButtonDefaults.buttonColors(containerColor = TriplyColors.OchreAccent, contentColor = TriplyColors.ObsidianCanvas)
        ) { Text(stringResource(R.string.action_save)) }
        Spacer(Modifier.height(8.dp))
        EditorialSecondaryButton(stringResource(R.string.dev_test_connection), { viewModel.testProviderConnectivity() })
        Text(
            text = testStatus ?: stringResource(R.string.dev_status_untested),
            style = MaterialTheme.typography.bodyMedium,
            color = TriplyColors.WarmStone
        )
    }
}
