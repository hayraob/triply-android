package com.triply.app.core.designsystem

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/**
 * Triply V2 — Modern Travel Editorial Color Tokens.
 * Deep charcoal-navy canvas, layered slate surfaces, warm ochre accent, ivory ink.
 */
object TriplyColors {
    val ObsidianCanvas = Color(0xFF0F141B)
    val SlateSurface = Color(0xFF171E28)
    val ElevatedSurface = Color(0xFF1F2835)
    val HairlineBorder = Color(0xFF2B3647)

    val OchreAccent = Color(0xFFD99B43)
    val OchreSoft = Color(0xFF3A2D1A)
    val TerracottaCoral = Color(0xFFC96D53)

    val IvoryInk = Color(0xFFF4F1EA)
    val WarmStone = Color(0xFFB5B1A8)
    val MutedAsh = Color(0xFF7E8794)

    val SageSuccess = Color(0xFF4F9A76)
    val AmberWarning = Color(0xFFE2A336)
    val CrimsonAlert = Color(0xFFD45B5B)
}

private val TriplyDarkColorScheme = darkColorScheme(
    primary = TriplyColors.OchreAccent,
    onPrimary = TriplyColors.ObsidianCanvas,
    primaryContainer = TriplyColors.OchreSoft,
    onPrimaryContainer = TriplyColors.IvoryInk,
    secondary = TriplyColors.TerracottaCoral,
    onSecondary = TriplyColors.ObsidianCanvas,
    background = TriplyColors.ObsidianCanvas,
    onBackground = TriplyColors.IvoryInk,
    surface = TriplyColors.SlateSurface,
    onSurface = TriplyColors.IvoryInk,
    surfaceVariant = TriplyColors.ElevatedSurface,
    onSurfaceVariant = TriplyColors.WarmStone,
    outline = TriplyColors.HairlineBorder,
    error = TriplyColors.CrimsonAlert,
    onError = TriplyColors.IvoryInk
)

val TriplyShapes = Shapes(
    extraSmall = RoundedCornerShape(4.dp),
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(12.dp),
    large = RoundedCornerShape(16.dp),
    extraLarge = RoundedCornerShape(24.dp)
)

@Composable
fun TriplyTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = TriplyDarkColorScheme,
        typography = TriplyTypography,
        shapes = TriplyShapes,
        content = content
    )
}
