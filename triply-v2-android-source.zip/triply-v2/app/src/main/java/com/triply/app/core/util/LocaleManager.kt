package com.triply.app.core.util

import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat

object LocaleManager {
    const val LANG_ENGLISH = "en"
    const val LANG_INDONESIAN = "in"

    fun applyLanguage(languageTag: String) {
        val normalized = if (languageTag == "id" || languageTag == LANG_INDONESIAN) "in" else "en"
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(normalized))
    }

    fun currentLanguageTag(): String {
        val locales = AppCompatDelegate.getApplicationLocales()
        val tag = if (!locales.isEmpty) locales[0]?.language else null
        return if (tag == "id" || tag == "in") LANG_INDONESIAN else LANG_ENGLISH
    }
}
