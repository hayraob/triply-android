package com.triply.app.core.alarm

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.triply.app.R

enum class ReminderScheduleResult {
    SCHEDULED_EXACT,
    DENIED_EXACT_ALARM_PERMISSION,
    FAILED_IN_PAST
}

class TripReminderScheduler(private val context: Context) {

    fun scheduleReminder(
        requestCode: Int,
        triggerAtMillis: Long,
        title: String,
        body: String
    ): ReminderScheduleResult {
        if (triggerAtMillis <= System.currentTimeMillis()) {
            return ReminderScheduleResult.FAILED_IN_PAST
        }
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarmManager.canScheduleExactAlarms()) {
            return ReminderScheduleResult.DENIED_EXACT_ALARM_PERMISSION
        }

        val intent = Intent(context, TripReminderReceiver::class.java).apply {
            putExtra(TripReminderReceiver.EXTRA_TITLE, title)
            putExtra(TripReminderReceiver.EXTRA_BODY, body)
            putExtra(TripReminderReceiver.EXTRA_ID, requestCode)
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return try {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent)
            ReminderScheduleResult.SCHEDULED_EXACT
        } catch (_: SecurityException) {
            ReminderScheduleResult.DENIED_EXACT_ALARM_PERMISSION
        }
    }

    fun cancelReminder(requestCode: Int) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, TripReminderReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pendingIntent != null) {
            alarmManager.cancel(pendingIntent)
        }
    }
}

class TripReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra(EXTRA_TITLE) ?: context.getString(R.string.app_name)
        val body = intent.getStringExtra(EXTRA_BODY).orEmpty()
        val id = intent.getIntExtra(EXTRA_ID, 1001)

        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Trip Departure Reminders",
            NotificationManager.IMPORTANCE_HIGH
        )
        nm.createNotificationChannel(channel)

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(title)
            .setContentText(body)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()

        nm.notify(id, notification)
    }

    companion object {
        const val CHANNEL_ID = "triply_trip_reminders"
        const val EXTRA_TITLE = "extra_title"
        const val EXTRA_BODY = "extra_body"
        const val EXTRA_ID = "extra_id"
    }
}
