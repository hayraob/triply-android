package com.triply.app.data.remote

import com.triply.app.domain.PlaceResult
import com.triply.app.domain.PoiCategory
import com.triply.app.domain.RouteEstimate
import com.triply.app.domain.WeatherForecastResult

/**
 * Separate capability abstractions as required:
 * Map tiles, geocoding, POI search, routing, weather, and destination imagery
 * are never conflated into a single API.
 */
interface MapTileProvider {
    val providerName: String
    val attribution: String
    fun styleUrlFor(styleId: String, customOverrideUrl: String = ""): String
    fun supportedStyles(): List<Pair<String, String>>
}

interface GeocodingProvider {
    val providerName: String
    suspend fun searchPlaces(query: String, limit: Int = 10): Result<List<PlaceResult>>
    suspend fun reverseGeocode(latitude: Double, longitude: Double): Result<PlaceResult?>
}

interface PoiSearchProvider {
    val providerName: String
    suspend fun searchByCategory(
        category: PoiCategory,
        centerLat: Double,
        centerLon: Double,
        radiusMeters: Int = 6000,
        limit: Int = 20
    ): Result<List<PlaceResult>>
}

interface RoutingProvider {
    val providerName: String
    suspend fun estimateRoute(
        fromLat: Double,
        fromLon: Double,
        toLat: Double,
        toLon: Double,
        transportMode: String
    ): Result<RouteEstimate>
}

interface WeatherProvider {
    val providerName: String
    suspend fun fetchForecast(
        destinationName: String,
        latitude: Double,
        longitude: Double,
        tripStartEpochDay: Long,
        tripEndEpochDay: Long
    ): Result<WeatherForecastResult>
}

interface DestinationImageProvider {
    val providerName: String
    suspend fun fetchImageForPlace(placeName: String): Result<String?>
}
