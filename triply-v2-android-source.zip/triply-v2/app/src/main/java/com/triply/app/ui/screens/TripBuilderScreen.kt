package com.triply.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.ArrowDownward
import androidx.compose.material.icons.outlined.ArrowUpward
import androidx.compose.material.icons.outlined.ChevronLeft
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.triply.app.R
import com.triply.app.core.designsystem.EditorialKeyValueRow
import com.triply.app.core.designsystem.EditorialProgressBar
import com.triply.app.core.designsystem.EditorialSecondaryButton
import com.triply.app.core.designsystem.IdrAmountTextField
import com.triply.app.core.designsystem.TriplyColors
import com.triply.app.core.util.DateRangeValidation
import com.triply.app.core.util.DateUtils
import com.triply.app.core.util.IdrFormatter
import com.triply.app.data.local.TripDestinationEntity
import com.triply.app.domain.DestinationOrdering
import com.triply.app.ui.TriplyViewModel
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.TextStyle
import java.util.Locale
import java.util.UUID

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TripBuilderScreen(
    viewModel: TriplyViewModel,
    onTripCreated: (String) -> Unit,
    onBack: () -> Unit
) {
    var step by remember { mutableIntStateOf(0) } // 0..6 (7 guided steps)
    var tripTitle by remember { mutableStateOf("") }
    var destSearchQuery by remember { mutableStateOf("") }
    var selectedDestinations by remember { mutableStateOf<List<TripDestinationEntity>>(emptyList()) }
    var startEpochDay by remember { mutableStateOf<Long?>(null) }
    var endEpochDay by remember { mutableStateOf<Long?>(null) }
    var travelStyle by remember { mutableStateOf("Solo") }
    var transportMode by remember { mutableStateOf("Car") }
    var accommodationNote by remember { mutableStateOf("") }
    var budgetDigits by remember { mutableStateOf("") }
    var validationError by remember { mutableStateOf<String?>(null) }

    val searchResults by viewModel.searchResults.collectAsState()
    val stepTitles = listOf(
        R.string.builder_step_destination,
        R.string.builder_step_dates,
        R.string.builder_step_style,
        R.string.builder_step_transport,
        R.string.builder_step_accommodation,
        R.string.builder_step_budget,
        R.string.builder_step_review
    )
    val isOptionalStep = step == 4 || step == 5
    val destRequiredMsg = stringResource(R.string.builder_dest_required)
    val datesRequiredMsg = stringResource(R.string.builder_dates_required)
    val datesInvalidMsg = stringResource(R.string.builder_dates_invalid)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(TriplyColors.ObsidianCanvas)
            .padding(20.dp)
    ) {
        // Top header + progress
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            IconButton(onClick = { if (step > 0) step-- else onBack() }) {
                Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = stringResource(R.string.action_back), tint = TriplyColors.IvoryInk)
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = stringResource(R.string.builder_step_counter, step + 1, 7),
                    style = MaterialTheme.typography.labelSmall,
                    color = TriplyColors.OchreAccent
                )
                Text(
                    text = stringResource(stepTitles[step]),
                    style = MaterialTheme.typography.headlineMedium,
                    color = TriplyColors.IvoryInk
                )
            }
            if (isOptionalStep) {
                TextButton(onClick = { validationError = null; step++ }) {
                    Text(stringResource(R.string.action_skip), color = TriplyColors.WarmStone)
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        EditorialProgressBar(progress = (step + 1) / 7f)
        Spacer(Modifier.height(18.dp))

        // Step content
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            when (step) {
                0 -> {
                    OutlinedTextField(
                        value = tripTitle,
                        onValueChange = { tripTitle = it },
                        label = { Text(stringResource(R.string.builder_trip_name_label)) },
                        placeholder = { Text(stringResource(R.string.builder_trip_name_hint)) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = destSearchQuery,
                        onValueChange = {
                            destSearchQuery = it
                            viewModel.searchPlacesDebounced(it)
                        },
                        label = { Text(stringResource(R.string.builder_dest_search_hint)) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (destSearchQuery.isNotBlank()) {
                        EditorialSecondaryButton(
                            text = "${stringResource(R.string.builder_dest_add_manual)}: $destSearchQuery",
                            onClick = {
                                val next = TripDestinationEntity(
                                    id = UUID.randomUUID().toString(),
                                    tripId = "",
                                    orderIndex = selectedDestinations.size,
                                    name = destSearchQuery.trim()
                                )
                                selectedDestinations = DestinationOrdering.normalizeOrder(selectedDestinations + next)
                                destSearchQuery = ""
                                validationError = null
                            }
                        )
                    }
                    searchResults.take(5).forEach { place ->
                        Surface(
                            color = TriplyColors.SlateSurface,
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, TriplyColors.HairlineBorder),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    val stop = TripDestinationEntity(
                                        id = UUID.randomUUID().toString(),
                                        tripId = "",
                                        orderIndex = selectedDestinations.size,
                                        name = place.name,
                                        region = place.address,
                                        latitude = place.latitude,
                                        longitude = place.longitude,
                                        providerAttribution = place.attribution
                                    )
                                    selectedDestinations = DestinationOrdering.normalizeOrder(selectedDestinations + stop)
                                    destSearchQuery = ""
                                    validationError = null
                                }
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(place.name, style = MaterialTheme.typography.titleMedium, color = TriplyColors.IvoryInk)
                                Text(place.address, style = MaterialTheme.typography.labelSmall, color = TriplyColors.WarmStone)
                            }
                        }
                    }

                    if (selectedDestinations.isNotEmpty()) {
                        Text(stringResource(R.string.builder_dest_selected), style = MaterialTheme.typography.labelLarge, color = TriplyColors.OchreAccent)
                        selectedDestinations.forEachIndexed { idx, dest ->
                            Surface(
                                color = TriplyColors.ElevatedSurface,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("${idx + 1}. ${dest.name}", modifier = Modifier.weight(1f), color = TriplyColors.IvoryInk)
                                    IconButton(onClick = { selectedDestinations = DestinationOrdering.moveUp(selectedDestinations, idx) }) {
                                        Icon(Icons.Outlined.ArrowUpward, contentDescription = null, tint = TriplyColors.WarmStone)
                                    }
                                    IconButton(onClick = { selectedDestinations = DestinationOrdering.moveDown(selectedDestinations, idx) }) {
                                        Icon(Icons.Outlined.ArrowDownward, contentDescription = null, tint = TriplyColors.WarmStone)
                                    }
                                    IconButton(onClick = {
                                        selectedDestinations = DestinationOrdering.normalizeOrder(
                                            selectedDestinations.filterNot { it.id == dest.id }
                                        )
                                    }) {
                                        Icon(Icons.Outlined.DeleteOutline, contentDescription = null, tint = TriplyColors.CrimsonAlert)
                                    }
                                }
                            }
                        }
                    }
                }
                1 -> {
                    Text(stringResource(R.string.builder_dates_subtitle), style = MaterialTheme.typography.bodyMedium, color = TriplyColors.WarmStone)
                    InteractiveDateRangeCalendar(
                        startEpochDay = startEpochDay,
                        endEpochDay = endEpochDay,
                        onSelectDay = { tapped ->
                            validationError = null
                            if (startEpochDay == null || (startEpochDay != null && endEpochDay != null)) {
                                startEpochDay = tapped
                                endEpochDay = null
                            } else {
                                val s = startEpochDay!!
                                if (tapped < s) {
                                    startEpochDay = tapped
                                    endEpochDay = s
                                } else {
                                    endEpochDay = tapped
                                }
                            }
                        }
                    )
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(
                            "${stringResource(R.string.builder_dates_start)}: ${startEpochDay?.let { DateUtils.formatShortDate(it) } ?: "—"}",
                            style = MaterialTheme.typography.labelLarge,
                            color = TriplyColors.IvoryInk
                        )
                        Text(
                            "${stringResource(R.string.builder_dates_end)}: ${endEpochDay?.let { DateUtils.formatShortDate(it) } ?: "—"}",
                            style = MaterialTheme.typography.labelLarge,
                            color = TriplyColors.OchreAccent
                        )
                    }
                }
                2 -> {
                    val styles = listOf(
                        "Solo" to R.string.builder_style_solo,
                        "Couple" to R.string.builder_style_couple,
                        "Friends" to R.string.builder_style_friends,
                        "Family" to R.string.builder_style_family,
                        "Group" to R.string.builder_style_group
                    )
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        styles.forEach { (key, res) ->
                            FilterChip(
                                selected = travelStyle == key,
                                onClick = { travelStyle = key },
                                label = { Text(stringResource(res)) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = TriplyColors.OchreAccent,
                                    selectedLabelColor = TriplyColors.ObsidianCanvas
                                )
                            )
                        }
                    }
                }
                3 -> {
                    val modes = listOf(
                        "Motorcycle" to R.string.builder_transport_motorcycle,
                        "Car" to R.string.builder_transport_car,
                        "Train" to R.string.builder_transport_train,
                        "Bus" to R.string.builder_transport_bus,
                        "Airplane" to R.string.builder_transport_airplane,
                        "Other" to R.string.builder_transport_other
                    )
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        modes.forEach { (key, res) ->
                            FilterChip(
                                selected = transportMode == key,
                                onClick = { transportMode = key },
                                label = { Text(stringResource(res)) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = TriplyColors.OchreAccent,
                                    selectedLabelColor = TriplyColors.ObsidianCanvas
                                )
                            )
                        }
                    }
                }
                4 -> {
                    Text(stringResource(R.string.builder_accommodation_hint), style = MaterialTheme.typography.bodyMedium, color = TriplyColors.WarmStone)
                    OutlinedTextField(
                        value = accommodationNote,
                        onValueChange = { accommodationNote = it },
                        label = { Text(stringResource(R.string.bookings_type_accommodation)) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                5 -> {
                    IdrAmountTextField(
                        rawDigits = budgetDigits,
                        onRawDigitsChange = { budgetDigits = it },
                        label = stringResource(R.string.builder_budget_total_label),
                        supportingText = stringResource(R.string.builder_budget_hint)
                    )
                }
                6 -> {
                    val sDay = startEpochDay ?: LocalDate.now().toEpochDay()
                    val eDay = endEpochDay ?: sDay
                    EditorialKeyValueRow(stringResource(R.string.builder_trip_name_label), tripTitle.ifBlank { selectedDestinations.firstOrNull()?.name ?: "Untitled" })
                    EditorialKeyValueRow(stringResource(R.string.builder_step_destination), selectedDestinations.joinToString(" → ") { it.name })
                    EditorialKeyValueRow(stringResource(R.string.builder_step_dates), DateUtils.formatDateRange(sDay, eDay))
                    EditorialKeyValueRow(stringResource(R.string.builder_step_style), travelStyle)
                    EditorialKeyValueRow(stringResource(R.string.builder_step_transport), transportMode)
                    EditorialKeyValueRow(stringResource(R.string.builder_step_budget), IdrFormatter.format(IdrFormatter.parseToLong(budgetDigits)))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TextButton(onClick = { step = 0 }) { Text("${stringResource(R.string.builder_edit_step)} ${stringResource(R.string.builder_step_destination)}") }
                        TextButton(onClick = { step = 1 }) { Text("${stringResource(R.string.builder_edit_step)} ${stringResource(R.string.builder_step_dates)}") }
                        TextButton(onClick = { step = 5 }) { Text("${stringResource(R.string.builder_edit_step)} ${stringResource(R.string.builder_step_budget)}") }
                    }
                }
            }

            if (validationError != null) {
                Text(validationError!!, color = TriplyColors.CrimsonAlert, style = MaterialTheme.typography.bodyMedium)
            }
        }

        // Bottom controls
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (step == 6) {
                EditorialSecondaryButton(
                    text = stringResource(R.string.builder_save_draft),
                    onClick = {
                        val sDay = startEpochDay ?: LocalDate.now().toEpochDay()
                        val eDay = endEpochDay ?: sDay
                        viewModel.saveNewTrip(
                            title = tripTitle,
                            startEpochDay = sDay,
                            endEpochDay = eDay,
                            travelStyle = travelStyle,
                            transportMode = transportMode,
                            totalBudgetIdr = IdrFormatter.parseToLong(budgetDigits),
                            destinations = selectedDestinations,
                            accommodationNote = accommodationNote,
                            isDraft = true,
                            onSaved = onTripCreated
                        )
                    },
                    modifier = Modifier.weight(1f)
                )
            }
            Button(
                onClick = {
                    when (step) {
                        0 -> {
                            if (selectedDestinations.isEmpty()) {
                                validationError = destRequiredMsg
                                return@Button
                            }
                            validationError = null
                            step++
                        }
                        1 -> {
                            when (DateUtils.validateDateRange(startEpochDay, endEpochDay)) {
                                DateRangeValidation.MissingDates -> { validationError = datesRequiredMsg; return@Button }
                                DateRangeValidation.EndBeforeStart -> { validationError = datesInvalidMsg; return@Button }
                                is DateRangeValidation.Valid -> { validationError = null; step++ }
                            }
                        }
                        6 -> {
                            val sDay = startEpochDay ?: LocalDate.now().toEpochDay()
                            val eDay = endEpochDay ?: sDay
                            viewModel.saveNewTrip(
                                title = tripTitle,
                                startEpochDay = sDay,
                                endEpochDay = eDay,
                                travelStyle = travelStyle,
                                transportMode = transportMode,
                                totalBudgetIdr = IdrFormatter.parseToLong(budgetDigits),
                                destinations = selectedDestinations,
                                accommodationNote = accommodationNote,
                                isDraft = false,
                                onSaved = onTripCreated
                            )
                        }
                        else -> { validationError = null; step++ }
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = TriplyColors.OchreAccent,
                    contentColor = TriplyColors.ObsidianCanvas
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text(stringResource(if (step == 6) R.string.builder_review_create else R.string.action_next))
            }
        }
    }
}

@Composable
fun InteractiveDateRangeCalendar(
    startEpochDay: Long?,
    endEpochDay: Long?,
    onSelectDay: (Long) -> Unit
) {
    var displayedMonth by remember { mutableStateOf(YearMonth.now()) }
    val firstDayOfMonth = displayedMonth.atDay(1)
    val leadingBlanks = (firstDayOfMonth.dayOfWeek.value % 7) // Sun=0..Sat=6
    val daysInMonth = displayedMonth.lengthOfMonth()

    Surface(
        color = TriplyColors.SlateSurface,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, TriplyColors.HairlineBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { displayedMonth = displayedMonth.minusMonths(1) }) {
                    Icon(Icons.Outlined.ChevronLeft, contentDescription = null, tint = TriplyColors.IvoryInk)
                }
                Text(
                    text = "${displayedMonth.month.getDisplayName(TextStyle.FULL, Locale.getDefault())} ${displayedMonth.year}",
                    style = MaterialTheme.typography.titleMedium,
                    color = TriplyColors.IvoryInk
                )
                IconButton(onClick = { displayedMonth = displayedMonth.plusMonths(1) }) {
                    Icon(Icons.Outlined.ChevronRight, contentDescription = null, tint = TriplyColors.IvoryInk)
                }
            }

            val dayLabels = listOf("S", "M", "T", "W", "T", "F", "S")
            Row(modifier = Modifier.fillMaxWidth()) {
                dayLabels.forEach { d ->
                    Text(
                        text = d,
                        modifier = Modifier.weight(1f),
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.labelSmall,
                        color = TriplyColors.MutedAsh
                    )
                }
            }

            val totalCells = leadingBlanks + daysInMonth
            val rows = (totalCells + 6) / 7
            for (r in 0 until rows) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    for (c in 0 until 7) {
                        val cellIndex = r * 7 + c
                        val dayNum = cellIndex - leadingBlanks + 1
                        if (dayNum in 1..daysInMonth) {
                            val epoch = displayedMonth.atDay(dayNum).toEpochDay()
                            val isEdge = epoch == startEpochDay || epoch == endEpochDay
                            val inRange = startEpochDay != null && endEpochDay != null && epoch in startEpochDay..endEpochDay
                            val bg = when {
                                isEdge -> TriplyColors.OchreAccent
                                inRange -> TriplyColors.OchreSoft
                                else -> TriplyColors.ObsidianCanvas.copy(alpha = 0.4f)
                            }
                            val fg = if (isEdge) TriplyColors.ObsidianCanvas else TriplyColors.IvoryInk
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .aspectRatio(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(bg)
                                    .border(
                                        width = if (isEdge) 1.dp else 0.dp,
                                        color = if (isEdge) TriplyColors.OchreAccent else TriplyColors.ObsidianCanvas,
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    .clickable { onSelectDay(epoch) },
                                contentAlignment = Alignment.Center
                            ) {
                                Text(dayNum.toString(), style = MaterialTheme.typography.bodyMedium, color = fg)
                            }
                        } else {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        }
    }
}
