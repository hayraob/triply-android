package com.triply.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.CloudDownload
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Directions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.triply.app.R
import com.triply.app.core.designsystem.EditorialBadge
import com.triply.app.core.designsystem.EditorialSectionHeader
import com.triply.app.core.designsystem.OfflineStatusBanner
import com.triply.app.core.designsystem.TriplyColors
import com.triply.app.domain.PlaceResult
import com.triply.app.domain.PoiCategory
import com.triply.app.ui.TriplyViewModel
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.Style

@Composable
fun MapDiscoveryScreen(
    viewModel: TriplyViewModel,
    onBack: () -> Unit,
    onOpenOfflineRegions: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val isOnline by viewModel.isOnline.collectAsState()
    val results by viewModel.searchResults.collectAsState()
    val isSearching by viewModel.isSearchingPlaces.collectAsState()
    val searchError by viewModel.placeSearchError.collectAsState()
    val routeEstimate by viewModel.routeEstimate.collectAsState()

    var query by remember { mutableStateOf("") }
    var selectedPlace by remember { mutableStateOf<PlaceResult?>(null) }
    var mapRef by remember { mutableStateOf<MapLibreMap?>(null) }
    val defaultLat = -7.7956 // Yogyakarta center default
    val defaultLon = 110.3695

    val mapView = remember {
        MapView(context).apply { onCreate(null) }
    }

    DisposableEffect(lifecycleOwner, mapView) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> mapView.onStart()
                Lifecycle.Event.ON_RESUME -> mapView.onResume()
                Lifecycle.Event.ON_PAUSE -> mapView.onPause()
                Lifecycle.Event.ON_STOP -> mapView.onStop()
                Lifecycle.Event.ON_DESTROY -> mapView.onDestroy()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(TriplyColors.ObsidianCanvas)
    ) {
        // Top bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = stringResource(R.string.action_back), tint = TriplyColors.IvoryInk)
            }
            Text(stringResource(R.string.map_title), style = MaterialTheme.typography.titleLarge, color = TriplyColors.IvoryInk, modifier = Modifier.weight(1f))
            IconButton(onClick = onOpenOfflineRegions) {
                Icon(Icons.Outlined.CloudDownload, contentDescription = stringResource(R.string.map_offline_regions_title), tint = TriplyColors.OchreAccent)
            }
        }

        OfflineStatusBanner(isOnline = isOnline, modifier = Modifier.padding(horizontal = 16.dp))

        // Search input + POI category rail
        OutlinedTextField(
            value = query,
            onValueChange = {
                query = it
                viewModel.searchPlacesDebounced(it)
            },
            placeholder = { Text(stringResource(R.string.map_search_hint)) },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        )

        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(PoiCategory.entries) { category ->
                FilterChip(
                    selected = false,
                    onClick = {
                        val center = mapRef?.cameraPosition?.target
                        viewModel.searchPoisByCategory(
                            category = category,
                            centerLat = center?.latitude ?: defaultLat,
                            centerLon = center?.longitude ?: defaultLon
                        )
                    },
                    label = { Text(category.name.lowercase().replace('_', ' ').replaceFirstChar { it.uppercase() }) }
                )
            }
        }

        // Native MapLibre Online Vector Map
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(270.dp)
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            AndroidView(
                factory = { mapView },
                modifier = Modifier.fillMaxSize(),
                update = { view ->
                    view.getMapAsync { map ->
                        mapRef = map
                        map.setStyle(Style.Builder().fromUri(viewModel.mapStyleUrl()))
                        if (map.cameraPosition.zoom < 2.0) {
                            map.cameraPosition = CameraPosition.Builder()
                                .target(LatLng(defaultLat, defaultLon))
                                .zoom(11.0)
                                .build()
                        }
                    }
                }
            )
            if (isSearching) {
                CircularProgressIndicator(
                    color = TriplyColors.OchreAccent,
                    modifier = Modifier.align(Alignment.Center)
                )
            }
        }

        // Route estimate card if calculated
        routeEstimate?.let { est ->
            Surface(
                color = TriplyColors.SlateSurface,
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, TriplyColors.OchreAccent.copy(alpha = 0.4f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "${stringResource(R.string.map_route_estimate_title)}: ${"%.1f".format(est.distanceKm)} km · ~${est.durationMinutes} min",
                        style = MaterialTheme.typography.titleMedium,
                        color = TriplyColors.OchreAccent
                    )
                    Text(est.providerAttribution, style = MaterialTheme.typography.labelSmall, color = TriplyColors.WarmStone)
                    est.disclaimer?.let {
                        Text(it, style = MaterialTheme.typography.labelSmall, color = TriplyColors.AmberWarning)
                    }
                }
            }
        }

        // Error or results list
        if (searchError != null) {
            Text(
                text = searchError!!,
                color = TriplyColors.CrimsonAlert,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
            )
        }

        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(results, key = { it.id }) { place ->
                Surface(
                    color = if (selectedPlace?.id == place.id) TriplyColors.ElevatedSurface else TriplyColors.SlateSurface,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, TriplyColors.HairlineBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            selectedPlace = place
                            mapRef?.animateCamera(
                                CameraUpdateFactory.newLatLngZoom(LatLng(place.latitude, place.longitude), 14.0)
                            )
                        }
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(place.name, style = MaterialTheme.typography.titleMedium, color = TriplyColors.IvoryInk)
                            EditorialBadge(place.category)
                        }
                        if (place.address.isNotBlank()) {
                            Text(place.address, style = MaterialTheme.typography.bodyMedium, color = TriplyColors.WarmStone)
                        }
                        Text(
                            text = "${"%.4f".format(place.latitude)}, ${"%.4f".format(place.longitude)} · ${place.attribution}",
                            style = MaterialTheme.typography.labelSmall,
                            color = TriplyColors.MutedAsh
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 6.dp)) {
                            Button(
                                onClick = {
                                    viewModel.estimateRoute(defaultLat, defaultLon, place.latitude, place.longitude, "Car")
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = TriplyColors.OchreAccent,
                                    contentColor = TriplyColors.ObsidianCanvas
                                ),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Outlined.Directions, contentDescription = null)
                                Spacer(Modifier.width(6.dp))
                                Text(stringResource(R.string.map_route_estimate_title))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun OfflineMapManagerScreen(
    viewModel: TriplyViewModel,
    onBack: () -> Unit
) {
    val regions by viewModel.offlineRegions.collectAsState()
    val presets = listOf(
        Triple("Yogyakarta & Borobudur", 18, listOf(-7.95, -7.55, 110.15, 110.55)),
        Triple("Bali South & Ubud", 24, listOf(-8.85, -8.35, 115.05, 115.45)),
        Triple("Bandung & Lembang", 21, listOf(-7.05, -6.75, 107.45, 107.80)),
        Triple("Semarang & Pekalongan Coast", 26, listOf(-7.15, -6.80, 109.55, 110.55))
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(TriplyColors.ObsidianCanvas),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = null, tint = TriplyColors.IvoryInk)
                }
                EditorialSectionHeader(title = stringResource(R.string.map_offline_regions_title))
            }
        }
        item {
            Surface(
                color = TriplyColors.OchreSoft,
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, TriplyColors.OchreAccent.copy(alpha = 0.4f))
            ) {
                Text(
                    text = stringResource(R.string.map_offline_disclaimer),
                    style = MaterialTheme.typography.bodyMedium,
                    color = TriplyColors.IvoryInk,
                    modifier = Modifier.padding(14.dp)
                )
            }
        }
        items(presets) { (name, estMb, bounds) ->
            Surface(
                color = TriplyColors.SlateSurface,
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, TriplyColors.HairlineBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(name, style = MaterialTheme.typography.titleMedium, color = TriplyColors.IvoryInk)
                        Text(stringResource(R.string.map_offline_size_est, estMb), style = MaterialTheme.typography.labelSmall, color = TriplyColors.WarmStone)
                    }
                    Button(
                        onClick = { viewModel.saveOfflineRegionRecord(name, bounds[0], bounds[1], bounds[2], bounds[3], estMb) },
                        colors = ButtonDefaults.buttonColors(containerColor = TriplyColors.OchreAccent, contentColor = TriplyColors.ObsidianCanvas)
                    ) {
                        Text(stringResource(R.string.map_offline_download))
                    }
                }
            }
        }
        if (regions.isNotEmpty()) {
            item { Text("Saved Regions", style = MaterialTheme.typography.titleMedium, color = TriplyColors.OchreAccent) }
            items(regions, key = { it.id }) { region ->
                Surface(
                    color = TriplyColors.ElevatedSurface,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(region.name, style = MaterialTheme.typography.titleMedium, color = TriplyColors.IvoryInk)
                            Text("${region.status} · ~${region.estimatedSizeMb} MB", style = MaterialTheme.typography.labelSmall, color = TriplyColors.WarmStone)
                        }
                        IconButton(onClick = { viewModel.deleteOfflineRegion(region) }) {
                            Icon(Icons.Outlined.DeleteOutline, contentDescription = null, tint = TriplyColors.CrimsonAlert)
                        }
                    }
                }
            }
        }
    }
}
