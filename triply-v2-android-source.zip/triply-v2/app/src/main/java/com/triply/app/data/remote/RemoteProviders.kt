package com.triply.app.data.remote

import com.triply.app.BuildConfig
import com.triply.app.core.util.DateUtils
import com.triply.app.data.local.CachedPlaceEntity
import com.triply.app.data.local.UtilityDao
import com.triply.app.domain.GeoMath
import com.triply.app.domain.PlaceResult
import com.triply.app.domain.PoiCategory
import com.triply.app.domain.RouteEstimate
import com.triply.app.domain.WeatherDayForecast
import com.triply.app.domain.WeatherForecastResult
import com.triply.app.domain.WmoWeatherClassifier
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.URLEncoder
import java.time.Instant
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

object HttpClientFactory {
    val json: Json = Json {
        ignoreUnknownKeys = true
        isLenient = true
    }

    fun createClient(): OkHttpClient {
        return OkHttpClient.Builder()
            .connectTimeout(12, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .addInterceptor { chain ->
                val req = chain.request().newBuilder()
                    .header("User-Agent", BuildConfig.USER_AGENT)
                    .build()
                chain.proceed(req)
            }
            .build()
    }
}

class OpenFreeMapTileProvider : MapTileProvider {
    override val providerName: String = "OpenFreeMap"
    override val attribution: String = "© OpenFreeMap · © OpenMapTiles · © OpenStreetMap contributors"

    override fun styleUrlFor(styleId: String, customOverrideUrl: String): String {
        if (customOverrideUrl.startsWith("https://")) return customOverrideUrl
        return when (styleId) {
            "dark" -> "https://tiles.openfreemap.org/styles/dark"
            "positron" -> "https://tiles.openfreemap.org/styles/positron"
            "bright" -> "https://tiles.openfreemap.org/styles/bright"
            else -> "https://tiles.openfreemap.org/styles/liberty"
        }
    }

    override fun supportedStyles(): List<Pair<String, String>> = listOf(
        "liberty" to "Liberty",
        "dark" to "Dark",
        "positron" to "Positron",
        "bright" to "Bright"
    )
}

/**
 * Primary forward geocoding & place search provider via Komoot Photon (no API key required).
 */
class PhotonGeocodingProvider(
    private val client: OkHttpClient
) : GeocodingProvider {
    override val providerName: String = "Photon (Komoot / OSM)"

    override suspend fun searchPlaces(query: String, limit: Int): Result<List<PlaceResult>> = withContext(Dispatchers.IO) {
        runCatching {
            val encoded = URLEncoder.encode(query.trim(), "UTF-8")
            val url = "https://photon.komoot.io/api/?q=$encoded&limit=$limit"
            val req = Request.Builder().url(url).get().build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) error("Photon HTTP ${resp.code}")
                val body = resp.body?.string().orEmpty()
                val root = HttpClientFactory.json.parseToJsonElement(body).jsonObject
                val features = root["features"]?.jsonArray ?: JsonArray(emptyList())
                features.mapIndexedNotNull { idx, elem ->
                    val obj = elem.jsonObject
                    val coords = obj["geometry"]?.jsonObject?.get("coordinates")?.jsonArray ?: return@mapIndexedNotNull null
                    val lon = coords.getOrNull(0)?.jsonPrimitive?.doubleOrNull ?: return@mapIndexedNotNull null
                    val lat = coords.getOrNull(1)?.jsonPrimitive?.doubleOrNull ?: return@mapIndexedNotNull null
                    val props = obj["properties"]?.jsonObject ?: JsonObject(emptyMap())
                    val name = props["name"]?.jsonPrimitive?.content
                        ?: props["city"]?.jsonPrimitive?.content
                        ?: props["street"]?.jsonPrimitive?.content
                        ?: return@mapIndexedNotNull null
                    val regionParts = listOfNotNull(
                        props["city"]?.jsonPrimitive?.content,
                        props["state"]?.jsonPrimitive?.content,
                        props["country"]?.jsonPrimitive?.content
                    ).distinct().joinToString(", ")
                    val osmVal = props["osm_value"]?.jsonPrimitive?.content ?: "place"
                    PlaceResult(
                        id = "photon_${props["osm_id"]?.jsonPrimitive?.content ?: idx}",
                        name = name,
                        category = osmVal.replace('_', ' '),
                        address = regionParts,
                        latitude = lat,
                        longitude = lon,
                        providerName = providerName,
                        attribution = "© OpenStreetMap contributors · Photon"
                    )
                }
            }
        }
    }

    override suspend fun reverseGeocode(latitude: Double, longitude: Double): Result<PlaceResult?> = withContext(Dispatchers.IO) {
        runCatching {
            val url = "https://photon.komoot.io/reverse?lat=$latitude&lon=$longitude"
            val req = Request.Builder().url(url).get().build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) error("Photon reverse HTTP ${resp.code}")
                val body = resp.body?.string().orEmpty()
                val features = HttpClientFactory.json.parseToJsonElement(body).jsonObject["features"]?.jsonArray
                val first = features?.firstOrNull()?.jsonObject ?: return@use null
                val props = first["properties"]?.jsonObject ?: JsonObject(emptyMap())
                val name = props["name"]?.jsonPrimitive?.content
                    ?: props["city"]?.jsonPrimitive?.content
                    ?: "Selected Location"
                val addr = listOfNotNull(
                    props["city"]?.jsonPrimitive?.content,
                    props["state"]?.jsonPrimitive?.content,
                    props["country"]?.jsonPrimitive?.content
                ).distinct().joinToString(", ")
                PlaceResult(
                    id = "photon_rev_${latitude}_${longitude}",
                    name = name,
                    category = props["osm_value"]?.jsonPrimitive?.content ?: "place",
                    address = addr,
                    latitude = latitude,
                    longitude = longitude,
                    providerName = providerName,
                    attribution = "© OpenStreetMap contributors · Photon"
                )
            }
        }
    }
}

/**
 * Fallback geocoding strictly honoring Nominatim Usage Policy:
 * - Custom User-Agent header
 * - >= 1.1s interval rate limiting
 * - Never used for live keystroke autocomplete
 */
class NominatimFallbackProvider(
    private val client: OkHttpClient
) : GeocodingProvider {
    override val providerName: String = "Nominatim (OpenStreetMap)"
    private val rateMutex = Mutex()
    private var lastRequestAtMillis: Long = 0L

    private suspend fun throttle() {
        rateMutex.withLock {
            val now = System.currentTimeMillis()
            val waitMs = 1100L - (now - lastRequestAtMillis)
            if (waitMs > 0) delay(waitMs)
            lastRequestAtMillis = System.currentTimeMillis()
        }
    }

    override suspend fun searchPlaces(query: String, limit: Int): Result<List<PlaceResult>> = withContext(Dispatchers.IO) {
        runCatching {
            throttle()
            val encoded = URLEncoder.encode(query.trim(), "UTF-8")
            val url = "https://nominatim.openstreetmap.org/search?format=jsonv2&limit=$limit&q=$encoded"
            val req = Request.Builder().url(url).get().build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) error("Nominatim HTTP ${resp.code}")
                val array = HttpClientFactory.json.parseToJsonElement(resp.body?.string().orEmpty()).jsonArray
                array.mapIndexedNotNull { idx, elem ->
                    val obj = elem.jsonObject
                    val lat = obj["lat"]?.jsonPrimitive?.content?.toDoubleOrNull() ?: return@mapIndexedNotNull null
                    val lon = obj["lon"]?.jsonPrimitive?.content?.toDoubleOrNull() ?: return@mapIndexedNotNull null
                    val display = obj["display_name"]?.jsonPrimitive?.content ?: return@mapIndexedNotNull null
                    val name = obj["name"]?.jsonPrimitive?.content?.takeIf { it.isNotBlank() }
                        ?: display.substringBefore(",")
                    PlaceResult(
                        id = "nom_${obj["place_id"]?.jsonPrimitive?.content ?: idx}",
                        name = name,
                        category = obj["type"]?.jsonPrimitive?.content ?: "place",
                        address = display,
                        latitude = lat,
                        longitude = lon,
                        providerName = providerName,
                        attribution = "© OpenStreetMap contributors · Nominatim"
                    )
                }
            }
        }
    }

    override suspend fun reverseGeocode(latitude: Double, longitude: Double): Result<PlaceResult?> = withContext(Dispatchers.IO) {
        runCatching {
            throttle()
            val url = "https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=$latitude&lon=$longitude"
            val req = Request.Builder().url(url).get().build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) error("Nominatim reverse HTTP ${resp.code}")
                val obj = HttpClientFactory.json.parseToJsonElement(resp.body?.string().orEmpty()).jsonObject
                val display = obj["display_name"]?.jsonPrimitive?.content ?: return@use null
                PlaceResult(
                    id = "nom_rev_${latitude}_${longitude}",
                    name = obj["name"]?.jsonPrimitive?.content?.takeIf { it.isNotBlank() } ?: display.substringBefore(","),
                    category = obj["type"]?.jsonPrimitive?.content ?: "location",
                    address = display,
                    latitude = latitude,
                    longitude = longitude,
                    providerName = providerName,
                    attribution = "© OpenStreetMap contributors · Nominatim"
                )
            }
        }
    }
}

/**
 * Category-driven real-world POI discovery using Overpass API (OpenStreetMap).
 */
class OverpassPoiProvider(
    private val client: OkHttpClient
) : PoiSearchProvider {
    override val providerName: String = "Overpass API (OpenStreetMap)"

    override suspend fun searchByCategory(
        category: PoiCategory,
        centerLat: Double,
        centerLon: Double,
        radiusMeters: Int,
        limit: Int
    ): Result<List<PlaceResult>> = withContext(Dispatchers.IO) {
        runCatching {
            val (tagKey, tagVal) = category.osmTagFilter.split("=")
            val overpassQuery = "[out:json][timeout:12];(" +
                "node["$tagKey"="$tagVal"](around:$radiusMeters,$centerLat,$centerLon);" +
                "way["$tagKey"="$tagVal"](around:$radiusMeters,$centerLat,$centerLon);" +
                ");out center $limit;"

            val form = FormBody.Builder().add("data", overpassQuery).build()
            val req = Request.Builder()
                .url("https://overpass-api.de/api/interpreter")
                .post(form)
                .build()

            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) error("Overpass HTTP ${resp.code}")
                val root = HttpClientFactory.json.parseToJsonElement(resp.body?.string().orEmpty()).jsonObject
                val elements = root["elements"]?.jsonArray ?: JsonArray(emptyList())
                elements.mapIndexedNotNull { idx, elem ->
                    val obj = elem.jsonObject
                    val tags = obj["tags"]?.jsonObject ?: return@mapIndexedNotNull null
                    val name = tags["name"]?.jsonPrimitive?.content ?: return@mapIndexedNotNull null
                    val lat = obj["lat"]?.jsonPrimitive?.doubleOrNull
                        ?: obj["center"]?.jsonObject?.get("lat")?.jsonPrimitive?.doubleOrNull
                        ?: return@mapIndexedNotNull null
                    val lon = obj["lon"]?.jsonPrimitive?.doubleOrNull
                        ?: obj["center"]?.jsonObject?.get("lon")?.jsonPrimitive?.doubleOrNull
                        ?: return@mapIndexedNotNull null
                    val addr = listOfNotNull(
                        tags["addr:street"]?.jsonPrimitive?.content,
                        tags["addr:city"]?.jsonPrimitive?.content
                    ).joinToString(", ").ifBlank { "%.4f, %.4f".format(lat, lon) }
                    PlaceResult(
                        id = "osm_${obj["id"]?.jsonPrimitive?.content ?: idx}",
                        name = name,
                        category = category.name.lowercase().replace('_', ' '),
                        address = addr,
                        latitude = lat,
                        longitude = lon,
                        openingHours = tags["opening_hours"]?.jsonPrimitive?.content,
                        providerName = providerName,
                        attribution = "© OpenStreetMap contributors · Overpass"
                    )
                }.take(limit)
            }
        }
    }
}

/**
 * Hybrid Place & POI Repository:
 * Checks local Room cache first, queries primary provider, falls back to secondary provider,
 * and degrades gracefully when offline.
 */
class HybridPlaceRepository(
    private val primaryGeocoder: GeocodingProvider,
    private val fallbackGeocoder: GeocodingProvider,
    private val poiProvider: PoiSearchProvider,
    private val utilityDao: UtilityDao? = null,
    private val isOnlineCheck: () -> Boolean = { true }
) {
    private val cacheTtlMillis = 24L * 60L * 60L * 1000L

    suspend fun searchText(query: String): Result<List<PlaceResult>> {
        val normalizedKey = "text:${query.trim().lowercase()}"
        val cached = loadFromCache(normalizedKey)
        if (!isOnlineCheck()) {
            return if (cached != null) Result.success(cached)
            else Result.failure(IllegalStateException("Offline and no cached results for '$query'"))
        }
        if (cached != null) return Result.success(cached)

        val primary = primaryGeocoder.searchPlaces(query)
        if (primary.isSuccess && primary.getOrNull().orEmpty().isNotEmpty()) {
            saveToCache(normalizedKey, primary.getOrThrow())
            return primary
        }
        val fallback = fallbackGeocoder.searchPlaces(query)
        if (fallback.isSuccess) {
            saveToCache(normalizedKey, fallback.getOrThrow())
        }
        return fallback
    }

    suspend fun searchCategory(
        category: PoiCategory,
        centerLat: Double,
        centerLon: Double
    ): Result<List<PlaceResult>> {
        val key = "cat:${category.name}:${"%.2f".format(centerLat)}:${"%.2f".format(centerLon)}"
        val cached = loadFromCache(key)
        if (!isOnlineCheck()) {
            return if (cached != null) Result.success(cached)
            else Result.failure(IllegalStateException("Offline and no cached POIs for ${category.name}"))
        }
        if (cached != null) return Result.success(cached)

        val over = poiProvider.searchByCategory(category, centerLat, centerLon)
        if (over.isSuccess && over.getOrNull().orEmpty().isNotEmpty()) {
            saveToCache(key, over.getOrThrow())
            return over
        }
        // Fallback to text search around category keyword
        val fallback = primaryGeocoder.searchPlaces(category.name.lowercase().replace('_', ' '), limit = 10)
        if (fallback.isSuccess) saveToCache(key, fallback.getOrThrow())
        return fallback
    }

    private suspend fun loadFromCache(key: String): List<PlaceResult>? {
        val entry = utilityDao?.getCachedPlace(key) ?: return null
        if (System.currentTimeMillis() - entry.cachedAtMillis > cacheTtlMillis) return null
        return runCatching {
            HttpClientFactory.json.decodeFromString<List<PlaceResult>>(entry.jsonPayload)
        }.getOrNull()
    }

    private suspend fun saveToCache(key: String, results: List<PlaceResult>) {
        if (utilityDao == null || results.isEmpty()) return
        val payload = HttpClientFactory.json.encodeToString(results)
        utilityDao.upsertCachedPlace(
            CachedPlaceEntity(
                queryKey = key,
                jsonPayload = payload,
                cachedAtMillis = System.currentTimeMillis()
            )
        )
    }
}

/**
 * OSRM public demo routing provider with honest straight-line fallback when offline or unavailable.
 */
class OsrmRoutingProvider(
    private val client: OkHttpClient,
    private val baseUrlProvider: () -> String = { "https://router.project-osrm.org" }
) : RoutingProvider {
    override val providerName: String = "OSRM (OpenStreetMap)"

    override suspend fun estimateRoute(
        fromLat: Double,
        fromLon: Double,
        toLat: Double,
        toLon: Double,
        transportMode: String
    ): Result<RouteEstimate> = withContext(Dispatchers.IO) {
        val profile = when (transportMode.lowercase()) {
            "walking" -> "foot"
            "bicycle" -> "bike"
            else -> "driving"
        }
        val base = baseUrlProvider().trimEnd('/')
        val url = "$base/route/v1/$profile/$fromLon,$fromLat;$toLon,$toLat?overview=false"
        val liveAttempt = runCatching {
            val req = Request.Builder().url(url).get().build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) error("OSRM HTTP ${resp.code}")
                val root = HttpClientFactory.json.parseToJsonElement(resp.body?.string().orEmpty()).jsonObject
                val firstRoute = root["routes"]?.jsonArray?.firstOrNull()?.jsonObject
                    ?: error("No route returned")
                val distKm = (firstRoute["distance"]?.jsonPrimitive?.doubleOrNull ?: 0.0) / 1000.0
                val durMin = ((firstRoute["duration"]?.jsonPrimitive?.doubleOrNull ?: 0.0) / 60.0).roundToInt()
                RouteEstimate(
                    distanceKm = distKm,
                    durationMinutes = maxOf(1, durMin),
                    isLiveRouting = true,
                    providerAttribution = "OSRM · © OpenStreetMap contributors"
                )
            }
        }
        if (liveAttempt.isSuccess) return@withContext liveAttempt

        // Honest straight-line estimate fallback (never claims live road routing)
        val straightKm = GeoMath.haversineKm(fromLat, fromLon, toLat, toLon)
        val avgSpeedKmh = when (transportMode.lowercase()) {
            "airplane" -> 650.0
            "train" -> 75.0
            "motorcycle" -> 42.0
            else -> 50.0
        }
        val estMin = maxOf(5, ((straightKm / avgSpeedKmh) * 60.0).roundToInt())
        Result.success(
            RouteEstimate(
                distanceKm = straightKm,
                durationMinutes = estMin,
                isLiveRouting = false,
                providerAttribution = "Straight-line geometric estimate",
                disclaimer = "Live routing provider unavailable; showing Haversine distance estimate."
            )
        )
    }
}

/**
 * Open-Meteo free non-commercial weather forecast provider (no API key required).
 */
class OpenMeteoWeatherProvider(
    private val client: OkHttpClient
) : WeatherProvider {
    override val providerName: String = "Open-Meteo"

    override suspend fun fetchForecast(
        destinationName: String,
        latitude: Double,
        longitude: Double,
        tripStartEpochDay: Long,
        tripEndEpochDay: Long
    ): Result<WeatherForecastResult> = withContext(Dispatchers.IO) {
        if (!DateUtils.isWithinOpenMeteoHorizon(tripStartEpochDay)) {
            return@withContext Result.success(
                WeatherForecastResult(
                    destinationName = destinationName,
                    days = emptyList(),
                    updatedAtIso = DateTimeFormatter.ISO_INSTANT.format(Instant.now()),
                    outOfRangeNotice = true
                )
            )
        }
        runCatching {
            val url = "https://api.open-meteo.com/v1/forecast" +
                "?latitude=$latitude&longitude=$longitude" +
                "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max" +
                "&timezone=auto&forecast_days=7"
            val req = Request.Builder().url(url).get().build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) error("Open-Meteo HTTP ${resp.code}")
                val daily = HttpClientFactory.json.parseToJsonElement(resp.body?.string().orEmpty())
                    .jsonObject["daily"]?.jsonObject ?: error("Missing daily forecast block")
                val times = daily["time"]?.jsonArray ?: JsonArray(emptyList())
                val tMax = daily["temperature_2m_max"]?.jsonArray ?: JsonArray(emptyList())
                val tMin = daily["temperature_2m_min"]?.jsonArray ?: JsonArray(emptyList())
                val precipProb = daily["precipitation_probability_max"]?.jsonArray ?: JsonArray(emptyList())
                val precipMm = daily["precipitation_sum"]?.jsonArray ?: JsonArray(emptyList())
                val codes = daily["weather_code"]?.jsonArray ?: JsonArray(emptyList())

                val forecastDays = times.indices.map { i ->
                    val code = codes.getOrNull(i)?.jsonPrimitive?.intOrNull ?: 0
                    val (label, advisory) = WmoWeatherClassifier.describe(code)
                    WeatherDayForecast(
                        dateIso = times[i].jsonPrimitive.content,
                        tempMinC = tMin.getOrNull(i)?.jsonPrimitive?.doubleOrNull ?: 0.0,
                        tempMaxC = tMax.getOrNull(i)?.jsonPrimitive?.doubleOrNull ?: 0.0,
                        precipitationProbPercent = precipProb.getOrNull(i)?.jsonPrimitive?.intOrNull ?: 0,
                        precipitationMm = precipMm.getOrNull(i)?.jsonPrimitive?.doubleOrNull ?: 0.0,
                        weatherCode = code,
                        conditionLabel = label,
                        severeAdvisory = advisory
                    )
                }
                val updated = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm 'UTC'")
                    .withZone(ZoneOffset.UTC)
                    .format(Instant.now())
                WeatherForecastResult(
                    destinationName = destinationName,
                    days = forecastDays,
                    updatedAtIso = updated,
                    outOfRangeNotice = false
                )
            }
        }
    }
}

/**
 * Fetches real, freely licensed destination photography via Wikipedia PageImages REST API.
 */
class WikimediaImageProvider(
    private val client: OkHttpClient
) : DestinationImageProvider {
    override val providerName: String = "Wikimedia Commons / Wikipedia"

    override suspend fun fetchImageForPlace(placeName: String): Result<String?> = withContext(Dispatchers.IO) {
        runCatching {
            val slug = URLEncoder.encode(placeName.trim().replace(' ', '_'), "UTF-8")
            val url = "https://en.wikipedia.org/api/rest_v1/page/summary/$slug"
            val req = Request.Builder().url(url).get().build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@use null
                val root = HttpClientFactory.json.parseToJsonElement(resp.body?.string().orEmpty()).jsonObject
                root["originalimage"]?.jsonObject?.get("source")?.jsonPrimitive?.content
                    ?: root["thumbnail"]?.jsonObject?.get("source")?.jsonPrimitive?.content
            }
        }
    }
}
