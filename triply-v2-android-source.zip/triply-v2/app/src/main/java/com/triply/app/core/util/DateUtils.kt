package com.triply.app.core.util

import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale

object DateUtils {

    fun validateDateRange(startEpochDay: Long?, endEpochDay: Long?): DateRangeValidation {
        if (startEpochDay == null || endEpochDay == null) {
            return DateRangeValidation.MissingDates
        }
        if (endEpochDay < startEpochDay) {
            return DateRangeValidation.EndBeforeStart
        }
        val days = (endEpochDay - startEpochDay).toInt() + 1
        return DateRangeValidation.Valid(days)
    }

    fun tripDurationDays(startEpochDay: Long, endEpochDay: Long): Int {
        return maxOf(1, (endEpochDay - startEpochDay).toInt() + 1)
    }

    fun formatShortDate(epochDay: Long, locale: Locale = Locale.getDefault()): String {
        val date = LocalDate.ofEpochDay(epochDay)
        val formatter = DateTimeFormatter.ofPattern("d MMM yyyy", locale)
        return date.format(formatter)
    }

    fun formatDateRange(startEpochDay: Long, endEpochDay: Long, locale: Locale = Locale.getDefault()): String {
        val start = LocalDate.ofEpochDay(startEpochDay)
        val end = LocalDate.ofEpochDay(endEpochDay)
        return if (start.year == end.year) {
            val startFmt = DateTimeFormatter.ofPattern("d MMM", locale)
            val endFmt = DateTimeFormatter.ofPattern("d MMM yyyy", locale)
            "${start.format(startFmt)} – ${end.format(endFmt)}"
        } else {
            "${formatShortDate(startEpochDay, locale)} – ${formatShortDate(endEpochDay, locale)}"
        }
    }

    fun isWithinOpenMeteoHorizon(targetEpochDay: Long, todayEpochDay: Long = LocalDate.now().toEpochDay()): Boolean {
        val diff = ChronoUnit.DAYS.between(LocalDate.ofEpochDay(todayEpochDay), LocalDate.ofEpochDay(targetEpochDay))
        return diff in -1..15
    }
}

sealed interface DateRangeValidation {
    data object MissingDates : DateRangeValidation
    data object EndBeforeStart : DateRangeValidation
    data class Valid(val durationDays: Int) : DateRangeValidation
}
