package com.triply.app

import android.app.Application
import com.triply.app.core.alarm.TripReminderScheduler
import com.triply.app.core.util.NetworkMonitor
import com.triply.app.data.local.EmergencyContactEntity
import com.triply.app.data.local.TriplyDatabase
import com.triply.app.data.local.UserPreferencesRepository
import com.triply.app.data.remote.HttpClientFactory
import com.triply.app.data.remote.HybridPlaceRepository
import com.triply.app.data.remote.NominatimFallbackProvider
import com.triply.app.data.remote.OpenFreeMapTileProvider
import com.triply.app.data.remote.OpenMeteoWeatherProvider
import com.triply.app.data.remote.OsrmRoutingProvider
import com.triply.app.data.remote.OverpassPoiProvider
import com.triply.app.data.remote.PhotonGeocodingProvider
import com.triply.app.data.remote.WikimediaImageProvider
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.maplibre.android.MapLibre

class AppContainer(application: Application) {
    val database: TriplyDatabase = TriplyDatabase.getInstance(application)
    val preferences: UserPreferencesRepository = UserPreferencesRepository(application)
    val networkMonitor: NetworkMonitor = NetworkMonitor(application)
    val reminderScheduler: TripReminderScheduler = TripReminderScheduler(application)

    private val httpClient = HttpClientFactory.createClient()
    val mapTileProvider = OpenFreeMapTileProvider()
    val photonProvider = PhotonGeocodingProvider(httpClient)
    val nominatimProvider = NominatimFallbackProvider(httpClient)
    val overpassProvider = OverpassPoiProvider(httpClient)
    val routingProvider = OsrmRoutingProvider(httpClient)
    val weatherProvider = OpenMeteoWeatherProvider(httpClient)
    val imageProvider = WikimediaImageProvider(httpClient)

    val placeRepository = HybridPlaceRepository(
        primaryGeocoder = photonProvider,
        fallbackGeocoder = nominatimProvider,
        poiProvider = overpassProvider,
        utilityDao = database.utilityDao(),
        isOnlineCheck = { networkMonitor.isCurrentlyOnline() }
    )

    fun seedOfficialEmergencyContacts(scope: CoroutineScope) {
        scope.launch(Dispatchers.IO) {
            val defaults = listOf(
                EmergencyContactEntity("id_112", "Indonesia National Emergency", "112", "OFFICIAL", "ID", "Single national emergency line"),
                EmergencyContactEntity("id_110", "Polisi (Police)", "110", "OFFICIAL", "ID", "Indonesian National Police"),
                EmergencyContactEntity("id_118", "Ambulans (Medical)", "118", "OFFICIAL", "ID", "Emergency medical & ambulance"),
                EmergencyContactEntity("id_113", "Pemadam Kebakaran (Fire)", "113", "OFFICIAL", "ID", "Fire & rescue department"),
                EmergencyContactEntity("id_115", "BASARNAS (Search & Rescue)", "115", "OFFICIAL", "ID", "Mountain, sea, and disaster rescue")
            )
            database.utilityDao().upsertEmergencyContacts(defaults)
        }
    }
}

class TriplyApplication : Application() {
    lateinit var container: AppContainer
        private set

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        MapLibre.getInstance(this)
        container = AppContainer(this)
        container.seedOfficialEmergencyContacts(appScope)
    }
}
