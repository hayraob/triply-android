package com.triply.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        TripEntity::class,
        TripDestinationEntity::class,
        ItineraryItemEntity::class,
        BudgetCategoryEntity::class,
        ExpenseEntity::class,
        PackingItemEntity::class,
        BookingEntity::class,
        JournalEntryEntity::class,
        GroupMemberEntity::class,
        EmergencyContactEntity::class,
        OfflineMapRegionEntity::class,
        WhatIfScenarioEntity::class,
        CachedPlaceEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class TriplyDatabase : RoomDatabase() {
    abstract fun tripDao(): TripDao
    abstract fun utilityDao(): UtilityDao

    companion object {
        @Volatile
        private var INSTANCE: TriplyDatabase? = null

        fun getInstance(context: Context): TriplyDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    TriplyDatabase::class.java,
                    "triply_v2.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
