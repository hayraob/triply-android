package com.triply.app.core.util

import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import kotlin.math.abs

enum class CurrencyCode(val symbol: String) {
    IDR("Rp"),
    USD("$"),
    SGD("S$"),
    EUR("€"),
    JPY("¥")
}

/**
 * Pure numeric IDR formatting & parsing utility.
 * Amounts are always stored as Long integers in the data layer, never as formatted strings.
 */
object IdrFormatter {

    fun format(amount: Long, currency: CurrencyCode = CurrencyCode.IDR): String {
        val sign = if (amount < 0) "-" else ""
        val digits = abs(amount).toString()
        val grouped = groupThousands(digits, separator = if (currency == CurrencyCode.IDR) '.' else ',')
        return "$sign${currency.symbol}$grouped"
    }

    fun formatDigitsOnly(rawDigits: String, currency: CurrencyCode = CurrencyCode.IDR): String {
        val cleaned = rawDigits.filter { it.isDigit() }.trimStart('0')
        if (cleaned.isEmpty()) return ""
        val grouped = groupThousands(cleaned, separator = if (currency == CurrencyCode.IDR) '.' else ',')
        return "${currency.symbol}$grouped"
    }

    fun parseToLong(input: String): Long {
        val digits = input.filter { it.isDigit() }
        if (digits.isEmpty()) return 0L
        return digits.toLongOrNull() ?: 0L
    }

    private fun groupThousands(digits: String, separator: Char): String {
        val sb = StringBuilder()
        var count = 0
        for (i in digits.length - 1 downTo 0) {
            if (count > 0 && count % 3 == 0) {
                sb.append(separator)
            }
            sb.append(digits[i])
            count++
        }
        return sb.reverse().toString()
    }
}

/**
 * Automatically formats raw numeric input as Rp150.000 / Rp1.500.000 while typing.
 */
class IdrVisualTransformation(
    private val currency: CurrencyCode = CurrencyCode.IDR
) : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val raw = text.text
        if (raw.isEmpty()) {
            return TransformedText(AnnotatedString(""), OffsetMapping.Identity)
        }
        val formatted = IdrFormatter.formatDigitsOnly(raw, currency)
        val mapping = object : OffsetMapping {
            override fun originalToTransformed(offset: Int): Int = formatted.length
            override fun transformedToOriginal(offset: Int): Int = raw.length
        }
        return TransformedText(AnnotatedString(formatted), mapping)
    }
}
