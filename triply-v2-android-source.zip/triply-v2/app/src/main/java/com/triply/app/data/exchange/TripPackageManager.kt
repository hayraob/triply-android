package com.triply.app.data.exchange

import com.triply.app.data.local.BookingEntity
import com.triply.app.data.local.BudgetCategoryEntity
import com.triply.app.data.local.ExpenseEntity
import com.triply.app.data.local.GroupMemberEntity
import com.triply.app.data.local.ItineraryItemEntity
import com.triply.app.data.local.JournalEntryEntity
import com.triply.app.data.local.PackingItemEntity
import com.triply.app.data.local.TripDestinationEntity
import com.triply.app.data.local.TripEntity
import com.triply.app.data.local.WhatIfScenarioEntity
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

@Serializable
data class TripPackagePayload(
    val schemaVersion: Int = CURRENT_SCHEMA_VERSION,
    val exportedAtMillis: Long = System.currentTimeMillis(),
    val trip: TripEntity,
    val destinations: List<TripDestinationEntity> = emptyList(),
    val itinerary: List<ItineraryItemEntity> = emptyList(),
    val budgetCategories: List<BudgetCategoryEntity> = emptyList(),
    val expenses: List<ExpenseEntity> = emptyList(),
    val packingItems: List<PackingItemEntity> = emptyList(),
    val bookings: List<BookingEntity> = emptyList(),
    val journalEntries: List<JournalEntryEntity> = emptyList(),
    val groupMembers: List<GroupMemberEntity> = emptyList(),
    val whatIfScenarios: List<WhatIfScenarioEntity> = emptyList()
) {
    companion object {
        const val CURRENT_SCHEMA_VERSION = 1
    }
}

data class ImportPreviewSummary(
    val payload: TripPackagePayload,
    val photoEntryCount: Int,
    val hasTripIdConflict: Boolean
)

/**
 * Security-hardened portable ZIP exporter/importer for Group Management (Module 10)
 * and Local Backup/Restore (Module 11).
 *
 * Enforces:
 * - Strict Zip-Slip path traversal rejection
 * - Per-entry (10 MB) and total archive (50 MB) size limits
 * - Schema version check
 * - Conflict detection before mutating local data
 */
object TripPackageManager {
    private const val MANIFEST_ENTRY = "manifest.json"
    private const val MAX_ENTRY_BYTES = 10L * 1024L * 1024L
    private const val MAX_TOTAL_BYTES = 50L * 1024L * 1024L

    private val json = Json {
        prettyPrint = true
        ignoreUnknownKeys = true
    }

    fun exportToZip(
        payload: TripPackagePayload,
        photoFiles: Map<String, File> = emptyMap(),
        output: OutputStream
    ) {
        ZipOutputStream(output).use { zos ->
            zos.putNextEntry(ZipEntry(MANIFEST_ENTRY))
            val manifestBytes = json.encodeToString(payload).toByteArray(Charsets.UTF_8)
            zos.write(manifestBytes)
            zos.closeEntry()

            for ((safeName, file) in photoFiles) {
                if (!file.exists() || !file.isFile) continue
                val cleanName = safeName.substringAfterLast('/').substringAfterLast('\\')
                if (cleanName.isBlank() || cleanName.contains("..")) continue
                zos.putNextEntry(ZipEntry("photos/$cleanName"))
                file.inputStream().use { it.copyTo(zos) }
                zos.closeEntry()
            }
        }
    }

    fun inspectAndValidateZip(
        input: InputStream,
        existingTripIds: Set<String>
    ): Result<ImportPreviewSummary> = runCatching {
        var manifestText: String? = null
        var photoCount = 0
        var totalBytes = 0L

        ZipInputStream(input).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                val entryName = entry.name
                require(!entryName.contains("..") && !entryName.startsWith("/") && !entryName.startsWith("\\")) {
                    "Unsafe ZIP path detected: $entryName"
                }
                if (!entry.isDirectory) {
                    val bytes = readBounded(zis, MAX_ENTRY_BYTES)
                    totalBytes += bytes.size
                    require(totalBytes <= MAX_TOTAL_BYTES) {
                        "ZIP package exceeds maximum allowed size (${MAX_TOTAL_BYTES / (1024 * 1024)} MB)."
                    }
                    when {
                        entryName == MANIFEST_ENTRY -> {
                            manifestText = bytes.toString(Charsets.UTF_8)
                        }
                        entryName.startsWith("photos/") -> {
                            photoCount++
                        }
                    }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }

        val rawManifest = manifestText ?: error("Missing $MANIFEST_ENTRY in ZIP package.")
        val payload = json.decodeFromString<TripPackagePayload>(rawManifest)
        require(payload.schemaVersion <= TripPackagePayload.CURRENT_SCHEMA_VERSION) {
            "Unsupported Triply package schema version: ${payload.schemaVersion}"
        }
        ImportPreviewSummary(
            payload = payload,
            photoEntryCount = photoCount,
            hasTripIdConflict = payload.trip.id in existingTripIds
        )
    }

    private fun readBounded(input: InputStream, maxBytes: Long): ByteArray {
        val out = ByteArrayOutputStream()
        val buf = ByteArray(8192)
        var readTotal = 0L
        while (true) {
            val n = input.read(buf)
            if (n <= 0) break
            readTotal += n
            require(readTotal <= maxBytes) { "ZIP entry exceeds maximum allowed size." }
            out.write(buf, 0, n)
        }
        return out.toByteArray()
    }
}
