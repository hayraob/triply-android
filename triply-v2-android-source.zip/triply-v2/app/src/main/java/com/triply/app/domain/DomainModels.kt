package com.triply.app.domain

import com.triply.app.data.local.BudgetCategoryEntity
import com.triply.app.data.local.ExpenseEntity
import com.triply.app.data.local.PackingItemEntity
import com.triply.app.data.local.TripDestinationEntity
import com.triply.app.data.local.TripEntity
import com.triply.app.data.local.WhatIfScenarioEntity
import kotlinx.serialization.Serializable
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

enum class PoiCategory(val osmTagFilter: String, val labelKey: String) {
    BEACH("natural=beach", "cat_beach"),
    MOUNTAIN("natural=peak", "cat_mountain"),
    ATTRACTION("tourism=attraction", "cat_attraction"),
    VILLAGE("place=village", "cat_village"),
    HOTEL("tourism=hotel", "cat_hotel"),
    GUESTHOUSE("tourism=guest_house", "cat_guesthouse"),
    RESTAURANT("amenity=restaurant", "cat_restaurant"),
    CAFE("amenity=cafe", "cat_cafe"),
    SHOP("shop=supermarket", "cat_shop"),
    CONVENIENCE("shop=convenience", "cat_convenience"),
    GAS_STATION("amenity=fuel", "cat_gas_station"),
    ATM("amenity=atm", "cat_atm"),
    PHARMACY("amenity=pharmacy", "cat_pharmacy"),
    HOSPITAL("amenity=hospital", "cat_hospital")
}

@Serializable
data class PlaceResult(
    val id: String,
    val name: String,
    val category: String,
    val address: String,
    val latitude: Double,
    val longitude: Double,
    val imageUrl: String? = null,
    val openingHours: String? = null,
    val providerName: String,
    val attribution: String
)

data class RouteEstimate(
    val distanceKm: Double,
    val durationMinutes: Int,
    val isLiveRouting: Boolean,
    val providerAttribution: String,
    val disclaimer: String? = null
)

data class WeatherDayForecast(
    val dateIso: String,
    val tempMinC: Double,
    val tempMaxC: Double,
    val precipitationProbPercent: Int,
    val precipitationMm: Double,
    val weatherCode: Int,
    val conditionLabel: String,
    val severeAdvisory: String? = null
)

data class WeatherForecastResult(
    val destinationName: String,
    val days: List<WeatherDayForecast>,
    val updatedAtIso: String,
    val sourceAttribution: String = "Open-Meteo (open-meteo.com)",
    val outOfRangeNotice: Boolean = false
)

enum class BudgetThresholdStatus {
    HEALTHY,
    APPROACHING,
    EXCEEDED
}

data class CategorySpendSummary(
    val categoryName: String,
    val allocatedIdr: Long,
    val spentIdr: Long
)

data class BudgetSummary(
    val totalPlannedIdr: Long,
    val totalSpentIdr: Long,
    val remainingIdr: Long,
    val utilizationPercent: Int,
    val status: BudgetThresholdStatus,
    val categoryBreakdown: List<CategorySpendSummary>
)

object BudgetCalculator {
    fun summarize(
        totalBudgetIdr: Long,
        categories: List<BudgetCategoryEntity>,
        expenses: List<ExpenseEntity>
    ): BudgetSummary {
        val totalSpent = expenses.sumOf { it.amountIdr }
        val remaining = totalBudgetIdr - totalSpent
        val percent = if (totalBudgetIdr > 0L) {
            ((totalSpent.toDouble() / totalBudgetIdr.toDouble()) * 100.0).roundToInt()
        } else {
            0
        }
        val status = when {
            totalBudgetIdr > 0L && totalSpent > totalBudgetIdr -> BudgetThresholdStatus.EXCEEDED
            totalBudgetIdr > 0L && percent >= 80 -> BudgetThresholdStatus.APPROACHING
            else -> BudgetThresholdStatus.HEALTHY
        }

        val spentByCategory = expenses.groupBy { it.categoryName }.mapValues { (_, list) ->
            list.sumOf { it.amountIdr }
        }
        val allCategoryNames = (categories.map { it.name } + spentByCategory.keys).distinct()
        val breakdown = allCategoryNames.map { name ->
            val alloc = categories.firstOrNull { it.name == name }?.allocatedIdr ?: 0L
            CategorySpendSummary(
                categoryName = name,
                allocatedIdr = alloc,
                spentIdr = spentByCategory[name] ?: 0L
            )
        }
        return BudgetSummary(
            totalPlannedIdr = totalBudgetIdr,
            totalSpentIdr = totalSpent,
            remainingIdr = remaining,
            utilizationPercent = percent,
            status = status,
            categoryBreakdown = breakdown
        )
    }
}

object DestinationOrdering {
    fun normalizeOrder(destinations: List<TripDestinationEntity>): List<TripDestinationEntity> {
        return destinations.mapIndexed { idx, dest -> dest.copy(orderIndex = idx) }
    }

    fun moveUp(destinations: List<TripDestinationEntity>, index: Int): List<TripDestinationEntity> {
        if (index <= 0 || index >= destinations.size) return normalizeOrder(destinations)
        val mutable = destinations.toMutableList()
        val item = mutable.removeAt(index)
        mutable.add(index - 1, item)
        return normalizeOrder(mutable)
    }

    fun moveDown(destinations: List<TripDestinationEntity>, index: Int): List<TripDestinationEntity> {
        if (index < 0 || index >= destinations.lastIndex) return normalizeOrder(destinations)
        val mutable = destinations.toMutableList()
        val item = mutable.removeAt(index)
        mutable.add(index + 1, item)
        return normalizeOrder(mutable)
    }
}

object PackingTemplates {
    fun itemsForTemplate(tripId: String, templateId: String, idFactory: () -> String): List<PackingItemEntity> {
        val pairs: List<Pair<String, String>> = when (templateId) {
            "hiking" -> listOf(
                "Gear" to "Hiking Boots",
                "Gear" to "Headlamp & Spare Batteries",
                "Gear" to "Rain Jacket / Poncho",
                "Gear" to "Reusable Water Bottle (1.5L)",
                "Safety" to "First-Aid Kit & Blister Plasters",
                "Clothing" to "Thermal Layer / Fleece"
            )
            "beach" -> listOf(
                "Sun Care" to "Reef-Safe Sunscreen SPF 50",
                "Sun Care" to "Polarized Sunglasses",
                "Clothing" to "Swimwear & Quick-Dry Towel",
                "Clothing" to "Sandals / Water Shoes",
                "Gear" to "Waterproof Dry Bag (10L)"
            )
            else -> listOf(
                "Documents" to "ID Card / Passport",
                "Documents" to "Booking Confirmations (Offline Copy)",
                "Tech" to "Power Bank & Charging Cables",
                "Health" to "Personal Medication & Hand Sanitizer",
                "Clothing" to "Comfortable Walking Shoes",
                "Essentials" to "Daypack"
            )
        }
        return pairs.map { (cat, name) ->
            PackingItemEntity(
                id = idFactory(),
                tripId = tripId,
                category = cat,
                name = name,
                quantity = 1,
                isPacked = false
            )
        }
    }

    fun completionRatio(items: List<PackingItemEntity>): Float {
        if (items.isEmpty()) return 0f
        return items.count { it.isPacked }.toFloat() / items.size.toFloat()
    }
}

object WhatIfEngine {
    data class ComparisonDelta(
        val budgetDeltaIdr: Long,
        val durationDeltaDays: Int,
        val transportChanged: Boolean
    )

    fun compare(original: TripEntity, scenario: WhatIfScenarioEntity): ComparisonDelta {
        val origDays = maxOf(1, (original.endDateEpochDay - original.startDateEpochDay).toInt() + 1)
        val altDays = maxOf(1, (scenario.altEndDateEpochDay - scenario.altStartDateEpochDay).toInt() + 1)
        return ComparisonDelta(
            budgetDeltaIdr = scenario.altBudgetIdr - original.totalBudgetIdr,
            durationDeltaDays = altDays - origDays,
            transportChanged = original.transportMode != scenario.altTransportMode
        )
    }

    /**
     * Explicit apply: returns a new TripEntity only when the user confirms applying a scenario.
     */
    fun applyScenarioToTrip(original: TripEntity, scenario: WhatIfScenarioEntity, nowMillis: Long): TripEntity {
        return original.copy(
            startDateEpochDay = scenario.altStartDateEpochDay,
            endDateEpochDay = scenario.altEndDateEpochDay,
            transportMode = scenario.altTransportMode,
            totalBudgetIdr = scenario.altBudgetIdr,
            updatedAtMillis = nowMillis
        )
    }
}

object GeoMath {
    private const val EARTH_RADIUS_KM = 6371.0

    fun haversineKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2) * sin(dLat / 2) +
            cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
            sin(dLon / 2) * sin(dLon / 2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return EARTH_RADIUS_KM * c
    }
}

object WmoWeatherClassifier {
    fun describe(code: Int): Pair<String, String?> = when (code) {
        0 -> "Clear sky" to null
        1, 2 -> "Partly cloudy" to null
        3 -> "Overcast" to null
        45, 48 -> "Fog / Mist" to null
        51, 53, 55 -> "Drizzle" to null
        61, 63 -> "Rain" to null
        65 -> "Heavy rain" to "Heavy rainfall reported by Open-Meteo. Plan covered transit."
        80, 81 -> "Rain showers" to null
        82 -> "Violent rain showers" to "Intense rain showers forecast. Exercise caution on roads."
        95 -> "Thunderstorm" to "Thunderstorm forecast by Open-Meteo. Avoid exposed beaches and peaks."
        96, 99 -> "Thunderstorm with hail" to "Severe thunderstorm with hail forecast. Delay outdoor travel."
        else -> "Variable conditions (WMO $code)" to null
    }
}
