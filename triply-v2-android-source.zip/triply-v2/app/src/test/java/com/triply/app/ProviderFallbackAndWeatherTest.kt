package com.triply.app

import com.triply.app.data.remote.GeocodingProvider
import com.triply.app.data.remote.HybridPlaceRepository
import com.triply.app.data.remote.PoiSearchProvider
import com.triply.app.domain.PlaceResult
import com.triply.app.domain.PoiCategory
import com.triply.app.domain.WmoWeatherClassifier
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ProviderFallbackAndWeatherTest {
    @Test
    fun fallsBackToSecondaryGeocoderWhenPrimaryFails() = runTest {
        val failingPrimary = object : GeocodingProvider {
            override val providerName = "Primary"
            override suspend fun searchPlaces(query: String, limit: Int) = Result.failure<List<PlaceResult>>(RuntimeException("503"))
            override suspend fun reverseGeocode(latitude: Double, longitude: Double) = Result.failure<PlaceResult?>(RuntimeException("503"))
        }
        val workingFallback = object : GeocodingProvider {
            override val providerName = "Fallback"
            override suspend fun searchPlaces(query: String, limit: Int) = Result.success(
                listOf(PlaceResult("1", "Parangtritis Beach", "beach", "Yogyakarta", -8.02, 110.33, providerName = "Fallback", attribution = "OSM"))
            )
            override suspend fun reverseGeocode(latitude: Double, longitude: Double) = Result.success(null)
        }
        val emptyPoi = object : PoiSearchProvider {
            override val providerName = "POI"
            override suspend fun searchByCategory(category: PoiCategory, centerLat: Double, centerLon: Double, radiusMeters: Int, limit: Int) =
                Result.success(emptyList<PlaceResult>())
        }

        val repo = HybridPlaceRepository(failingPrimary, workingFallback, emptyPoi, utilityDao = null, isOnlineCheck = { true })
        val res = repo.searchText("Parangtritis").getOrThrow()
        assertEquals(1, res.size)
        assertEquals("Parangtritis Beach", res.first().name)
    }

    @Test
    fun reportsOfflineFailureHonestyWhenNoCacheExists() = runTest {
        val dummyGeo = object : GeocodingProvider {
            override val providerName = "Dummy"
            override suspend fun searchPlaces(query: String, limit: Int) = Result.success(emptyList<PlaceResult>())
            override suspend fun reverseGeocode(latitude: Double, longitude: Double) = Result.success(null)
        }
        val dummyPoi = object : PoiSearchProvider {
            override val providerName = "Dummy"
            override suspend fun searchByCategory(category: PoiCategory, centerLat: Double, centerLon: Double, radiusMeters: Int, limit: Int) =
                Result.success(emptyList<PlaceResult>())
        }
        val repo = HybridPlaceRepository(dummyGeo, dummyGeo, dummyPoi, utilityDao = null, isOnlineCheck = { false })
        assertTrue(repo.searchText("Bali").isFailure)
    }

    @Test
    fun classifiesWmoSevereWeatherWithoutInventingAlerts() {
        val (_, clearAlert) = WmoWeatherClassifier.describe(0)
        val (_, stormAlert) = WmoWeatherClassifier.describe(95)
        assertNull(clearAlert)
        assertNotNull(stormAlert)
    }
}
