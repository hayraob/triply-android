package com.triply.app

import com.triply.app.data.local.BudgetCategoryEntity
import com.triply.app.data.local.ExpenseEntity
import com.triply.app.domain.BudgetCalculator
import com.triply.app.domain.BudgetThresholdStatus
import org.junit.Assert.assertEquals
import org.junit.Test

class BudgetAggregationTest {
    @Test
    fun computesTotalsCategoriesAndThresholdWarnings() {
        val categories = listOf(
            BudgetCategoryEntity("c1", "t1", "Food", 500_000L),
            BudgetCategoryEntity("c2", "t1", "Transport", 500_000L)
        )
        val expenses = listOf(
            ExpenseEntity("e1", "t1", "Food", "Lunch", 350_000L, 20000L),
            ExpenseEntity("e2", "t1", "Transport", "Train", 500_000L, 20000L)
        )
        val summary = BudgetCalculator.summarize(1_000_000L, categories, expenses)
        assertEquals(850_000L, summary.totalSpentIdr)
        assertEquals(150_000L, summary.remainingIdr)
        assertEquals(85, summary.utilizationPercent)
        assertEquals(BudgetThresholdStatus.APPROACHING, summary.status)
        assertEquals(2, summary.categoryBreakdown.size)
    }

    @Test
    fun flagsExceededBudgetWhenSpendingSurpassesPlan() {
        val expenses = listOf(ExpenseEntity("e1", "t1", "Hotel", "Stay", 1_200_000L, 20000L))
        val summary = BudgetCalculator.summarize(1_000_000L, emptyList(), expenses)
        assertEquals(BudgetThresholdStatus.EXCEEDED, summary.status)
        assertEquals(-200_000L, summary.remainingIdr)
    }
}
