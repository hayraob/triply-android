package com.triply.app

import com.triply.app.data.exchange.TripPackageManager
import com.triply.app.data.exchange.TripPackagePayload
import com.triply.app.data.local.TripDestinationEntity
import com.triply.app.data.local.TripEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class TripPackageValidationTest {
    @Test
    fun roundTripsValidTripPackageAndDetectsConflict() {
        val payload = TripPackagePayload(
            trip = TripEntity("trip-42", "Java Loop", 20100L, 20104L, "Friends", "Train", 3_500_000L),
            destinations = listOf(TripDestinationEntity("d1", "trip-42", 0, "Yogyakarta"))
        )
        val out = ByteArrayOutputStream()
        TripPackageManager.exportToZip(payload, emptyMap(), out)

        val preview = TripPackageManager.inspectAndValidateZip(
            ByteArrayInputStream(out.toByteArray()),
            existingTripIds = setOf("trip-42")
        ).getOrThrow()

        assertEquals("Java Loop", preview.payload.trip.title)
        assertEquals(1, preview.payload.destinations.size)
        assertTrue(preview.hasTripIdConflict)
    }

    @Test
    fun rejectsZipSlipPathTraversalEntries() {
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { zos ->
            zos.putNextEntry(ZipEntry("../evil.txt"))
            zos.write("bad".toByteArray())
            zos.closeEntry()
        }
        val result = TripPackageManager.inspectAndValidateZip(
            ByteArrayInputStream(out.toByteArray()),
            existingTripIds = emptySet()
        )
        assertTrue(result.isFailure)
    }
}
