package com.triply.app

import com.triply.app.core.util.DateRangeValidation
import com.triply.app.core.util.DateUtils
import com.triply.app.data.local.TripDestinationEntity
import com.triply.app.domain.DestinationOrdering
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TripValidationAndOrderingTest {
    @Test
    fun validatesDateRangesAccurately() {
        assertEquals(DateRangeValidation.MissingDates, DateUtils.validateDateRange(null, 20000L))
        assertEquals(DateRangeValidation.EndBeforeStart, DateUtils.validateDateRange(20005L, 20001L))
        val valid = DateUtils.validateDateRange(20000L, 20003L)
        assertTrue(valid is DateRangeValidation.Valid)
        assertEquals(4, (valid as DateRangeValidation.Valid).durationDays)
    }

    @Test
    fun reordersMultiDestinationStopsAndNormalizesIndices() {
        val stops = listOf(
            TripDestinationEntity("1", "t1", 0, "Pekalongan"),
            TripDestinationEntity("2", "t1", 1, "Dieng"),
            TripDestinationEntity("3", "t1", 2, "Yogyakarta")
        )
        val movedUp = DestinationOrdering.moveUp(stops, 2)
        assertEquals(listOf("Pekalongan", "Yogyakarta", "Dieng"), movedUp.map { it.name })
        assertEquals(listOf(0, 1, 2), movedUp.map { it.orderIndex })

        val movedDown = DestinationOrdering.moveDown(movedUp, 0)
        assertEquals(listOf("Yogyakarta", "Pekalongan", "Dieng"), movedDown.map { it.name })
    }
}
