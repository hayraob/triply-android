package com.triply.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import javax.xml.parsers.DocumentBuilderFactory

class LocalizationCompletenessTest {
    @Test
    fun englishAndIndonesianStringResourcesHaveExactKeyParity() {
        val enFile = File("src/main/res/values/strings.xml")
        val idFile = File("src/main/res/values-in/strings.xml")
        assertTrue("English strings.xml missing", enFile.exists())
        assertTrue("Indonesian strings.xml missing", idFile.exists())

        val enKeys = extractStringKeys(enFile)
        val idKeys = extractStringKeys(idFile)
        assertTrue("Expected >100 string keys", enKeys.size > 100)
        assertEquals("Mismatch between EN and ID string keys", enKeys, idKeys)
    }

    private fun extractStringKeys(file: File): Set<String> {
        val doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(file)
        val nodes = doc.getElementsByTagName("string")
        val keys = mutableSetOf<String>()
        for (i in 0 until nodes.length) {
            val name = nodes.item(i).attributes.getNamedItem("name")?.nodeValue
            if (!name.isNullOrBlank()) keys.add(name)
        }
        return keys
    }
}
