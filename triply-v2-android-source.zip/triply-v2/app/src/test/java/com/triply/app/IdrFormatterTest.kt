package com.triply.app

import com.triply.app.core.util.IdrFormatter
import org.junit.Assert.assertEquals
import org.junit.Test

class IdrFormatterTest {
    @Test
    fun formatsIdrWithIndonesianThousandsSeparators() {
        assertEquals("Rp0", IdrFormatter.format(0L))
        assertEquals("Rp150.000", IdrFormatter.format(150_000L))
        assertEquals("Rp1.500.000", IdrFormatter.format(1_500_000L))
        assertEquals("-Rp25.000", IdrFormatter.format(-25_000L))
    }

    @Test
    fun parsesFormattedAndRawDigitsToNumericLong() {
        assertEquals(150_000L, IdrFormatter.parseToLong("150000"))
        assertEquals(1_500_000L, IdrFormatter.parseToLong("Rp1.500.000"))
        assertEquals(0L, IdrFormatter.parseToLong(""))
    }

    @Test
    fun formatDigitsOnlyHandlesLeadingZeros() {
        assertEquals("Rp150.000", IdrFormatter.formatDigitsOnly("00150000"))
        assertEquals("", IdrFormatter.formatDigitsOnly("000"))
    }
}
