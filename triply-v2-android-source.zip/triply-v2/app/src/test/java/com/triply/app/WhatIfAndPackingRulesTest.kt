package com.triply.app

import com.triply.app.data.local.TripEntity
import com.triply.app.data.local.WhatIfScenarioEntity
import com.triply.app.domain.PackingTemplates
import com.triply.app.domain.WhatIfEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class WhatIfAndPackingRulesTest {
    @Test
    fun whatIfComparesNonDestructivelyAndAppliesExplicitly() {
        val original = TripEntity("t1", "Bali", 20100L, 20103L, "Couple", "Airplane", 6_000_000L)
        val scenario = WhatIfScenarioEntity("s1", "t1", "Overland Train", 20100L, 20105L, "Train", 4_200_000L, "Bali")

        val delta = WhatIfEngine.compare(original, scenario)
        assertEquals(-1_800_000L, delta.budgetDeltaIdr)
        assertEquals(2, delta.durationDeltaDays)
        assertTrue(delta.transportChanged)
        // Original remains unchanged until applyScenarioToTrip is explicitly called
        assertEquals(6_000_000L, original.totalBudgetIdr)

        val applied = WhatIfEngine.applyScenarioToTrip(original, scenario, nowMillis = 999L)
        assertEquals(4_200_000L, applied.totalBudgetIdr)
        assertEquals("Train", applied.transportMode)
    }

    @Test
    fun packingTemplatesComputeCompletionRatio() {
        var counter = 0
        val items = PackingTemplates.itemsForTemplate("t1", "hiking") { "id_${counter++}" }
        assertTrue(items.isNotEmpty())
        assertEquals(0f, PackingTemplates.completionRatio(items), 0.001f)
        val halfPacked = items.mapIndexed { idx, it -> it.copy(isPacked = idx < items.size / 2) }
        assertEquals(0.5f, PackingTemplates.completionRatio(halfPacked), 0.05f)
    }
}
