# Triply V2 — Provider Configuration Guide

Triply V2 is preconfigured to work out-of-the-box with free, open, zero-API-key providers for everyday users. Normal users are **never** asked to register for developer accounts or paste API keys.

## Default Provider Matrix

| Capability | Default Provider | Endpoint | API Key? | Quotas / Rate Limits & Terms | Required Attribution |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Vector Map Tiles** | [OpenFreeMap](https://openfreemap.org/quick_start/) via [MapLibre Native Android](https://github.com/maplibre/maplibre-native) (`11.11.0`) | `https://tiles.openfreemap.org/styles/{liberty\|dark\|positron\|bright}` | None | Free public vector tiles; offline downloads capped at 3,000 tiles / 50 MB per download, max 4 parallel requests, unique `User-Agent`. | `© OpenFreeMap · © OpenMapTiles · © OpenStreetMap contributors` |
| **Forward Geocoding (Primary)** | [Photon (Komoot)](https://github.com/komoot/photon) | `https://photon.komoot.io/api/` | None | Fair-use public instance; Triply debounces input (450 ms) and caches results for 24 h in Room. | `© OpenStreetMap contributors · Photon` |
| **Category POI Discovery** | [Overpass API](https://wiki.openstreetmap.org/wiki/Overpass_API) | `https://overpass-api.de/api/interpreter` | None | Public fair-use; bounded `timeout:12` and `out center 20`, cached locally by category + rounded center coordinates. | `© OpenStreetMap contributors · Overpass` |
| **Geocoding Fallback** | [Nominatim](https://operations.osmfoundation.org/policies/nominatim/) | `https://nominatim.openstreetmap.org/` | None | Strictly max 1 request/second (enforced via `Mutex` 1,100 ms throttle), custom `User-Agent`, never used for live keystroke autocomplete. | `© OpenStreetMap contributors · Nominatim` |
| **Route Estimates** | OSRM Public Demo Server | `https://router.project-osrm.org/route/v1/` | None | Demo server is best-effort and not SLA-backed; Triply falls back to a clearly labeled straight-line Haversine estimate when unavailable. | `OSRM · © OpenStreetMap contributors` |
| **Weather Forecasts** | [Open-Meteo](https://open-meteo.com/en/docs) | `https://api.open-meteo.com/v1/forecast` | None | Free for non-commercial use (<10,000 daily API calls per [Open-Meteo Terms](https://open-meteo.com/en/terms)); 16-day forecast horizon. | `Forecast by Open-Meteo` |
| **Destination Imagery** | Wikipedia PageImages / Wikimedia Commons | `https://en.wikipedia.org/api/rest_v1/page/summary/` | None | Custom `User-Agent` sent on all requests; images cached locally by Coil. | Wikimedia Commons / Wikipedia |

## Production Scaling & Secret Management
- **Never commit private API keys** to Git or embed server secrets in the APK.
- For commercial or high-traffic deployments:
  1. Self-host **OSRM** or **Valhalla** (or proxy **OpenRouteService** behind your own backend) and point **Profile > Advanced Provider Configuration > Custom OSRM Routing Base URL** to your endpoint.
  2. Self-host **Photon** or **OpenFreeMap** tiles (or configure a package-restricted commercial MapLibre style URL).
  3. Upgrade to an Open-Meteo commercial plan if distributing commercially.
