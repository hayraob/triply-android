# Triply V2 — Privacy & Third-Party Services

## Local-First Privacy Architecture
- Triply V2 requires **no user account, no login, and no cloud database**.
- All personal trip records (itineraries, expenses, budgets, packing checklists, bookings, journal notes, photos, group members, personal emergency contacts, and What-If scenarios) are stored strictly in the device's local Room database (`triply_v2.db`) and DataStore Preferences.
- No analytics SDKs, ad trackers, or telemetry beacons are included.

## Data Shared with Third-Party Services (Only When Invoked Online)
1. **OpenFreeMap**: Receives map tile viewport requests (tile coordinates & zoom) when rendering online maps.
2. **Photon / Nominatim / Overpass API**: Receives user search text or selected map center coordinates when searching places or nearby POIs.
3. **OSRM**: Receives origin and destination coordinates only when the user requests a route estimate.
4. **Open-Meteo**: Receives destination latitude/longitude when loading the Weather tab.
5. **Wikipedia / Wikimedia Commons**: Receives destination names to fetch real cover photographs.

## Android Permissions (Contextual & Minimal)
- `INTERNET` / `ACCESS_NETWORK_STATE`: Online maps, place search, weather, route estimates, and offline status detection.
- `ACCESS_COARSE_LOCATION` / `ACCESS_FINE_LOCATION`: Requested only when the user invokes location-dependent features (such as searching nearby hospitals/pharmacies in Emergency Center).
- `POST_NOTIFICATIONS` / `SCHEDULE_EXACT_ALARM`: Requested contextually when enabling departure reminders in Timeline; denied permissions are handled gracefully without claiming a reminder was scheduled.
- **Photo Access**: Uses Android's privacy-preserving `PickVisualMedia` Photo Picker for Journal attachments—no broad storage permission required.
