# Triply V2 — Architecture Document

## 1. Architectural Overview
Triply V2 uses a single-activity, unidirectional data flow (UDF) architecture in Kotlin & Jetpack Compose with strict separation between UI, pure domain rules, local persistence, and remote provider abstractions:

- **`com.triply.app.core.designsystem`**: Modern Travel Editorial color tokens, typography scale, shapes, and reusable components (`EditorialSectionHeader`, `EditorialDestinationImage`, `IdrAmountTextField`, `EditorialProgressBar`, `OfflineStatusBanner`).
- **`com.triply.app.core.util`**: Pure utilities (`IdrFormatter`, `DateUtils`, `NetworkMonitor`, `LocaleManager`).
- **`com.triply.app.core.alarm`**: Android `AlarmManager` exact-alarm scheduling with `TripReminderReceiver` and explicit permission-aware return statuses (`ReminderScheduleResult`).
- **`com.triply.app.domain`**: Platform-independent domain models and calculators (`BudgetCalculator`, `DestinationOrdering`, `PackingTemplates`, `WhatIfEngine`, `GeoMath`, `WmoWeatherClassifier`) covered by JVM unit tests.
- **`com.triply.app.data.local`**: Room database (`TriplyDatabase`, 13 entities, foreign-key cascades, `TripDao`, `UtilityDao`) and `UserPreferencesRepository` (DataStore Preferences).
- **`com.triply.app.data.remote`**: Separated provider interfaces (`MapTileProvider`, `GeocodingProvider`, `PoiSearchProvider`, `RoutingProvider`, `WeatherProvider`, `DestinationImageProvider`) and concrete zero-key open implementations.
- **`com.triply.app.data.exchange`**: `TripPackageManager` for portable, security-validated ZIP export/import.
- **`com.triply.app.ui`**: `TriplyViewModel`, `TriplyNavHost` (5-destination bottom bar), and modular screens for all 12 travel modules.

## 2. Local-First Persistence Schema (Room)
All core trip records are persisted locally in `triply_v2.db`:
`trips`, `trip_destinations`, `itinerary_items`, `budget_categories`, `expenses`, `packing_items`, `bookings`, `journal_entries`, `group_members`, `emergency_contacts`, `offline_map_regions`, `what_if_scenarios`, and `cached_places`.

Foreign keys on trip-scoped tables use `ON DELETE CASCADE` so deleting a trip cleans up child records atomically. Financial amounts are stored strictly as `Long` IDR integers (`amountIdr`, `totalBudgetIdr`, `priceIdr`) rather than formatted display strings.

## 3. Separated Provider Abstractions
Map tiles, forward/reverse geocoding, category POI discovery, routing, weather forecasting, and destination imagery are modeled as independent Kotlin interfaces so any provider can be swapped or proxied without touching UI code:
- **Tiles**: `OpenFreeMapTileProvider` (default) -> swappable in Developer Settings via custom style JSON URL.
- **Hybrid Search & POI**: `HybridPlaceRepository` checks Room cache (`cached_places`, 24h TTL) -> queries `PhotonGeocodingProvider` / `OverpassPoiProvider` -> falls back to rate-limited `NominatimFallbackProvider` -> fails honestly when offline with no cache.
- **Routing**: `OsrmRoutingProvider` with honest Haversine fallback clearly marked `isLiveRouting = false`.
- **Weather**: `OpenMeteoWeatherProvider` with 16-day forecast horizon check and WMO code severity mapping.
- **Imagery**: `WikimediaImageProvider` with Coil disk/memory caching.

## 4. ZIP Exchange Security Model
`TripPackageManager.inspectAndValidateZip()` enforces:
1. Path traversal rejection (blocks `..`, leading `/`, or `\`).
2. Bounded stream reading (10 MB max per entry, 50 MB max total archive).
3. `schemaVersion` compatibility check (`CURRENT_SCHEMA_VERSION = 1`).
4. Conflict detection (`hasTripIdConflict`) and user preview dialog before mutating local Room tables.
